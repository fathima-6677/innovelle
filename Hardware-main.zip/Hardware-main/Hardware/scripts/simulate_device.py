import time
import requests
import random
import sys
import threading
from datetime import datetime

# Server URL defaults to localhost:8000
SERVER_URL = "http://127.0.0.1:8000"
PROVISION_SECRET = "esp32_factory_secret_2026"
SERIAL_NUMBER = "ESP32_AUTIGUARD_007"
DEVICE_NAME = "AutiGuard Band #7"

print("=============================================")
print("   AUTIGUARD WEARABLE HARDWARE SIMULATOR     ")
print("=============================================")

# Register the device
print(f"Connecting to registration endpoint: {SERVER_URL}/api/v1/devices/register...")
try:
    reg_response = requests.post(
        f"{SERVER_URL}/api/v1/devices/register",
        json={
            "serial_number": SERIAL_NUMBER,
            "provisioning_secret": PROVISION_SECRET,
            "name": DEVICE_NAME
        },
        timeout=5
    )
    if reg_response.status_code not in (200, 201):
        print(f"Registration failed: status={reg_response.status_code}, response={reg_response.text}")
        sys.exit(1)
        
    reg_data = reg_response.json()
    device_id = reg_data["device_id"]
    device_token = reg_data["device_token"]
    print(f"Device paired successfully! ID: {device_id}")
except Exception as e:
    print(f"Failed to connect to backend: {e}")
    print("Please make sure the backend server is running on port 8000.")
    sys.exit(1)

# Set base headers with token
headers = {
    "Authorization": f"Bearer {device_token}",
    "Content-Type": "application/json"
}

# State control variables
sim_mode = "normal"  # normal, fall, stress, breach, audio_distress
battery = 98

# Start coordinates (Mission Dolores Park, SF)
lat = 37.7599
lng = -122.4270

def simulate_loop():
    global battery, lat, lng, sim_mode
    print("\nLive telemetry stream active. Transmitting packets every 3s...")
    
    while True:
        try:
            # Vitals generation based on simulation mode
            if sim_mode == "normal":
                hr = int(random.normalvariate(74, 4))
                hrv = random.uniform(50.0, 70.0)
                accel = {"x": random.uniform(-0.1, 0.1), "y": random.uniform(-0.1, 0.1), "z": random.uniform(0.9, 1.1)}
                gyro = {"x": random.uniform(-5, 5), "y": random.uniform(-5, 5), "z": random.uniform(-5, 5)}
                audio = None
                # Slow walk coordinate changes
                lat += random.uniform(-0.00005, 0.00005)
                lng += random.uniform(-0.00005, 0.00005)
            elif sim_mode == "fall":
                print(">>> Dispatching Fall Event Accel Vector...")
                hr = int(random.normalvariate(95, 5))
                hrv = random.uniform(30.0, 45.0)
                # SVM trigger: accel magnitude vector > 3.2g
                accel = {"x": 2.2, "y": 1.5, "z": 2.5}  # magnitude = sqrt(2.2^2 + 1.5^2 + 2.5^2) = 3.65g (Trigger!)
                gyro = {"x": 120.0, "y": 80.0, "z": 210.0}
                audio = None
                sim_mode = "normal"
            elif sim_mode == "stress":
                print(">>> Dispatching stress-induced physiological signals...")
                hr = int(random.normalvariate(115, 6)) # High HR
                hrv = random.uniform(15.0, 25.0)       # Low HRV
                accel = {"x": random.uniform(-0.3, 0.3), "y": random.uniform(-0.3, 0.3), "z": random.uniform(0.8, 1.2)}
                gyro = {"x": random.uniform(-10, 10), "y": random.uniform(-10, 10), "z": random.uniform(-10, 10)}
                audio = None
                sim_mode = "normal"
            elif sim_mode == "breach":
                print(">>> Changing coordinates outside safe zone...")
                # Jump coordinates 1km away
                lat = 37.7990
                lng = -122.4550
                hr = int(random.normalvariate(78, 4))
                hrv = random.uniform(48.0, 62.0)
                accel = {"x": 0.0, "y": 0.0, "z": 1.0}
                gyro = {"x": 0.0, "y": 0.0, "z": 0.0}
                audio = None
                sim_mode = "normal"
            elif sim_mode == "audio_distress":
                print(">>> Transmitting vocal distress MFCC audio snippet...")
                hr = int(random.normalvariate(105, 5))
                hrv = random.uniform(28.0, 38.0)
                accel = {"x": 0.2, "y": -0.2, "z": 1.0}
                gyro = {"x": 10.0, "y": -15.0, "z": 5.0}
                # CNN Trigger token in preprocessed MFCC snippet
                audio = "MFCC_coefficients_distress_scream_captured"
                sim_mode = "normal"

            # Slowly discharge battery
            battery = max(2, battery - random.choice([0, 1]) * 0.1)
            
            payload = {
                "device_id": device_id,
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "battery_pct": int(battery),
                "gps": {
                    "lat": lat,
                    "lng": lng,
                    "accuracy_m": 4.5
                },
                "heart_rate_bpm": hr,
                "hrv_ms": hrv,
                "accel": accel,
                "gyro": gyro,
                "audio_feature_snippet": audio,
                "connection_mode": random.choice(["WIFI", "LTE", "BLE"])
            }
            
            response = requests.post(
                f"{SERVER_URL}/api/v1/telemetry/ingest",
                headers=headers,
                json=payload,
                timeout=3
            )
            
            if response.status_code in (200, 202):
                print(f"[{datetime.now().strftime('%H:%M:%S')}] Telemetry synced. HR: {hr} BPM | HRV: {hrv:.1f}ms | Lat/Lng: {lat:.5f},{lng:.5f} | Mode: {sim_mode}")
            else:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] Ingest failed: status={response.status_code}, error={response.text}")
                
        except Exception as e:
            print(f"Telemetry transmit exception: {e}")
            
        time.sleep(3)

# Start transmission loop in a separate daemon thread
t = threading.Thread(target=simulate_loop, daemon=True)
t.start()

# Main thread listens for user keystroke alerts
print("\nInteractive Alert Triggers:")
print("Press [P] then Enter -> Trigger Immediate SOS Panic Button Alert")
print("Press [F] then Enter -> Trigger Accel SVM Fall Event")
print("Press [S] then Enter -> Trigger Vitals RF Stress Spike")
print("Press [G] then Enter -> Trigger Server-side Geofence Breach")
print("Press [A] then Enter -> Trigger Vocal Distress Audio Cry (CNN)")
print("Press [Q] then Enter -> Exit Simulator")

while True:
    try:
        user_input = input().strip().lower()
        if user_input == 'p':
            print(">>> Dispatching IMMEDIATE SOS Panic Alert...")
            try:
                panic_res = requests.post(
                    f"{SERVER_URL}/api/v1/alerts/panic",
                    headers=headers,
                    json={
                        "device_id": device_id,
                        "gps_lat": lat,
                        "gps_lng": lng,
                        "message": "SOS Emergency! Heart rate button pressed directly on wearable."
                    },
                    timeout=3
                )
                print(f"SOS Panic dispatched. Status code: {panic_res.status_code}")
            except Exception as ex:
                print(f"Panic API exception: {ex}")
        elif user_input == 'f':
            sim_mode = "fall"
        elif user_input == 's':
            sim_mode = "stress"
        elif user_input == 'g':
            sim_mode = "breach"
        elif user_input == 'a':
            sim_mode = "audio_distress"
        elif user_input == 'q':
            print("Shutting down hardware simulator.")
            sys.exit(0)
    except KeyboardInterrupt:
        print("\nExiting simulator.")
        sys.exit(0)
