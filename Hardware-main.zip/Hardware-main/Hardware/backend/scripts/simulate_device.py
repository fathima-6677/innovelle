#!/usr/bin/env python3
"""
AutiGuard ESP32 Wearable — Python Device Simulator
====================================================
Publishes synthetic but plausible telemetry to the FastAPI backend at the
same cadence and schema the real ESP32 firmware uses, so the full pipeline
(ingestion → AI engine → WebSocket broadcast → dashboard) can be exercised
without physical hardware.

Usage
-----
    # Default — HTTP REST mode, auto-registers a device, streams every 5 s
    python scripts/simulate_device.py

    # Custom options
    python scripts/simulate_device.py \\
        --api-url http://localhost:8000 \\
        --device-serial ESP32_AUTIGUARD_SIM_001 \\
        --interval 5 \\
        --transport http            # or mqtt
        --mqtt-broker mqtt://localhost:1883

Interactive keyboard commands (stdin)
--------------------------------------
    f   Trigger a fall event (high-g spike)
    p   Trigger a SOS panic event
    o   Teleport GPS outside the geofence
    r   Reset GPS back inside the geofence
    h   Spike heart rate (stress simulation)
    n   Normalize all vitals
    d   Trigger distress audio event
    q   Quit

Requirements: httpx, paho-mqtt (both in requirements.txt)
"""
from __future__ import annotations

import argparse
import asyncio
import json
import math
import random
import sys
import time
from datetime import datetime, timezone
from typing import Any

import httpx

# ── Defaults ──────────────────────────────────────────────────────────────────
DEFAULT_API_URL    = "http://localhost:8000"
DEFAULT_SERIAL     = "ESP32_AUTIGUARD_SIM_001"
DEFAULT_INTERVAL   = 5      # seconds between telemetry packets
DEFAULT_DEVICE_KEY = "esp32_factory_secret_2026"

# Base GPS — San Francisco (Civic Center area)
BASE_LAT = 37.7799
BASE_LNG = -122.4183

# ─────────────────────────────────────────────────────────────────────────────
# Simulated sensor state
# ─────────────────────────────────────────────────────────────────────────────
class SensorState:
    def __init__(self) -> None:
        self.lat         = BASE_LAT
        self.lng         = BASE_LNG
        self.heart_rate  = 72
        self.hrv_ms      = 52.0
        self.battery_pct = 97
        self.accel_x     = 0.02
        self.accel_y     = 0.01
        self.accel_z     = 1.00   # resting ≈ 1 g (gravity)
        self.gyro_x      = 0.0
        self.gyro_y      = 0.0
        self.gyro_z      = 0.0
        self.connection  = "LTE"
        self._outside    = False
        self._fall_flag  = False
        self._distress   = False
        self._tick       = 0

    # ── Manual triggers ───────────────────────────────────────────────────
    def trigger_fall(self) -> None:
        self.accel_x = round(random.uniform(3.5, 6.0), 2)
        self.accel_y = round(random.uniform(2.0, 4.0), 2)
        self.accel_z = round(random.uniform(0.1, 0.4), 2)
        self._fall_flag = True
        print("\n[SIM] 💥 FALL triggered — high-g spike injected into accel payload")

    def trigger_distress(self) -> None:
        self._distress = True
        print("\n[SIM] 🎙️  DISTRESS audio event triggered")

    def go_outside_geofence(self) -> None:
        self.lat = BASE_LAT + 0.004   # ~440 m north-east
        self.lng = BASE_LNG + 0.004
        self._outside = True
        print("\n[SIM] 📍 GPS teleported OUTSIDE geofence boundary")

    def reset_gps(self) -> None:
        self.lat = BASE_LAT
        self.lng = BASE_LNG
        self._outside = False
        print("\n[SIM] 📍 GPS reset to safe zone center")

    def spike_heart_rate(self) -> None:
        self.heart_rate = random.randint(118, 135)
        self.hrv_ms     = round(random.uniform(18, 28), 1)
        print(f"\n[SIM] ❤️  Heart rate spiked to {self.heart_rate} BPM (stress simulation)")

    def normalize(self) -> None:
        self.heart_rate = 72
        self.hrv_ms     = 52.0
        self.accel_x    = 0.02
        self.accel_y    = 0.01
        self.accel_z    = 1.00
        self._fall_flag = False
        self._distress  = False
        print("\n[SIM] ✅ All vitals normalized")

    # ── Autonomous drift (called every tick) ─────────────────────────────
    def drift(self) -> None:
        self._tick += 1

        # GPS micro-drift inside zone
        if not self._outside:
            self.lat += random.uniform(-0.00003, 0.00003)
            self.lng += random.uniform(-0.00003, 0.00003)

        # Heart rate natural oscillation (unless manually spiked)
        if self.heart_rate < 100:
            self.heart_rate = max(58, min(95, self.heart_rate + random.randint(-2, 3)))
        else:
            self.heart_rate = max(72, self.heart_rate - random.randint(0, 3))

        # HRV inverse correlation with HR
        self.hrv_ms = round(max(18, min(90, 110 - self.heart_rate + random.uniform(-3, 3))), 1)

        # Accel resting noise
        if not self._fall_flag:
            self.accel_x = round(random.uniform(-0.08, 0.08), 3)
            self.accel_y = round(random.uniform(-0.06, 0.06), 3)
            self.accel_z = round(random.uniform(0.95, 1.05), 3)
        else:
            # Decay fall spike after one tick
            self.accel_x = round(random.uniform(-0.15, 0.15), 3)
            self.accel_y = round(random.uniform(-0.12, 0.12), 3)
            self.accel_z = round(random.uniform(0.90, 1.10), 3)
            self._fall_flag = False

        # Gyro always small
        self.gyro_x = round(random.uniform(-0.5, 0.5), 3)
        self.gyro_y = round(random.uniform(-0.5, 0.5), 3)
        self.gyro_z = round(random.uniform(-0.2, 0.2), 3)

        # Battery slow drain (1% every ~100 ticks)
        if self._tick % 100 == 0:
            self.battery_pct = max(5, self.battery_pct - 1)

    def telemetry_payload(self) -> dict[str, Any]:
        audio_snippet = "distress_scream" if self._distress else None
        if self._distress:
            self._distress = False   # one-shot

        return {
            "device_id": None,       # filled in by the caller
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "battery_pct": self.battery_pct,
            "connection_mode": self.connection,
            "gps": {
                "lat": round(self.lat, 6),
                "lng": round(self.lng, 6),
                "accuracy_m": round(random.uniform(3, 12), 1),
            },
            "heart_rate_bpm": self.heart_rate,
            "hrv_ms": self.hrv_ms,
            "accel": {
                "x": self.accel_x,
                "y": self.accel_y,
                "z": self.accel_z,
            },
            "gyro": {
                "x": self.gyro_x,
                "y": self.gyro_y,
                "z": self.gyro_z,
            },
            "audio_feature_snippet": audio_snippet,
        }


# ─────────────────────────────────────────────────────────────────────────────
# HTTP transport
# ─────────────────────────────────────────────────────────────────────────────
class HttpTransport:
    def __init__(self, api_url: str, device_key: str, device_id: str) -> None:
        self._base    = api_url.rstrip("/")
        self._key     = device_key
        self._id      = device_id
        self._headers = {
            "X-Device-Key": device_key,
            "Content-Type": "application/json",
        }

    async def send_telemetry(self, payload: dict[str, Any]) -> None:
        payload["device_id"] = self._id
        async with httpx.AsyncClient(timeout=8) as client:
            r = await client.post(
                f"{self._base}/api/v1/telemetry/ingest",
                json=payload,
                headers=self._headers,
            )
            if r.status_code not in (200, 202):
                print(f"[HTTP] Telemetry error {r.status_code}: {r.text[:120]}")

    async def send_panic(self, lat: float, lng: float) -> None:
        body = {
            "device_id": self._id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "gps": {"lat": lat, "lng": lng, "accuracy_m": 5.0},
        }
        async with httpx.AsyncClient(timeout=8) as client:
            r = await client.post(
                f"{self._base}/api/v1/events/panic/{self._id}",
                json=body,
                headers=self._headers,
            )
            if r.status_code not in (200, 202):
                print(f"[HTTP] Panic error {r.status_code}: {r.text[:120]}")
            else:
                print("[HTTP] 🚨 Panic alert dispatched successfully")

    async def send_fall(self, impact_g: float, inactivity_s: int) -> None:
        body = {
            "device_id": self._id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "impact_g": impact_g,
            "post_fall_inactivity_s": inactivity_s,
        }
        async with httpx.AsyncClient(timeout=8) as client:
            r = await client.post(
                f"{self._base}/api/v1/events/fall/{self._id}",
                json=body,
                headers=self._headers,
            )
            if r.status_code not in (200, 202):
                print(f"[HTTP] Fall event error {r.status_code}: {r.text[:120]}")
            else:
                result = r.json()
                print(f"[HTTP] Fall event accepted — label={result.get('fall_label')}")


# ─────────────────────────────────────────────────────────────────────────────
# MQTT transport
# ─────────────────────────────────────────────────────────────────────────────
class MqttTransport:
    def __init__(self, broker_url: str, device_id: str) -> None:
        self._device_id  = device_id
        self._broker_url = broker_url

        try:
            import paho.mqtt.client as mqtt
            self._mqtt = mqtt
        except ImportError:
            print("[MQTT] paho-mqtt not installed. Run: pip install paho-mqtt")
            sys.exit(1)

        hostname = broker_url.replace("mqtt://", "").replace("mqtts://", "").split(":")[0]
        port_str = broker_url.split(":")[-1] if ":" in broker_url.replace("://", "") else "1883"
        try:
            port = int(port_str)
        except ValueError:
            port = 1883

        self._client = mqtt.Client(client_id=f"autiguard-sim-{device_id}")
        self._client.connect(hostname, port, keepalive=60)
        self._client.loop_start()
        print(f"[MQTT] Connected to {hostname}:{port}")

    def _topic(self, event: str) -> str:
        return f"autiguard/{self._device_id}/{event}"

    async def send_telemetry(self, payload: dict[str, Any]) -> None:
        payload["device_id"] = self._device_id
        self._client.publish(self._topic("telemetry"), json.dumps(payload), qos=1)

    async def send_panic(self, lat: float, lng: float) -> None:
        body = {
            "device_id": self._device_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "gps": {"lat": lat, "lng": lng, "accuracy_m": 5.0},
        }
        self._client.publish(self._topic("panic"), json.dumps(body), qos=2)
        print("[MQTT] 🚨 Panic published on panic topic (QoS 2)")

    async def send_fall(self, impact_g: float, inactivity_s: int) -> None:
        body = {
            "device_id": self._device_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "impact_g": impact_g,
            "post_fall_inactivity_s": inactivity_s,
        }
        self._client.publish(self._topic("fall_event"), json.dumps(body), qos=1)
        print(f"[MQTT] Fall event published — impact={impact_g}g")


# ─────────────────────────────────────────────────────────────────────────────
# Device registration helper
# ─────────────────────────────────────────────────────────────────────────────
async def register_device(api_url: str, serial: str, device_key: str) -> str:
    """Register (or re-register) the simulated device and return its UUID."""
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.post(
            f"{api_url}/api/v1/devices/register",
            json={
                "serial_number": serial,
                "provisioning_secret": device_key,
                "name": f"AutiGuard Simulator ({serial[-6:]})",
            },
        )
        if r.status_code in (200, 201):
            data = r.json()
            device_id = data["device_id"]
            print(f"[SIM] Device registered: id={device_id[:8]}… token={data['device_token'][:24]}…")
            return device_id
        else:
            print(f"[SIM] Registration error {r.status_code}: {r.text[:200]}")
            sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Keyboard listener (non-blocking, reads single chars from stdin)
# ─────────────────────────────────────────────────────────────────────────────
_COMMAND_QUEUE: asyncio.Queue[str] = asyncio.Queue()


def _start_keyboard_listener() -> None:
    """Read single-char keyboard commands on a background thread."""
    import threading

    def _reader():
        while True:
            try:
                ch = sys.stdin.read(1)
                if ch:
                    _COMMAND_QUEUE.put_nowait(ch.strip().lower())
            except Exception:
                break

    t = threading.Thread(target=_reader, daemon=True)
    t.start()


# ─────────────────────────────────────────────────────────────────────────────
# Main simulation loop
# ─────────────────────────────────────────────────────────────────────────────
async def run_simulator(
    api_url: str,
    serial: str,
    interval: int,
    transport_mode: str,
    mqtt_broker: str,
    device_key: str,
) -> None:
    # 1. Register device with the FastAPI backend
    print(f"\n{'='*60}")
    print("  AutiGuard ESP32 Wearable Simulator (Python)")
    print(f"{'='*60}")
    print(f"  API URL   : {api_url}")
    print(f"  Serial    : {serial}")
    print(f"  Transport : {transport_mode.upper()}")
    print(f"  Interval  : {interval}s")
    print(f"{'='*60}")
    print("  Commands: [f]=fall [p]=panic [o]=outside geofence")
    print("            [r]=reset GPS [h]=spike HR [n]=normalize")
    print("            [d]=distress audio [q]=quit")
    print(f"{'='*60}\n")

    device_id = await register_device(api_url, serial, device_key)

    # 2. Build transport
    if transport_mode == "mqtt":
        transport: HttpTransport | MqttTransport = MqttTransport(mqtt_broker, device_id)
    else:
        transport = HttpTransport(api_url, device_key, device_id)

    sensor = SensorState()
    _start_keyboard_listener()

    last_tick = time.monotonic()

    while True:
        # ── Process keyboard commands ─────────────────────────────────────
        while not _COMMAND_QUEUE.empty():
            cmd = _COMMAND_QUEUE.get_nowait()
            if cmd == "q":
                print("\n[SIM] Stopping simulator. Goodbye.")
                return
            elif cmd == "f":
                sensor.trigger_fall()
                impact = round(random.uniform(4.0, 7.0), 2)
                await transport.send_fall(impact_g=impact, inactivity_s=random.randint(3, 8))
            elif cmd == "p":
                await transport.send_panic(lat=sensor.lat, lng=sensor.lng)
            elif cmd == "o":
                sensor.go_outside_geofence()
            elif cmd == "r":
                sensor.reset_gps()
            elif cmd == "h":
                sensor.spike_heart_rate()
            elif cmd == "n":
                sensor.normalize()
            elif cmd == "d":
                sensor.trigger_distress()

        # ── Periodic telemetry tick ───────────────────────────────────────
        now = time.monotonic()
        if now - last_tick >= interval:
            last_tick = now
            sensor.drift()
            payload = sensor.telemetry_payload()

            try:
                await transport.send_telemetry(payload)
                print(
                    f"[{datetime.now().strftime('%H:%M:%S')}] "
                    f"GPS={payload['gps']['lat']:.5f},{payload['gps']['lng']:.5f}  "
                    f"HR={payload['heart_rate_bpm']} BPM  "
                    f"HRV={payload['hrv_ms']} ms  "
                    f"Batt={payload['battery_pct']}%  "
                    f"Accel=({payload['accel']['x']:.2f},{payload['accel']['y']:.2f},{payload['accel']['z']:.2f})g"
                )
            except Exception as exc:
                print(f"[SIM] Transmission error: {exc}")

        await asyncio.sleep(0.1)   # tight loop — real work is in the 5 s gate


# ─────────────────────────────────────────────────────────────────────────────
# CLI entry point
# ─────────────────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="AutiGuard ESP32 Python Simulator")
    parser.add_argument("--api-url",      default=DEFAULT_API_URL,    help="FastAPI base URL")
    parser.add_argument("--device-serial",default=DEFAULT_SERIAL,     help="Simulated device serial")
    parser.add_argument("--interval",     default=DEFAULT_INTERVAL,   type=int, help="Telemetry interval (s)")
    parser.add_argument("--transport",    default="http", choices=["http", "mqtt"], help="Transport mode")
    parser.add_argument("--mqtt-broker",  default="mqtt://localhost:1883", help="MQTT broker URL")
    parser.add_argument("--device-key",   default=DEFAULT_DEVICE_KEY, help="Device provisioning key")
    args = parser.parse_args()

    try:
        asyncio.run(run_simulator(
            api_url=args.api_url,
            serial=args.device_serial,
            interval=args.interval,
            transport_mode=args.transport,
            mqtt_broker=args.mqtt_broker,
            device_key=args.device_key,
        ))
    except KeyboardInterrupt:
        print("\n[SIM] Interrupted by user.")


if __name__ == "__main__":
    main()
