"""
Behavioral Prediction Model — LSTM on rolling stress-score window (heuristic stub).

Input features:
    stress_history  : list[float] — ordered list of recent stress scores (oldest→newest)
    device_id       : str         — used for per-device history stored in the engine

Output:
    score  — meltdown escalation risk 0–100 for the next ~30 minutes
    label  — "stable" | "elevated_anxiety" | "critical_meltdown_risk"

To swap in a real LSTM:
    1. Build a Keras LSTM: input shape (N_STEPS, N_FEATURES).
    2. Save: model.save("behavioral_lstm.h5")
    3. In __init__: self._model = tf.keras.models.load_model("behavioral_lstm.h5")
    4. In predict(): normalise history → reshape → self._model.predict(x)[0][0] * 100
"""
from __future__ import annotations
import logging
from typing import Any

from ai_engine.base import BaseModel, ModelResult

logger = logging.getLogger("autiguard.ai.behavioral")

# In-process rolling buffer: device_id → deque of stress scores
# (populated by the ingestion worker so the model always sees the latest window)
from collections import deque
_history_store: dict[str, deque[float]] = {}
WINDOW_SIZE = 50  # keep the last 50 stress readings per device


def push_stress_score(device_id: str, score: float) -> None:
    """Called by the ingestion worker after every stress model run."""
    if device_id not in _history_store:
        _history_store[device_id] = deque(maxlen=WINDOW_SIZE)
    _history_store[device_id].append(score)


def get_stress_history(device_id: str) -> list[float]:
    return list(_history_store.get(device_id, []))


class BehavioralModel(BaseModel):
    MODEL_NAME = "BehavioralPrediction-LSTM"

    def predict(self, features: dict[str, Any]) -> ModelResult:
        device_id: str = features.get("device_id", "unknown")
        # Caller may pass an explicit list, otherwise read from in-process store
        history: list[float] = features.get("stress_history") or get_stress_history(device_id)

        if not history:
            return ModelResult(score=10.0, label="stable", confidence=0.3)

        risk, label = self._heuristic(history)
        logger.info(f"[BehavioralModel] device={device_id} risk={risk:.1f}% label={label}")

        return ModelResult(
            score=round(risk, 2),
            label=label,
            confidence=min(1.0, len(history) / WINDOW_SIZE),  # grows as window fills
            raw={
                "window_size": len(history),
                "mean_stress": round(sum(history) / len(history), 2),
                "trend_delta": round(history[-1] - history[0], 2) if len(history) > 1 else 0.0,
            },
        )

    @staticmethod
    def _heuristic(history: list[float]) -> tuple[float, str]:
        n = len(history)
        avg = sum(history) / n
        # Slope: difference between last and first reading as a trend proxy
        delta = history[-1] - history[0] if n > 1 else 0.0
        # Weighted blend: base risk from average, amplified by rising trend
        risk = avg
        if delta > 10:
            risk += delta * 1.4  # escalating trend → significant risk boost
        elif delta < -10:
            risk -= abs(delta) * 0.6  # de-escalating → modest reduction
        risk = max(0.0, min(100.0, risk))

        if risk > 70:
            label = "critical_meltdown_risk"
        elif risk > 40:
            label = "elevated_anxiety"
        else:
            label = "stable"
        return risk, label


behavioral_model = BehavioralModel()
