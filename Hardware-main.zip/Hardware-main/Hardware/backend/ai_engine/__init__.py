# ai_engine — AutiGuard ML inference module
# Each model lives in its own file and implements a common predict() interface.
# Swap heuristic stubs for real trained .pkl / .tflite / .h5 artefacts without
# touching the FastAPI layer — just replace the implementation inside each class.
