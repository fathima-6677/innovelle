"""
Distress Audio Recognition — CNN on MFCC features (heuristic stub).

Input features:
    audio_feature_snippet : str  — Base64-encoded pre-processed MFCC vector
                                    OR a special trigger string from the simulator
    confidence            : float — on-device classifier confidence 0–1 (optional)

Output:
    score  — distress probability 0.0–1.0
    label  — "no_distress" | "possible_distress" | "confirmed_distress"

To swap in a real TensorFlow Lite / Keras CNN:
    1. Export model: model.save("distress_cnn.tflite")  or  model.save("distress_cnn.h5")
    2. In __init__ load interpreter:
           import tflite_runtime.interpreter as tflite
           self._interp = tflite.Interpreter("distress_cnn.tflite")
           self._interp.allocate_tensors()
    3. In predict(), decode base64 → numpy MFCC array → run_inference → return score.
"""
from __future__ import annotations
import base64
import logging
from typing import Any

from ai_engine.base import BaseModel, ModelResult

logger = logging.getLogger("autiguard.ai.distress")

# Simulator / test-harness trigger strings (case-insensitive)
_TRIGGER_KEYWORDS = {"distress_scream", "scream", "crying", "meltdown", "distress"}


class DistressModel(BaseModel):
    MODEL_NAME = "DistressAudio-CNN"

    def predict(self, features: dict[str, Any]) -> ModelResult:
        snippet: str | None = features.get("audio_feature_snippet")
        device_conf: float = float(features.get("confidence") or 0.0)

        if not snippet:
            return ModelResult(score=0.0, label="no_distress", confidence=0.0)

        probability, label = self._heuristic(snippet, device_conf)

        if probability > 0.5:
            logger.warning(
                f"[DistressModel] distress detected — probability={probability:.2f} label={label}"
            )

        return ModelResult(
            score=round(probability, 4),
            label=label,
            confidence=probability,
            raw={"snippet_length": len(snippet), "device_confidence": device_conf},
        )

    @staticmethod
    def _heuristic(snippet: str, device_conf: float) -> tuple[float, str]:
        # Check for simulator / integration-test trigger keywords
        lower = snippet.lower()
        for kw in _TRIGGER_KEYWORDS:
            if kw in lower:
                prob = max(0.90, device_conf) if device_conf > 0 else 0.92
                return prob, "confirmed_distress"

        # Attempt to decode Base64 MFCC vector and use its mean energy as proxy
        try:
            decoded = base64.b64decode(snippet + "==")  # pad to be safe
            # Mean byte value as a rough energy proxy (0-255 → 0.0-1.0)
            energy = sum(decoded) / (len(decoded) * 255) if decoded else 0.0
            # Blend with device confidence
            prob = 0.4 * energy + 0.6 * device_conf
            if prob > 0.70:
                return round(min(prob, 0.95), 4), "confirmed_distress"
            if prob > 0.45:
                return round(prob, 4), "possible_distress"
        except Exception:
            # Treat decode failure as unknown / benign
            pass

        return 0.0, "no_distress"


distress_model = DistressModel()
