"""
AIEngine — single entry-point for the FastAPI ingestion layer.

Usage:
    from ai_engine.engine import ai_engine

    stress  = ai_engine.stress(hr=95, hrv=38, ax=0.1, ay=0.2, az=1.0)
    fall    = ai_engine.fall(ax=4.1, ay=0.3, az=0.5, impact_g=5.2, inactivity_s=4)
    distress= ai_engine.distress(snippet="distress_scream", device_confidence=0.91)
    trend   = ai_engine.behavioral(device_id="abc123")

All methods return a ModelResult with .score, .label, .confidence, .raw.
"""
from __future__ import annotations
import datetime
from typing import Any

from ai_engine.base import ModelResult
from ai_engine.stress_model import stress_model
from ai_engine.fall_model import fall_model
from ai_engine.distress_model import distress_model
from ai_engine.behavioral_model import behavioral_model, push_stress_score


class AIEngine:
    # ------------------------------------------------------------------ #
    # Stress (Random Forest)
    # ------------------------------------------------------------------ #
    def stress(
        self,
        hr: int | None = None,
        hrv: float | None = None,
        ax: float = 0.0,
        ay: float = 0.0,
        az: float = 1.0,
        hour_of_day: int | None = None,
    ) -> ModelResult:
        features: dict[str, Any] = {
            "heart_rate_bpm": hr,
            "hrv_ms": hrv,
            "accel_x": ax,
            "accel_y": ay,
            "accel_z": az,
            "hour_of_day": hour_of_day if hour_of_day is not None
                           else datetime.datetime.utcnow().hour,
        }
        return stress_model.predict(features)

    # ------------------------------------------------------------------ #
    # Fall (SVM + rule-based)
    # ------------------------------------------------------------------ #
    def fall(
        self,
        ax: float = 0.0,
        ay: float = 0.0,
        az: float = 1.0,
        impact_g: float = 0.0,
        inactivity_s: int = 0,
    ) -> ModelResult:
        features: dict[str, Any] = {
            "accel_x": ax,
            "accel_y": ay,
            "accel_z": az,
            "impact_g": impact_g,
            "post_fall_inactivity_s": inactivity_s,
        }
        return fall_model.predict(features)

    # ------------------------------------------------------------------ #
    # Distress audio (CNN)
    # ------------------------------------------------------------------ #
    def distress(
        self,
        snippet: str | None = None,
        device_confidence: float = 0.0,
    ) -> ModelResult:
        features: dict[str, Any] = {
            "audio_feature_snippet": snippet,
            "confidence": device_confidence,
        }
        return distress_model.predict(features)

    # ------------------------------------------------------------------ #
    # Behavioral trend (LSTM)
    # ------------------------------------------------------------------ #
    def behavioral(
        self,
        device_id: str,
        stress_history: list[float] | None = None,
    ) -> ModelResult:
        features: dict[str, Any] = {
            "device_id": device_id,
            "stress_history": stress_history,
        }
        return behavioral_model.predict(features)

    # ------------------------------------------------------------------ #
    # Helper called by ingestion worker to keep the LSTM window fresh
    # ------------------------------------------------------------------ #
    @staticmethod
    def record_stress_score(device_id: str, score: float) -> None:
        push_stress_score(device_id, score)


# Module-level singleton
ai_engine = AIEngine()
