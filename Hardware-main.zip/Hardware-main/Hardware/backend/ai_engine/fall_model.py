"""
Fall Detection Model — SVM + rule-based post-validation (heuristic stub).

Input features:
    accel_x/y/z          : float — 3-axis accelerometer in g units (required)
    impact_g             : float — peak impact magnitude reported by device (optional)
    post_fall_inactivity_s: int  — seconds of inactivity after impact (optional)

Output:
    score      — fall confidence 0.0–1.0
    label      — "no_fall" | "possible_fall" | "confirmed_fall"

To swap in a real SVM:
    1. Train on windowed accelerometer features; pickle with joblib.
    2. Load in __init__; replace _heuristic() with model.decision_function([feat])[0].
"""
from __future__ import annotations
import math
import logging
from typing import Any

from ai_engine.base import BaseModel, ModelResult

logger = logging.getLogger("autiguard.ai.fall")

# g-force thresholds
FREEFALL_LOW_G = 0.3      # below this → free-fall phase
IMPACT_HIGH_G  = 3.0      # above this → impact phase
INACTIVITY_S   = 3        # seconds without motion after impact = confirmed fall


class FallModel(BaseModel):
    MODEL_NAME = "FallDetection-SVM"

    def predict(self, features: dict[str, Any]) -> ModelResult:
        ax: float = float(features.get("accel_x") or 0.0)
        ay: float = float(features.get("accel_y") or 0.0)
        az: float = float(features.get("accel_z") or 1.0)
        impact_g: float = float(features.get("impact_g") or 0.0)
        inactivity: int = int(features.get("post_fall_inactivity_s") or 0)

        magnitude = math.sqrt(ax**2 + ay**2 + az**2)
        confidence, label = self._heuristic(magnitude, impact_g, inactivity)

        if confidence > 0:
            logger.warning(
                f"[FallModel] magnitude={magnitude:.2f}g confidence={confidence:.2f} label={label}"
            )

        return ModelResult(
            score=round(confidence, 4),
            label=label,
            confidence=confidence,
            raw={"magnitude_g": round(magnitude, 4), "impact_g": impact_g, "inactivity_s": inactivity},
        )

    @staticmethod
    def _heuristic(magnitude: float, impact_g: float, inactivity: int):
        # Phase 1: free-fall detection
        is_freefall = magnitude < FREEFALL_LOW_G

        # Phase 2: impact spike — use higher of stream magnitude or device-reported peak
        peak = max(magnitude, impact_g)
        is_impact = peak > IMPACT_HIGH_G

        # Phase 3: post-fall inactivity
        is_inactive = inactivity >= INACTIVITY_S

        if is_impact and is_inactive:
            confidence = min(0.97, 0.60 + (peak - IMPACT_HIGH_G) * 0.08 + inactivity * 0.01)
            return confidence, "confirmed_fall"

        if is_impact or (is_freefall and peak > 2.0):
            confidence = min(0.65, 0.35 + (peak - IMPACT_HIGH_G) * 0.06)
            return max(0.0, confidence), "possible_fall"

        return 0.0, "no_fall"


fall_model = FallModel()
