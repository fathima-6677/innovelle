"""
Common base class and result types for every AutiGuard AI model.

All models implement:
    predict(features: dict) -> ModelResult

This allows the ingestion service to call any model through the same
interface and swap heuristic stubs for real trained artefacts later.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ModelResult:
    """Unified result envelope returned by every model."""

    # Primary scalar output (score, probability, boolean cast to float)
    score: float

    # Human-readable label for the score bucket
    label: str

    # Raw model output (dict, list, etc.) — useful for debugging / logging
    raw: dict[str, Any] = field(default_factory=dict)

    # Confidence / probability in [0, 1] — may equal score for probability outputs
    confidence: float = 1.0

    def as_dict(self) -> dict[str, Any]:
        return {
            "score": self.score,
            "label": self.label,
            "confidence": self.confidence,
            "raw": self.raw,
        }


class BaseModel:
    """
    Abstract base every ai_engine model should inherit from.
    Concrete classes must override `predict`.
    """

    MODEL_NAME: str = "BaseModel"

    def predict(self, features: dict[str, Any]) -> ModelResult:  # noqa: D102
        raise NotImplementedError(f"{self.MODEL_NAME}.predict() not implemented")
