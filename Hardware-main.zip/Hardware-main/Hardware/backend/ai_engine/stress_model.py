"""
Stress Detection Model — Random Forest (heuristic stub).

Input features (all optional, sensible defaults applied):
    heart_rate_bpm  : int   — beats per minute
    hrv_ms          : float — heart rate variability in milliseconds
    accel_x/y/z     : float — 3-axis accelerometer in g units
    hour_of_day     : int   — 0-23, used as a circadian proxy

Output:
    score  — stress index 0–100
    label  — "low" | "medium" | "high"

To swap in a real scikit-learn RandomForestClassifier:
    1. Pickle the trained model: joblib.dump(clf, "stress_rf.pkl")
    2. Load it once in __init__:  self._model = joblib.load("stress_rf.pkl")
    3. Replace _heuristic() with self._model.predict_proba([feature_vector])[0][1] * 100
"""
from __future__ import annotations
import math
import logging
from typing import Any

from ai_engine.base import BaseModel, ModelResult

logger = logging.getLogger("autiguard.ai.stress")


class StressModel(BaseModel):
    MODEL_NAME = "StressDetection-RandomForest"

    # ------------------------------------------------------------------ #
    # Public interface
    # ------------------------------------------------------------------ #
    def predict(self, features: dict[str, Any]) -> ModelResult:
        hr: float = float(features.get("heart_rate_bpm") or 72)
        hrv: float = float(features.get("hrv_ms") or 50.0)
        ax: float = float(features.get("accel_x") or 0.0)
        ay: float = float(features.get("accel_y") or 0.0)
        az: float = float(features.get("accel_z") or 1.0)
        hour: int = int(features.get("hour_of_day") or 12)

        score = self._heuristic(hr, hrv, ax, ay, az, hour)
        label = self._bucket(score)
        logger.info(f"[StressModel] score={score:.1f} label={label}")

        return ModelResult(
            score=round(score, 2),
            label=label,
            confidence=min(1.0, score / 100),
            raw={"hr": hr, "hrv": hrv, "motion": self._motion(ax, ay, az)},
        )

    # ------------------------------------------------------------------ #
    # Internal helpers (replace with real model forward-pass here)
    # ------------------------------------------------------------------ #
    @staticmethod
    def _motion(ax: float, ay: float, az: float) -> float:
        magnitude = math.sqrt(ax**2 + ay**2 + az**2)
        return round(abs(magnitude - 1.0), 4)  # deviation from 1 g (resting)

    def _heuristic(
        self,
        hr: float,
        hrv: float,
        ax: float,
        ay: float,
        az: float,
        hour: int,
    ) -> float:
        score = 28.0  # baseline offset

        # Elevated heart rate → stress
        if hr > 90:
            score += (hr - 90) * 1.4

        # Low HRV → stress (low HRV = poor autonomic balance)
        if hrv < 50:
            score += (50 - hrv) * 1.1

        # High motion intensity (agitation / stimming)
        motion = self._motion(ax, ay, az)
        if motion > 0.4:
            score += motion * 18

        # Circadian penalty — late-night / early-morning hours add small load
        if hour < 6 or hour > 22:
            score += 6.0

        return max(0.0, min(100.0, score))

    @staticmethod
    def _bucket(score: float) -> str:
        if score > 75:
            return "high"
        if score > 45:
            return "medium"
        return "low"


# Module-level singleton so the FastAPI app doesn't reconstruct per-request
stress_model = StressModel()
