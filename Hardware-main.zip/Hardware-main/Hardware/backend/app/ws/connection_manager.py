from fastapi import WebSocket
from typing import Dict, List
import json
from app.core.logging import logger

class ConnectionManager:
    def __init__(self):
        # Maps device_id -> list of active WebSockets
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, device_id: str):
        await websocket.accept()
        if device_id not in self.active_connections:
            self.active_connections[device_id] = []
        self.active_connections[device_id].append(websocket)
        logger.info(f"WebSocket client connected to room: device:{device_id}")

    def disconnect(self, websocket: WebSocket, device_id: str):
        if device_id in self.active_connections:
            if websocket in self.active_connections[device_id]:
                self.active_connections[device_id].remove(websocket)
                logger.info(f"WebSocket client disconnected from room: device:{device_id}")
            if not self.active_connections[device_id]:
                del self.active_connections[device_id]

    async def send_personal_message(self, message: dict, websocket: WebSocket):
        await websocket.send_json(message)

    async def broadcast_to_device(self, device_id: str, message: dict):
        if device_id in self.active_connections:
            logger.info(f"Broadcasting to {len(self.active_connections[device_id])} dashboard clients in room: device:{device_id}")
            # Iterate copy of connections to avoid modification errors during broadcast loop
            for connection in list(self.active_connections[device_id]):
                try:
                    await connection.send_json(message)
                except Exception as e:
                    logger.error(f"Error sending message to WebSocket client: {e}")
                    self.disconnect(connection, device_id)

manager = ConnectionManager()
