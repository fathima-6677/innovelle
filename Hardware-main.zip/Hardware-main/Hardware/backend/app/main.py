import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from app.core.config import settings
from app.core.limiter import limiter          # shared instance — no circular import
from app.core.logging import logger
from app.db.postgres import engine, Base
from app.db.dynamo import DynamoDBClient
from app.services.ingestion_service import telemetry_processing_worker
from app.services.mqtt_bridge import run_mqtt_bridge

# ── API Routers ────────────────────────────────────────────────────────────────
from app.api.v1.users import router as users_router
from app.api.v1.devices import router as devices_router
from app.api.v1.telemetry import router as telemetry_router
from app.api.v1.alerts import router as alerts_router
from app.api.v1.geofence import router as geofence_router
from app.api.v1.identity_qr import router as identity_qr_router
from app.api.v1.nonverbal import router as nonverbal_router
from app.api.v1.dashboard import router as dashboard_router
from app.api.v1.events import router as events_router


# ── Lifespan ───────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing AutiGuard backend services…")

    # 1. Create / migrate relational DB tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Relational database tables ready.")

    # 2. Ensure DynamoDB telemetry table exists
    await DynamoDBClient.create_table_if_not_exists()

    # 3. Background AI/ML queue worker
    worker_task = asyncio.create_task(telemetry_processing_worker())
    logger.info("Telemetry processing worker started.")

    # 4. MQTT bridge (no-op if MQTT_BROKER_URL is blank in .env)
    mqtt_task = asyncio.create_task(run_mqtt_bridge())
    logger.info("MQTT bridge task started.")

    yield  # ── app is running ─────────────────────────────────────────────────

    logger.info("Shutting down AutiGuard services…")
    for task in (worker_task, mqtt_task):
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
    logger.info("All background tasks stopped.")


# ── Application ────────────────────────────────────────────────────────────────
app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Backend service for the AutiGuard wearable monitoring system.",
    version="1.1.0",
    lifespan=lifespan,
)

# Attach rate limiter
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# CORS — lock allow_origins to your dashboard domain in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Register routers ───────────────────────────────────────────────────────────
V1 = settings.API_V1_STR

app.include_router(users_router,       prefix=f"{V1}/users",       tags=["Users"])
app.include_router(devices_router,     prefix=f"{V1}/devices",     tags=["Devices"])
app.include_router(telemetry_router,   prefix=f"{V1}/telemetry",   tags=["Telemetry"])
app.include_router(alerts_router,      prefix=f"{V1}/alerts",      tags=["Alerts"])
app.include_router(geofence_router,    prefix=f"{V1}/geofence",    tags=["Geofences"])
app.include_router(identity_qr_router, prefix=f"{V1}/identity_qr", tags=["QR Identity"])
app.include_router(nonverbal_router,   prefix=f"{V1}/nonverbal",   tags=["Non-Verbal Assist"])
app.include_router(dashboard_router,   prefix=f"{V1}/dashboard",   tags=["Dashboard"])
app.include_router(events_router,      prefix=f"{V1}/events",      tags=["Event Ingestion"])


# ── Health check ───────────────────────────────────────────────────────────────
@app.get("/", tags=["Health"])
def health_check():
    return {
        "status": "online",
        "service": "AutiGuard API",
        "version": "1.1.0",
        "docs": "/docs",
    }
