"""
Shared slowapi rate-limiter instance.

Defined here (not in main.py) to avoid a circular import:
  main.py → telemetry.py (router) → main.py (limiter)

Both main.py and any router that needs rate-limiting import from this module.
"""
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address, default_limits=["300/minute"])
