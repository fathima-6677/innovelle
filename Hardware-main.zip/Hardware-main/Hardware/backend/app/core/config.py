import os
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    PROJECT_NAME: str = "AutiGuard API"
    API_V1_STR: str = "/api/v1"

    # ── Auth ─────────────────────────────────────────────────────────────
    JWT_SECRET_KEY: str = os.getenv("JWT_SECRET_KEY", "supersecretkeychangeinproduction")
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24        # 24 hours
    DEVICE_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 365  # 1 year

    # ── Device provisioning ───────────────────────────────────────────────
    DEVICE_PROVISIONING_SECRET: str = os.getenv(
        "DEVICE_PROVISIONING_SECRET", "esp32_factory_secret_2026"
    )

    # ── Relational DB ─────────────────────────────────────────────────────
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL", "sqlite+aiosqlite:///./autiguard.db"
    )

    # ── DynamoDB ──────────────────────────────────────────────────────────
    DYNAMODB_TABLE_NAME: str = os.getenv("DYNAMODB_TABLE_NAME", "autiguard_telemetry")
    AWS_ACCESS_KEY_ID: Optional[str] = os.getenv("AWS_ACCESS_KEY_ID")
    AWS_SECRET_ACCESS_KEY: Optional[str] = os.getenv("AWS_SECRET_ACCESS_KEY")
    AWS_REGION: str = os.getenv("AWS_REGION", "us-east-1")
    USE_LOCAL_DYNAMO_MOCK: bool = os.getenv("USE_LOCAL_DYNAMO_MOCK", "true").lower() == "true"

    # ── MQTT bridge ───────────────────────────────────────────────────────
    # Leave blank to disable the MQTT bridge (REST-only mode).
    MQTT_BROKER_URL: str = os.getenv("MQTT_BROKER_URL", "")
    MQTT_PORT: int = int(os.getenv("MQTT_PORT", "1883"))
    MQTT_TLS_PORT: int = int(os.getenv("MQTT_TLS_PORT", "8883"))
    MQTT_USERNAME: str = os.getenv("MQTT_USERNAME", "")
    MQTT_PASSWORD: str = os.getenv("MQTT_PASSWORD", "")
    MQTT_CA_CERT_PATH: str = os.getenv("MQTT_CA_CERT_PATH", "")
    MQTT_CLIENT_CERT_PATH: str = os.getenv("MQTT_CLIENT_CERT_PATH", "")
    MQTT_CLIENT_KEY_PATH: str = os.getenv("MQTT_CLIENT_KEY_PATH", "")

    # ── Notifications ─────────────────────────────────────────────────────
    TWILIO_ACCOUNT_SID: Optional[str] = os.getenv("TWILIO_ACCOUNT_SID")
    TWILIO_AUTH_TOKEN: Optional[str] = os.getenv("TWILIO_AUTH_TOKEN")
    TWILIO_PHONE_NUMBER: Optional[str] = os.getenv("TWILIO_PHONE_NUMBER")

    # ── QR Identity ───────────────────────────────────────────────────────
    # Generate: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
    QR_AES_KEY: str = os.getenv("QR_AES_KEY", "g5tH_xK-Sly01x-Lz9Z7Jv9Dvxo7k6yTzD8n5N_X4P0=")

    # ── S3 audio clips ────────────────────────────────────────────────────
    S3_BUCKET_NAME: str = os.getenv("S3_BUCKET_NAME", "autiguard-audio-clips")
    S3_REGION: str = os.getenv("S3_REGION", "us-east-1")

    # ── Rate limiting ─────────────────────────────────────────────────────
    # Applied per device to ingestion endpoints.
    RATE_LIMIT_INGEST: str = os.getenv("RATE_LIMIT_INGEST", "120/minute")  # 2 rps per device

    class Config:
        case_sensitive = True


settings = Settings()
