from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from datetime import datetime
from typing import List

from app.db.postgres import get_db
from app.models.models import WearerRequest, Device
from app.schemas.schemas import NonVerbalRequest, NonVerbalResponse
from app.core.security import get_current_user
from app.ws.connection_manager import manager

router = APIRouter()

# Device-facing endpoint to post non-verbal assist messages
@router.post("/request", response_model=NonVerbalResponse, status_code=status.HTTP_201_CREATED)
async def post_wearer_request(
    payload: NonVerbalRequest,
    db: AsyncSession = Depends(get_db)
):
    # Verify device exists
    device_res = await db.execute(select(Device).where(Device.id == payload.device_id))
    device = device_res.scalars().first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not registered")
        
    db_req = WearerRequest(
        device_id=payload.device_id,
        message=payload.message,
        timestamp=datetime.utcnow()
    )
    db.add(db_req)
    await db.commit()
    await db.refresh(db_req)
    
    # Broadcast through WebSockets to dashboard room instantly
    await manager.broadcast_to_device(payload.device_id, {
        "type": "nonverbal.new",
        "data": {
            "id": db_req.id,
            "device_id": db_req.device_id,
            "message": db_req.message,
            "timestamp": db_req.timestamp.isoformat()
        }
    })
    
    return db_req

# Caregiver dashboard query endpoint
@router.get("/device/{device_id}", response_model=List[NonVerbalResponse])
async def list_wearer_requests(
    device_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    res = await db.execute(
        select(WearerRequest)
        .where(WearerRequest.device_id == device_id)
        .order_by(WearerRequest.timestamp.desc())
        .limit(30)
    )
    requests = res.scalars().all()
    return requests
