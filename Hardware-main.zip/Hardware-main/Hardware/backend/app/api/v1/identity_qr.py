from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from datetime import datetime

from app.db.postgres import get_db
from app.models.models import Device, QRIdentity, ScanLog, User
from app.schemas.schemas import QRIdentityResponse, QRScanRequest, QRDecodedResponse
from app.services.qr_identity_service import QRIdentityService
from app.services.notification_service import NotificationService
from app.core.security import get_current_user
from app.core.logging import logger

router = APIRouter()

# 7. Dynamic QR rotation endpoint (generated on wearable or pulled by guardian client)
@router.get("/display/{device_id}", response_model=QRIdentityResponse)
async def get_or_create_qr(
    device_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Verify device exists
    device_res = await db.execute(select(Device).where(Device.id == device_id))
    device = device_res.scalars().first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    # Generate new encrypted payload
    encrypted = QRIdentityService.generate_encrypted_qr(device.id, f"Wearer of {device.name}")
    
    # Check if there is already a QR code
    qr_res = await db.execute(select(QRIdentity).where(QRIdentity.device_id == device_id))
    qr_record = qr_res.scalars().first()
    
    if qr_record:
        qr_record.encrypted_payload = encrypted
        qr_record.rotated_at = datetime.utcnow()
    else:
        qr_record = QRIdentity(
            device_id=device_id,
            encrypted_payload=encrypted,
            rotated_at=datetime.utcnow()
        )
        db.add(qr_record)
        
    await db.commit()
    await db.refresh(qr_record)
    
    return QRIdentityResponse(
        device_id=qr_record.device_id,
        encrypted_payload=qr_record.encrypted_payload,
        rotated_at=qr_record.rotated_at
    )

# 7. QR Scan logging & hierarchical decryption endpoint
@router.post("/scan", response_model=QRDecodedResponse)
async def scan_qr_code(
    payload: QRScanRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    try:
        # Hierarchically decode based on current scanning user's role
        decoded_info = QRIdentityService.decrypt_and_filter_qr(
            payload.encrypted_payload, 
            current_user.role
        )
    except Exception as e:
        logger.error(f"Failed to decrypt scanned QR: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e) or "Invalid QR payload format."
        )

    device_id = decoded_info["device_id"]
    
    # Log the access scan event
    scan_log = ScanLog(
        device_id=device_id,
        timestamp=datetime.utcnow(),
        location_lat=payload.location_lat,
        location_lng=payload.location_lng,
        accessor_role=current_user.role,
        notification_sent=True
    )
    db.add(scan_log)
    
    # Load device owner info to notify the guardian
    device_res = await db.execute(select(Device).where(Device.id == device_id))
    device = device_res.scalars().first()
    if device and device.owner_id:
        owner_res = await db.execute(select(User).where(User.id == device.owner_id))
        owner = owner_res.scalars().first()
        
        # Dispatch SMS/Push notification alert to guardian about the scan
        alert_details = f"Role: {current_user.role}. Scanned by: {current_user.name}."
        if payload.location_lat and payload.location_lng:
            alert_details += f" Coordinates: {payload.location_lat:.4f}, {payload.location_lng:.4f}"
            
        await NotificationService.dispatch_critical_alert(
            device_name=device.name,
            alert_type="QR Scan Event",
            details=alert_details
        )
        
    await db.commit()
    
    return QRDecodedResponse(**decoded_info)
