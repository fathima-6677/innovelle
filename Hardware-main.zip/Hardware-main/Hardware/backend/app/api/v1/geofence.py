from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List

from app.db.postgres import get_db
from app.models.models import Geofence, Device
from app.schemas.schemas import GeofenceCreate, GeofenceResponse
from app.core.security import get_current_user

router = APIRouter()

@router.post("/", response_model=GeofenceResponse, status_code=status.HTTP_201_CREATED)
async def create_geofence(
    payload: GeofenceCreate,
    device_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    # Verify device exists and belongs to the caregiver
    res = await db.execute(select(Device).where(Device.id == device_id))
    device = res.scalars().first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
        
    db_geofence = Geofence(
        device_id=device_id,
        name=payload.name,
        center_lat=payload.center_lat,
        center_lng=payload.center_lng,
        radius_meters=payload.radius_meters,
        is_active=True
    )
    
    db.add(db_geofence)
    await db.commit()
    await db.refresh(db_geofence)
    return db_geofence

@router.get("/device/{device_id}", response_model=List[GeofenceResponse])
async def list_geofences(
    device_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    res = await db.execute(
        select(Geofence).where(Geofence.device_id == device_id, Geofence.is_active == True)
    )
    geofences = res.scalars().all()
    return geofences

@router.delete("/{geofence_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_geofence(
    geofence_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    res = await db.execute(select(Geofence).where(Geofence.id == geofence_id))
    geofence = res.scalars().first()
    if not geofence:
        raise HTTPException(status_code=404, detail="Geofence not found")
        
    await db.delete(geofence)
    await db.commit()
    return None
