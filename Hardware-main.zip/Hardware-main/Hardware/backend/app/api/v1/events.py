"""
Event ingestion endpoints — hardware-facing REST fallback for MQTT events.

All endpoints:
  - Accept a per-device API key in the X-Device-Key header  OR
    a device-scoped Bearer JWT (same token issued on registration).
  - Run through the same ai_engine + alert pipeline as the MQTT bridge.
  - Return 202 Accepted so the ESP32 doesn't have to wait for AI inference.

Routes:
    POST /api/v1/events/audio/{device_id}
    POST /api/v1/events/fall/{device_id}
    POST /api/v1/events/panic/{device_id}
    POST /api/v1/status/{device_id}
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.core.config import settings
from app.core.logging import logger
from app.core.security import verify_token
from app.db.postgres import get_db
from app.models.models import Alert, Device
from app.schemas.schemas import GPSReading
from app.services.notification_service import NotificationService
from app.ws.connection_manager import manager
from ai_engine.engine import ai_engine

router = APIRouter()


# ─────────────────────────────────────────────────────────────────────────────
# Shared device-key auth dependency (mirrors telemetry.py authenticate_device)
# ─────────────────────────────────────────────────────────────────────────────
async def _verify_device_key(
    x_device_key: Optional[str] = Header(None, alias="X-Device-Key"),
    authorization: Optional[str] = Header(None),
) -> str:
    """
    Accept either:
      X-Device-Key: <provisioning_secret>   (ESP32 convenience header)
      Authorization: Bearer <device_jwt>    (device-scoped JWT from /devices/register)
    Returns the authenticated device_id or "ESP32_MOCK" for the provisioning key.
    """
    if x_device_key and x_device_key == settings.DEVICE_PROVISIONING_SECRET:
        return "ESP32_MOCK"

    if authorization and authorization.startswith("Bearer "):
        token = authorization[len("Bearer "):]
        payload = verify_token(token)
        if payload and "device:telemetry:write" in payload.get("scopes", []):
            return payload.get("device_id", "unknown")

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Missing or invalid X-Device-Key / Bearer token.",
    )


def _alert_ws_event(alert: Alert) -> dict:
    return {
        "type": "alert.new",
        "data": {
            "id": alert.id,
            "device_id": alert.device_id,
            "type": alert.type,
            "severity": alert.severity,
            "timestamp": alert.timestamp.isoformat(),
            "message": alert.message,
            "gps_lat": alert.gps_lat,
            "gps_lng": alert.gps_lng,
            "acknowledged": alert.acknowledged,
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic schemas (spec §3.4)
# ─────────────────────────────────────────────────────────────────────────────
class AudioEventPayload(BaseModel):
    device_id: str
    timestamp: Optional[datetime] = None
    confidence: float = 0.0          # on-device classifier confidence 0–1
    audio_clip_url: Optional[str] = None


class FallEventPayload(BaseModel):
    device_id: str
    timestamp: Optional[datetime] = None
    impact_g: float = 0.0
    post_fall_inactivity_s: int = 0


class PanicEventPayload(BaseModel):
    device_id: str
    timestamp: Optional[datetime] = None
    gps: Optional[GPSReading] = None
    audio_clip_url: Optional[str] = None


class DeviceStatusPayload(BaseModel):
    device_id: str
    battery_pct: Optional[int] = None
    signal_strength: Optional[str] = None
    firmware_version: Optional[str] = None
    connection_mode: Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
# POST /events/audio/{device_id}
# ─────────────────────────────────────────────────────────────────────────────
@router.post("/audio/{device_id}", status_code=status.HTTP_202_ACCEPTED)
async def ingest_audio_event(
    device_id: str,
    payload: AudioEventPayload,
    db: AsyncSession = Depends(get_db),
    _auth: str = Depends(_verify_device_key),
):
    if _auth != "ESP32_MOCK" and payload.device_id != device_id:
        raise HTTPException(status_code=403, detail="Device ID mismatch.")

    logger.info(f"Audio event received: device={device_id} conf={payload.confidence:.2f}")

    snippet = payload.audio_clip_url or "audio_event_rest"
    result = ai_engine.distress(snippet=snippet, device_confidence=payload.confidence)

    if result.label == "confirmed_distress":
        res = await db.execute(select(Device).where(Device.id == device_id))
        device = res.scalars().first()

        alert = Alert(
            device_id=device_id,
            type="distress",
            severity="high",
            message=f"Distress audio event (confidence {result.confidence:.0%})",
            timestamp=payload.timestamp or datetime.utcnow(),
        )
        db.add(alert)
        await db.commit()
        await db.refresh(alert)

        await manager.broadcast_to_device(device_id, _alert_ws_event(alert))
        if device:
            await NotificationService.dispatch_critical_alert(
                device_name=device.name, alert_type="distress", details=alert.message or ""
            )

    return {
        "status": "accepted",
        "distress_label": result.label,
        "confidence": result.confidence,
    }


# ─────────────────────────────────────────────────────────────────────────────
# POST /events/fall/{device_id}
# ─────────────────────────────────────────────────────────────────────────────
@router.post("/fall/{device_id}", status_code=status.HTTP_202_ACCEPTED)
async def ingest_fall_event(
    device_id: str,
    payload: FallEventPayload,
    db: AsyncSession = Depends(get_db),
    _auth: str = Depends(_verify_device_key),
):
    if _auth != "ESP32_MOCK" and payload.device_id != device_id:
        raise HTTPException(status_code=403, detail="Device ID mismatch.")

    logger.info(
        f"Fall event received: device={device_id} impact={payload.impact_g}g "
        f"inactivity={payload.post_fall_inactivity_s}s"
    )

    result = ai_engine.fall(
        impact_g=payload.impact_g,
        inactivity_s=payload.post_fall_inactivity_s,
    )

    if result.label in ("confirmed_fall", "possible_fall"):
        res = await db.execute(select(Device).where(Device.id == device_id))
        device = res.scalars().first()

        severity = "critical" if result.label == "confirmed_fall" else "high"
        alert = Alert(
            device_id=device_id,
            type="fall",
            severity=severity,
            message=f"Fall event: {result.label} (impact {payload.impact_g:.1f}g, "
                    f"inactivity {payload.post_fall_inactivity_s}s, "
                    f"confidence {result.confidence:.0%})",
            timestamp=payload.timestamp or datetime.utcnow(),
        )
        db.add(alert)
        await db.commit()
        await db.refresh(alert)

        await manager.broadcast_to_device(device_id, _alert_ws_event(alert))
        if device:
            await NotificationService.dispatch_critical_alert(
                device_name=device.name, alert_type="fall", details=alert.message or ""
            )

    return {
        "status": "accepted",
        "fall_label": result.label,
        "confidence": result.confidence,
    }


# ─────────────────────────────────────────────────────────────────────────────
# POST /events/panic/{device_id}
# ─────────────────────────────────────────────────────────────────────────────
@router.post("/panic/{device_id}", status_code=status.HTTP_202_ACCEPTED)
async def ingest_panic_event(
    device_id: str,
    payload: PanicEventPayload,
    db: AsyncSession = Depends(get_db),
    _auth: str = Depends(_verify_device_key),
):
    if _auth != "ESP32_MOCK" and payload.device_id != device_id:
        raise HTTPException(status_code=403, detail="Device ID mismatch.")

    logger.warning(f"PANIC event received: device={device_id}")

    res = await db.execute(select(Device).where(Device.id == device_id))
    device = res.scalars().first()

    alert = Alert(
        device_id=device_id,
        type="panic",
        severity="critical",
        message="SOS Panic button pressed on wearable.",
        gps_lat=payload.gps.lat if payload.gps else None,
        gps_lng=payload.gps.lng if payload.gps else None,
        timestamp=payload.timestamp or datetime.utcnow(),
    )
    db.add(alert)
    await db.commit()
    await db.refresh(alert)

    await manager.broadcast_to_device(device_id, _alert_ws_event(alert))
    if device:
        await NotificationService.dispatch_critical_alert(
            device_name=device.name,
            alert_type="panic",
            details="SOS Panic button pressed on wearable device.",
        )

    return {"status": "dispatched", "alert_id": alert.id}


# ─────────────────────────────────────────────────────────────────────────────
# POST /status/{device_id}  — device heartbeat / health check-in
# ─────────────────────────────────────────────────────────────────────────────
@router.post("/status/{device_id}", status_code=status.HTTP_202_ACCEPTED)
async def ingest_device_status(
    device_id: str,
    payload: DeviceStatusPayload,
    db: AsyncSession = Depends(get_db),
    _auth: str = Depends(_verify_device_key),
):
    res = await db.execute(select(Device).where(Device.id == device_id))
    device = res.scalars().first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not registered.")

    if payload.battery_pct is not None:
        device.battery_pct = payload.battery_pct
    if payload.firmware_version:
        device.firmware_version = payload.firmware_version
    if payload.connection_mode:
        device.connection_mode = payload.connection_mode
    device.last_seen = datetime.utcnow()
    db.add(device)
    await db.commit()

    await manager.broadcast_to_device(device_id, {
        "type": "device.status",
        "data": {
            "device_id": device.id,
            "name": device.name,
            "battery_pct": device.battery_pct,
            "firmware_version": device.firmware_version,
            "connection_mode": device.connection_mode,
            "last_seen": device.last_seen.isoformat(),
            "is_online": True,
        },
    })

    return {"status": "ok", "device_id": device_id}
