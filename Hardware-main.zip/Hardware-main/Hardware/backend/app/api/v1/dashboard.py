from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from datetime import datetime, timedelta

from app.db.postgres import get_db
from app.db.dynamo import DynamoDBClient
from app.models.models import Device, Geofence, Alert, WearerRequest
from app.schemas.schemas import AlertResponse, GeofenceResponse, NonVerbalResponse
from app.core.security import get_current_user

router = APIRouter()


@router.get("/summary/{device_id}")
async def get_dashboard_summary(
    device_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    # Verify device exists
    dev_res = await db.execute(select(Device).where(Device.id == device_id))
    device = dev_res.scalars().first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    # Active geofences
    gf_res = await db.execute(
        select(Geofence).where(
            Geofence.device_id == device_id, Geofence.is_active == True
        )
    )
    geofences = gf_res.scalars().all()

    # Last 10 alerts
    alert_res = await db.execute(
        select(Alert)
        .where(Alert.device_id == device_id)
        .order_by(Alert.timestamp.desc())
        .limit(10)
    )
    alerts = alert_res.scalars().all()

    # Last 5 non-verbal requests
    req_res = await db.execute(
        select(WearerRequest)
        .where(WearerRequest.device_id == device_id)
        .order_by(WearerRequest.timestamp.desc())
        .limit(5)
    )
    requests = req_res.scalars().all()

    # Latest telemetry from DynamoDB
    telemetry_history = await DynamoDBClient.get_telemetry_history(device_id, seconds=300)
    latest_reading = telemetry_history[-1] if telemetry_history else None

    is_online = (datetime.utcnow() - device.last_seen) < timedelta(seconds=15)

    return {
        "device": {
            "device_id": device.id,
            "name": device.name,
            "firmware_version": device.firmware_version,
            "battery_pct": device.battery_pct,
            "connection_mode": device.connection_mode,
            "last_seen": device.last_seen.isoformat(),
            "is_online": is_online,
        },
        # Pydantic v2: use model_validate(obj, from_attributes=True)
        "geofences": [
            GeofenceResponse.model_validate(gf, from_attributes=True).model_dump()
            for gf in geofences
        ],
        "alerts": [
            AlertResponse.model_validate(al, from_attributes=True).model_dump()
            for al in alerts
        ],
        "nonverbal_requests": [
            NonVerbalResponse.model_validate(r, from_attributes=True).model_dump()
            for r in requests
        ],
        "latest_telemetry": latest_reading,
    }
