"""
Telemetry ingestion + WebSocket streaming endpoints.

Device authentication accepts either:
  - X-AutiGuard-Key: <DEVICE_PROVISIONING_SECRET>  (ESP32 header convenience)
  - Authorization: Bearer <device_jwt>              (scoped token from /devices/register)

Rate limit: 120 req/min per IP (≈ 2 req/s, well above the 5–10 s ESP32 interval).
"""
from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, WebSocket, WebSocketDisconnect, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional

from app.core.config import settings
from app.core.limiter import limiter  # shared slowapi limiter — no circular import
from app.core.logging import logger
from app.core.security import verify_token, get_current_user
from app.db.dynamo import DynamoDBClient
from app.db.postgres import get_db
from app.schemas.schemas import TelemetryPacket
from app.services.ingestion_service import IngestionService
from app.ws.connection_manager import manager

router = APIRouter()
_bearer = HTTPBearer(auto_error=False)


# ─────────────────────────────────────────────────────────────────────────────
# Device auth dependency
# ─────────────────────────────────────────────────────────────────────────────
async def authenticate_device(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_bearer),
    x_autiguard_key: Optional[str] = Header(None, alias="X-AutiGuard-Key"),
    x_device_key: Optional[str] = Header(None, alias="X-Device-Key"),
) -> str:
    # Provisioning-secret shortcut (ESP32 convenience)
    for key in (x_autiguard_key, x_device_key):
        if key and key == settings.DEVICE_PROVISIONING_SECRET:
            return "ESP32_MOCK"

    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing Authorization header or X-Device-Key.",
        )

    payload = verify_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token.")

    if "device:telemetry:write" not in payload.get("scopes", []):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient token scope.")

    return payload.get("device_id", "unknown")


# ─────────────────────────────────────────────────────────────────────────────
# POST /api/v1/telemetry/ingest  — main ingest endpoint
# ─────────────────────────────────────────────────────────────────────────────
@router.post("/ingest", status_code=status.HTTP_202_ACCEPTED)
@limiter.limit(settings.RATE_LIMIT_INGEST)
async def ingest_telemetry(
    request: Request,          # required by slowapi
    packet: TelemetryPacket,
    db: AsyncSession = Depends(get_db),
    device_id: str = Depends(authenticate_device),
):
    if device_id != "ESP32_MOCK" and packet.device_id != device_id:
        raise HTTPException(status_code=403, detail="Device ID mismatch with token.")

    # Phase 1 — immediate (synchronous)
    await IngestionService.process_immediate_ingest(packet, db)
    # Phase 2 — enqueue for AI / broadcast
    await IngestionService.queue_telemetry(packet)

    return {"status": "accepted", "timestamp": datetime.utcnow().isoformat()}


# ─────────────────────────────────────────────────────────────────────────────
# GET /api/v1/telemetry/history/{device_id}
# ─────────────────────────────────────────────────────────────────────────────
@router.get("/history/{device_id}")
async def get_telemetry_history(
    device_id: str,
    seconds: int = Query(3600, ge=60, le=86400),
    current_user=Depends(get_current_user),
):
    history = await DynamoDBClient.get_telemetry_history(device_id, seconds)
    return {
        "device_id": device_id,
        "seconds_requested": seconds,
        "count": len(history),
        "data": history,
    }


# ─────────────────────────────────────────────────────────────────────────────
# WS /api/v1/telemetry/ws/v1/devices/{device_id}?token=<jwt>
# ─────────────────────────────────────────────────────────────────────────────
@router.websocket("/ws/v1/devices/{device_id}")
async def websocket_endpoint(websocket: WebSocket, device_id: str):
    token = websocket.query_params.get("token")
    if not token:
        logger.warning(f"WS rejected for {device_id}: missing token.")
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    if not verify_token(token):
        logger.warning(f"WS rejected for {device_id}: invalid token.")
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    await manager.connect(websocket, device_id)
    try:
        while True:
            data = await websocket.receive_text()
            logger.debug(f"WS message from dashboard client ({device_id}): {data}")
    except WebSocketDisconnect:
        manager.disconnect(websocket, device_id)
    except Exception as exc:
        logger.error(f"WS error on room {device_id}: {exc}")
        manager.disconnect(websocket, device_id)
