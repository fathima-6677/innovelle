from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from datetime import datetime, timedelta
from typing import List

from app.db.postgres import get_db
from app.models.models import Device, User, Geofence
from app.schemas.schemas import DeviceRegister, DeviceResponse, DeviceConfigResponse, GeofenceResponse
from fastapi.security import OAuth2PasswordBearer
from app.core.config import settings
from app.core.security import create_access_token, get_current_user, verify_token, RoleChecker

oauth2_scheme_optional = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_STR}/users/login", auto_error=False)

async def get_current_user_optional(
    token: str = Depends(oauth2_scheme_optional),
    db: AsyncSession = Depends(get_db)
):
    if not token:
        return None
    try:
        payload = verify_token(token)
        if not payload:
            return None
        user_email = payload.get("sub")
        result = await db.execute(select(User).where(User.email == user_email))
        return result.scalars().first()
    except Exception:
        return None

router = APIRouter()

# 3.1 Device registration / provisioning endpoint
@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register_device(
    payload: DeviceRegister, 
    db: AsyncSession = Depends(get_db),
    # Allow registration either authenticated (linked to caregiver) or unauthenticated (factory registration)
    current_user = Depends(get_current_user_optional)
):
    # Validate the factory provisioning secret
    if payload.provisioning_secret != settings.DEVICE_PROVISIONING_SECRET:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid device provisioning secret key."
        )

    # Check if device is already registered by serial number
    result = await db.execute(select(Device).where(Device.serial_number == payload.serial_number))
    device = result.scalars().first()
    
    if not device:
        # Create new device mapping
        device = Device(
            serial_number=payload.serial_number,
            name=payload.name,
            owner_id=current_user.id if current_user else None,
            firmware_version="1.0.0",
            battery_pct=100,
            connection_mode="WIFI",
            last_seen=datetime.utcnow()
        )
        db.add(device)
    else:
        # Update existing device assignment to the current user
        if current_user:
            device.owner_id = current_user.id
            device.name = payload.name
            
    await db.commit()
    await db.refresh(device)
    
    # Issue a long-lived JWT token scoped for telemetry write only
    device_token_data = {
        "sub": f"device:{device.id}",
        "device_id": device.id,
        "scopes": ["device:telemetry:write"]
    }
    
    # Scoped device JWT token (expires in 1 year)
    device_token = create_access_token(
        data=device_token_data, 
        expires_delta=timedelta(minutes=settings.DEVICE_TOKEN_EXPIRE_MINUTES)
    )
    
    return {
        "device_id": device.id,
        "name": device.name,
        "device_token": device_token,
        "token_type": "bearer"
    }

# 3.5 Device config endpoint: pulls geofences + configurations on boot
@router.get("/{device_id}/config", response_model=DeviceConfigResponse)
async def get_device_config(device_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Device).where(Device.id == device_id))
    device = result.scalars().first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found."
        )
        
    # Get active geofences for this device
    gf_result = await db.execute(
        select(Geofence).where(Geofence.device_id == device_id, Geofence.is_active == True)
    )
    geofences = gf_result.scalars().all()
    
    return DeviceConfigResponse(
        device_id=device.id,
        name=device.name,
        geofences=[GeofenceResponse.from_attributes(gf) for gf in geofences]
    )

# Get status details of a device
@router.get("/{device_id}/status")
async def get_device_status(device_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Device).where(Device.id == device_id))
    device = result.scalars().first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    # Calculate connection status (online if seen in the last 15 seconds)
    is_online = (datetime.utcnow() - device.last_seen) < timedelta(seconds=15)
    
    return {
        "device_id": device.id,
        "name": device.name,
        "firmware_version": device.firmware_version,
        "battery_pct": device.battery_pct,
        "connection_mode": device.connection_mode,
        "last_seen": device.last_seen.isoformat(),
        "is_online": is_online
    }

# Get list of devices linked to the current user
@router.get("/list", response_model=List[DeviceResponse])
async def list_devices(
    current_user: User = Depends(get_current_user), 
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(Device).where(Device.owner_id == current_user.id))
    devices = result.scalars().all()
    return devices

# Unpair device endpoint
@router.delete("/{device_id}", status_code=status.HTTP_204_NO_CONTENT)
async def unpair_device(
    device_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(Device).where(Device.id == device_id, Device.owner_id == current_user.id))
    device = result.scalars().first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found or not owned by current user"
        )
    
    device.owner_id = None
    db.add(device)
    await db.commit()
    return None

