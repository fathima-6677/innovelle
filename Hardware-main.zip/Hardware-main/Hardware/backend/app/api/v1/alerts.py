from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from datetime import datetime
from typing import List

from app.db.postgres import get_db
from app.models.models import Alert, Device, User
from app.schemas.schemas import AlertPanicRequest, AlertResponse
from app.core.security import get_current_user
from app.services.notification_service import NotificationService
from app.ws.connection_manager import manager

router = APIRouter()

# 3.5 Immediate SOS Panic endpoint
@router.post("/panic", status_code=status.HTTP_201_CREATED)
async def trigger_panic(
    payload: AlertPanicRequest,
    db: AsyncSession = Depends(get_db)
):
    # Verify device exists
    result = await db.execute(select(Device).where(Device.id == payload.device_id))
    device = result.scalars().first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found."
        )

    # Save to PostgreSQL Alerts table
    alert = Alert(
        device_id=payload.device_id,
        type="panic",
        severity="critical",
        message=payload.message,
        gps_lat=payload.gps_lat,
        gps_lng=payload.gps_lng,
        timestamp=datetime.utcnow()
    )
    db.add(alert)
    await db.commit()
    await db.refresh(alert)

    # Broadcast updated alert to WebSocket room
    alert_event = {
        "type": "alert.new",
        "data": {
            "id": alert.id,
            "device_id": alert.device_id,
            "type": alert.type,
            "severity": alert.severity,
            "timestamp": alert.timestamp.isoformat(),
            "message": alert.message,
            "gps_lat": alert.gps_lat,
            "gps_lng": alert.gps_lng,
            "acknowledged": alert.acknowledged
        }
    }
    await manager.broadcast_to_device(payload.device_id, alert_event)

    # Dispatch immediate notifications
    await NotificationService.dispatch_critical_alert(
        device_name=device.name,
        alert_type="panic",
        details=payload.message or "Panic button pressed"
    )

    return {"status": "dispatched", "alert_id": alert.id}

# List all alerts for a device
@router.get("/list/{device_id}", response_model=List[AlertResponse])
async def list_alerts(
    device_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(Alert).where(Alert.device_id == device_id).order_by(Alert.timestamp.desc())
    )
    alerts = result.scalars().all()
    return alerts

# 6.3 Acknowledge/escalate alert workflow
@router.patch("/{alert_id}/acknowledge", response_model=AlertResponse)
async def acknowledge_alert(
    alert_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Alert).where(Alert.id == alert_id))
    alert = result.scalars().first()
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alert not found"
        )

    alert.acknowledged = True
    alert.acknowledged_by = current_user.id
    alert.acknowledged_at = datetime.utcnow()
    
    db.add(alert)
    await db.commit()
    await db.refresh(alert)

    # Broadcast updated alert status to all connected dashboard WebSockets
    await manager.broadcast_to_device(alert.device_id, {
        "type": "alert.acknowledged",
        "data": {
            "id": alert.id,
            "device_id": alert.device_id,
            "acknowledged": True,
            "acknowledged_by": alert.acknowledged_by,
            "acknowledged_at": alert.acknowledged_at.isoformat()
        }
    })

    return alert
