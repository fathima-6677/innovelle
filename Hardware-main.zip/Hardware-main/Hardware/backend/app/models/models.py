import uuid
from datetime import datetime
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.db.postgres import Base

def generate_uuid():
    return str(uuid.uuid4())

class User(Base):
    __tablename__ = "users"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, default="caregiver", nullable=False)  # admin, guardian, caregiver, clinician, emergency_responder
    name = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    devices = relationship("Device", back_populates="owner")

class Device(Base):
    __tablename__ = "devices"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    serial_number = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    owner_id = Column(String, ForeignKey("users.id"), nullable=True)
    firmware_version = Column(String, default="1.0.0")
    battery_pct = Column(Integer, default=100)
    connection_mode = Column(String, default="WIFI")  # BLE, WIFI, LTE
    last_seen = Column(DateTime, default=datetime.utcnow)
    provisioned_at = Column(DateTime, default=datetime.utcnow)
    
    owner = relationship("User", back_populates="devices")
    geofences = relationship("Geofence", back_populates="device", cascade="all, delete-orphan")
    alerts = relationship("Alert", back_populates="device", cascade="all, delete-orphan")
    qr_identity = relationship("QRIdentity", uselist=False, back_populates="device", cascade="all, delete-orphan")

class Geofence(Base):
    __tablename__ = "geofences"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    device_id = Column(String, ForeignKey("devices.id"), nullable=False)
    name = Column(String, nullable=False)
    center_lat = Column(Float, nullable=False)
    center_lng = Column(Float, nullable=False)
    radius_meters = Column(Float, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    device = relationship("Device", back_populates="geofences")

class Alert(Base):
    __tablename__ = "alerts"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    device_id = Column(String, ForeignKey("devices.id"), nullable=False)
    type = Column(String, nullable=False)  # panic, fall, distress, stress, geofence
    severity = Column(String, nullable=False)  # critical, high, warning, info
    timestamp = Column(DateTime, default=datetime.utcnow)
    message = Column(Text, nullable=True)
    gps_lat = Column(Float, nullable=True)
    gps_lng = Column(Float, nullable=True)
    acknowledged = Column(Boolean, default=False)
    acknowledged_by = Column(String, ForeignKey("users.id"), nullable=True)
    acknowledged_at = Column(DateTime, nullable=True)
    
    device = relationship("Device", back_populates="alerts")

class QRIdentity(Base):
    __tablename__ = "qr_identities"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    device_id = Column(String, ForeignKey("devices.id"), nullable=False, unique=True)
    encrypted_payload = Column(Text, nullable=False)
    rotated_at = Column(DateTime, default=datetime.utcnow)
    
    device = relationship("Device", back_populates="qr_identity")

class ScanLog(Base):
    __tablename__ = "scan_logs"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    device_id = Column(String, ForeignKey("devices.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    location_lat = Column(Float, nullable=True)
    location_lng = Column(Float, nullable=True)
    accessor_role = Column(String, nullable=False)
    notification_sent = Column(Boolean, default=False)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    action = Column(String, nullable=False)
    performed_by_user_id = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    details = Column(Text, nullable=True)

class WearerRequest(Base):
    __tablename__ = "wearer_requests"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    device_id = Column(String, ForeignKey("devices.id"), nullable=False)
    message = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

