import os
import json
import boto3
from datetime import datetime, timedelta
from typing import List, Dict, Any
from botocore.exceptions import ClientError
from app.core.config import settings
from app.core.logging import logger

# Simulated in-memory database for local/offline testing
_simulated_dynamo_db: List[Dict[str, Any]] = []
MOCK_FILE_PATH = "./autiguard_dynamo_mock.json"

# Load mock data from file if it exists to maintain parity on restarts
if os.path.exists(MOCK_FILE_PATH):
    try:
        with open(MOCK_FILE_PATH, "r") as f:
            _simulated_dynamo_db = json.load(f)
            logger.info("Loaded simulated DynamoDB state from file.")
    except Exception as e:
        logger.error(f"Error loading mock DynamoDB file: {e}")

def save_mock_db():
    try:
        with open(MOCK_FILE_PATH, "w") as f:
            json.dump(_simulated_dynamo_db, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to write mock DynamoDB file: {e}")

# DynamoDB client setup
dynamodb = None
table = None

if not settings.USE_LOCAL_DYNAMO_MOCK and settings.AWS_ACCESS_KEY_ID and settings.AWS_SECRET_ACCESS_KEY:
    try:
        dynamodb = boto3.resource(
            "dynamodb",
            region_name=settings.AWS_REGION,
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
        )
        table = dynamodb.Table(settings.DYNAMODB_TABLE_NAME)
        logger.info(f"Connected to AWS DynamoDB Table: {settings.DYNAMODB_TABLE_NAME}")
    except Exception as e:
        logger.error(f"Failed to initialize AWS DynamoDB: {e}. Falling back to Local Mock.")
        table = None

class DynamoDBClient:
    @staticmethod
    async def create_table_if_not_exists():
        if table is not None:
            try:
                # Basic check
                table.table_status
            except ClientError as e:
                if e.response["Error"]["Code"] == "ResourceNotFoundException":
                    logger.info(f"Creating DynamoDB Table '{settings.DYNAMODB_TABLE_NAME}' on AWS...")
                    # Create table command
                    try:
                        dynamodb.create_table(
                            TableName=settings.DYNAMODB_TABLE_NAME,
                            KeySchema=[
                                {"AttributeName": "device_id", "KeyType": "HASH"},  # Partition key
                                {"AttributeName": "timestamp", "KeyType": "RANGE"}  # Sort key
                            ],
                            AttributeDefinitions=[
                                {"AttributeName": "device_id", "AttributeType": "S"},
                                {"AttributeName": "timestamp", "AttributeType": "S"}
                            ],
                            BillingMode="PAY_PER_REQUEST"
                        )
                        logger.info("DynamoDB table creation initiated.")
                    except Exception as err:
                        logger.error(f"Failed to create DynamoDB table: {err}")
                else:
                    logger.error(f"DynamoDB error: {e}")
        else:
            logger.info("DynamoDB Simulator initialized (no AWS connection required).")

    @staticmethod
    async def put_telemetry(packet: Dict[str, Any]):
        # Parse datetime to ISO strings for serialization
        payload = packet.copy()
        if isinstance(payload.get("timestamp"), datetime):
            payload["timestamp"] = payload["timestamp"].isoformat()
            
        if table is not None:
            try:
                table.put_item(Item=payload)
            except Exception as e:
                logger.error(f"Failed to put item in AWS DynamoDB: {e}")
                # Fallback to local
                _simulated_dynamo_db.append(payload)
                save_mock_db()
        else:
            _simulated_dynamo_db.append(payload)
            # Cap local log size at 5000 items
            if len(_simulated_dynamo_db) > 5000:
                _simulated_dynamo_db.pop(0)
            save_mock_db()

    @staticmethod
    async def get_telemetry_history(device_id: str, seconds: int) -> List[Dict[str, Any]]:
        threshold_time = datetime.utcnow() - timedelta(seconds=seconds)
        
        if table is not None:
            try:
                # Query AWS DynamoDB
                # KeyConditionExpression: device_id = :d AND timestamp >= :t
                from boto3.dynamodb.conditions import Key, Attr
                response = table.query(
                    KeyConditionExpression=Key("device_id").eq(device_id) & Key("timestamp").gte(threshold_time.isoformat())
                )
                return response.get("Items", [])
            except Exception as e:
                logger.error(f"Failed to query AWS DynamoDB: {e}")
                # Fallback to mock search
                pass
                
        # Query Local Mock Database
        results = []
        for item in _simulated_dynamo_db:
            if item.get("device_id") == device_id:
                try:
                    item_time = datetime.fromisoformat(item["timestamp"])
                    if item_time >= threshold_time:
                        results.append(item)
                except ValueError:
                    pass
                    
        # Sort chronologically by timestamp
        results.sort(key=lambda x: x.get("timestamp", ""))
        return results
