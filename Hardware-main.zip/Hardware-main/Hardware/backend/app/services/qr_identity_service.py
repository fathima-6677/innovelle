import json
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
from app.core.config import settings
from app.core.logging import logger

class QRIdentityService:
    @staticmethod
    def _get_fernet() -> Fernet:
        # settings.QR_AES_KEY must be a 32-byte url-safe base64 key
        return Fernet(settings.QR_AES_KEY.encode())

    @classmethod
    def generate_encrypted_qr(cls, device_id: str, wearer_name: str) -> str:
        """
        Encrypts wearer details into a dynamic payload that is valid for 24h.
        """
        data = {
            "device_id": device_id,
            "wearer_name": wearer_name,
            "created_at": datetime.utcnow().isoformat(),
            # Crucial medical and identification payload fields
            "emergency_contact": "Sarah Connor (Guardian)",
            "emergency_phone": "+14155552671",
            "critical_medical_notes": "Wearer has Autism (ASD). Non-verbal when stressed. Sensitive to sirens/flashing lights.",
            "stress_trend_summary": "Stable. HRV baseline 58ms, no meltdowns today.",
            "full_medical_record": "Patient ID: AS-91182. Diagnosis: Autism Spectrum Disorder (Level 2). Meds: Guanfacine 1mg QD."
        }
        
        json_data = json.dumps(data)
        f = cls._get_fernet()
        encrypted_bytes = f.encrypt(json_data.encode())
        return encrypted_bytes.decode()

    @classmethod
    def decrypt_and_filter_qr(cls, encrypted_payload: str, accessor_role: str) -> dict:
        """
        Decrypts the payload and filters fields hierarchically based on the accessor's RBAC role.
        """
        f = cls._get_fernet()
        decrypted_bytes = f.decrypt(encrypted_payload.encode())
        data = json.loads(decrypted_bytes.decode())
        
        # Check payload expiration (24h)
        created_at = datetime.fromisoformat(data["created_at"])
        if datetime.utcnow() - created_at > timedelta(hours=24):
            logger.warning("Attempted to decrypt expired QR code payload")
            raise ValueError("QR code has expired. Please refresh the display on the wearable device.")

        # Hierarchical filtering
        filtered_info = {
            "device_id": data["device_id"],
            "wearer_name": data["wearer_name"],
            "role_level": accessor_role
        }

        # Role levels: guardian, caregiver, clinician, emergency_responder, admin
        if accessor_role in ("emergency_responder", "caregiver", "clinician", "guardian", "admin"):
            # Emergency responder gets safety + contact information
            filtered_info["emergency_contact"] = data["emergency_contact"]
            filtered_info["emergency_phone"] = data["emergency_phone"]
            filtered_info["critical_medical_notes"] = data["critical_medical_notes"]

        if accessor_role in ("clinician", "guardian", "admin"):
            # Clinician gets stress statistics and medication details
            filtered_info["stress_trend_summary"] = data["stress_trend_summary"]
            
        if accessor_role in ("guardian", "admin"):
            # Guardians get the complete medical file
            filtered_info["full_medical_record"] = data["full_medical_record"]

        return filtered_info
