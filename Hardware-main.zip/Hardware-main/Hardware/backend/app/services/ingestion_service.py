"""
Ingestion Service — two-phase pipeline for all incoming telemetry.

Phase 1 (synchronous, inside the HTTP request):
  - Write raw packet to DynamoDB
  - Update Device row in PostgreSQL (last_seen, battery, connection_mode)
  - Server-side geofence breach check → Alert + WS broadcast

Phase 2 (async background queue worker):
  - Fall SVM detection
  - Stress RF detection + LSTM history update
  - Audio distress CNN detection
  - Behavioral LSTM trend
  - Broadcast telemetry.update to WebSocket room

Both phases call the same ai_engine facade so real models can be
swapped in without touching this file.
"""
import asyncio
from datetime import datetime

from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.postgres import SessionLocal
from app.db.dynamo import DynamoDBClient
from app.models.models import Device, Geofence, Alert
from app.schemas.schemas import TelemetryPacket
from app.services.geofence_engine import GeofenceEngine
from app.services.notification_service import NotificationService
from app.ws.connection_manager import manager
from app.core.logging import logger

# New unified AI engine — replaces the old MLInferenceClient
from ai_engine.engine import ai_engine

# ---------------------------------------------------------------------------
# Global async queue (populated by REST / MQTT ingestion, drained by worker)
# ---------------------------------------------------------------------------
telemetry_queue: asyncio.Queue[TelemetryPacket] = asyncio.Queue()


# ---------------------------------------------------------------------------
# Phase 1 — synchronous immediate processing
# ---------------------------------------------------------------------------
class IngestionService:

    @staticmethod
    async def queue_telemetry(packet: TelemetryPacket) -> None:
        await telemetry_queue.put(packet)
        logger.info(f"Queued telemetry packet for device: {packet.device_id}")

    @staticmethod
    async def process_immediate_ingest(packet: TelemetryPacket, db: AsyncSession) -> None:
        logger.info(f"Immediate ingest for device: {packet.device_id}")

        # 1. Write to DynamoDB
        await DynamoDBClient.put_telemetry(packet.model_dump())

        # 2. Update Device row
        result = await db.execute(select(Device).where(Device.id == packet.device_id))
        device = result.scalars().first()
        if not device:
            logger.warning(f"Unknown device ID in telemetry: {packet.device_id}")
            return

        device.last_seen = datetime.utcnow()
        device.battery_pct = packet.battery_pct
        device.connection_mode = packet.connection_mode
        db.add(device)

        await manager.broadcast_to_device(device.id, {
            "type": "device.status",
            "data": {
                "device_id": device.id,
                "name": device.name,
                "battery_pct": device.battery_pct,
                "connection_mode": device.connection_mode,
                "last_seen": device.last_seen.isoformat(),
                "is_online": True,
            },
        })

        # 3. Geofence breach check
        if packet.gps:
            gf_result = await db.execute(
                select(Geofence).where(
                    Geofence.device_id == packet.device_id,
                    Geofence.is_active == True,
                )
            )
            for gf in gf_result.scalars().all():
                if GeofenceEngine.is_outside_geofence(
                    gps_lat=packet.gps.lat,
                    gps_lng=packet.gps.lng,
                    center_lat=gf.center_lat,
                    center_lng=gf.center_lng,
                    radius_meters=gf.radius_meters,
                ):
                    logger.warning(f"Geofence breach: device={packet.device_id} zone='{gf.name}'")
                    msg = f"Wearer has exited safe zone '{gf.name}'."
                    alert = Alert(
                        device_id=packet.device_id,
                        type="geofence",
                        severity="critical",
                        message=msg,
                        gps_lat=packet.gps.lat,
                        gps_lng=packet.gps.lng,
                        timestamp=datetime.utcnow(),
                    )
                    db.add(alert)
                    await db.commit()
                    await manager.broadcast_to_device(packet.device_id, _alert_event(alert))
                    await NotificationService.dispatch_critical_alert(
                        device_name=device.name, alert_type="geofence", details=msg
                    )

        await db.commit()


# ---------------------------------------------------------------------------
# Phase 2 — background queue worker
# ---------------------------------------------------------------------------
async def telemetry_processing_worker() -> None:
    logger.info("Telemetry background worker started.")
    while True:
        packet: TelemetryPacket = await telemetry_queue.get()
        try:
            async with SessionLocal() as db:
                res = await db.execute(select(Device).where(Device.id == packet.device_id))
                device = res.scalars().first()
                if not device:
                    telemetry_queue.task_done()
                    continue

                ax = packet.accel.x if packet.accel else 0.0
                ay = packet.accel.y if packet.accel else 0.0
                az = packet.accel.z if packet.accel else 1.0

                # ── 1. Fall detection ────────────────────────────────
                fall_result = ai_engine.fall(ax=ax, ay=ay, az=az)
                if fall_result.label == "confirmed_fall":
                    alert = Alert(
                        device_id=packet.device_id,
                        type="fall",
                        severity="critical",
                        message=f"Fall confirmed (confidence {fall_result.confidence:.0%})",
                        gps_lat=packet.gps.lat if packet.gps else None,
                        gps_lng=packet.gps.lng if packet.gps else None,
                        timestamp=datetime.utcnow(),
                    )
                    db.add(alert)
                    await db.commit()
                    await manager.broadcast_to_device(packet.device_id, _alert_event(alert))
                    await NotificationService.dispatch_critical_alert(
                        device_name=device.name,
                        alert_type="fall",
                        details=alert.message or "",
                    )

                # ── 2. Stress detection ──────────────────────────────
                stress_result = ai_engine.stress(
                    hr=packet.heart_rate_bpm,
                    hrv=packet.hrv_ms,
                    ax=ax, ay=ay, az=az,
                )
                # Update LSTM rolling window
                ai_engine.record_stress_score(packet.device_id, stress_result.score)

                if stress_result.label == "high":
                    alert = Alert(
                        device_id=packet.device_id,
                        type="stress",
                        severity="warning",
                        message=f"Elevated stress detected (index {stress_result.score:.1f}/100)",
                        gps_lat=packet.gps.lat if packet.gps else None,
                        gps_lng=packet.gps.lng if packet.gps else None,
                        timestamp=datetime.utcnow(),
                    )
                    db.add(alert)
                    await db.commit()
                    await manager.broadcast_to_device(packet.device_id, _alert_event(alert))
                    await NotificationService.dispatch_critical_alert(
                        device_name=device.name,
                        alert_type="stress",
                        details=alert.message or "",
                    )

                # ── 3. Distress audio detection ──────────────────────
                distress_result = ai_engine.distress(
                    snippet=packet.audio_feature_snippet,
                    device_confidence=0.0,
                )
                if distress_result.label == "confirmed_distress":
                    alert = Alert(
                        device_id=packet.device_id,
                        type="distress",
                        severity="high",
                        message=f"Vocal distress detected (confidence {distress_result.confidence:.0%})",
                        gps_lat=packet.gps.lat if packet.gps else None,
                        gps_lng=packet.gps.lng if packet.gps else None,
                        timestamp=datetime.utcnow(),
                    )
                    db.add(alert)
                    await db.commit()
                    await manager.broadcast_to_device(packet.device_id, _alert_event(alert))
                    await NotificationService.dispatch_critical_alert(
                        device_name=device.name,
                        alert_type="distress",
                        details=alert.message or "",
                    )

                # ── 4. Behavioral LSTM trend ─────────────────────────
                trend_result = ai_engine.behavioral(device_id=packet.device_id)

                # ── 5. Broadcast live telemetry update ───────────────
                await manager.broadcast_to_device(packet.device_id, {
                    "type": "telemetry.update",
                    "data": {
                        "device_id": packet.device_id,
                        "timestamp": packet.timestamp.isoformat(),
                        "battery_pct": packet.battery_pct,
                        "gps": packet.gps.model_dump() if packet.gps else None,
                        "heart_rate_bpm": packet.heart_rate_bpm,
                        "hrv_ms": packet.hrv_ms,
                        "accel": packet.accel.model_dump() if packet.accel else None,
                        "gyro": packet.gyro.model_dump() if packet.gyro else None,
                        "stress_index": stress_result.score,
                        "stress_risk": stress_result.label,
                        "behavioral_trend_risk": trend_result.score,
                        "behavioral_trend_status": trend_result.label,
                    },
                })
                await db.commit()

        except Exception as exc:
            logger.error(f"Background worker error: {exc}", exc_info=True)
        finally:
            telemetry_queue.task_done()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _alert_event(alert: Alert) -> dict:
    return {
        "type": "alert.new",
        "data": {
            "id": alert.id,
            "device_id": alert.device_id,
            "type": alert.type,
            "severity": alert.severity,
            "timestamp": alert.timestamp.isoformat(),
            "message": alert.message,
            "gps_lat": alert.gps_lat,
            "gps_lng": alert.gps_lng,
            "acknowledged": alert.acknowledged,
        },
    }
