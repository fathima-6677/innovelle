"""
MQTT Bridge — subscribes to all AutiGuard device topics and feeds the same
ingestion pipeline used by the REST endpoints.

Topic structure (mirrors the firmware spec):
    autiguard/{device_id}/telemetry    → TelemetryPacket
    autiguard/{device_id}/audio_event  → AudioEventPayload
    autiguard/{device_id}/fall_event   → FallEventPayload
    autiguard/{device_id}/panic        → PanicEventPayload
    autiguard/{device_id}/status       → device heartbeat (battery / signal)

The bridge is started as an asyncio background task inside FastAPI's lifespan
context manager. If MQTT_BROKER_URL is not configured in .env, the bridge
skips gracefully so REST-only mode works without any MQTT infrastructure.
"""
from __future__ import annotations

import asyncio
import json
import re
from datetime import datetime
from typing import Any

from app.core.config import settings
from app.core.logging import logger
from app.db.postgres import SessionLocal
from app.models.models import Alert, Device
from app.schemas.schemas import (
    TelemetryPacket,
    GPSReading,
    AccelReading,
    GyroReading,
)
from app.services.ingestion_service import IngestionService
from app.services.notification_service import NotificationService
from app.ws.connection_manager import manager
from sqlalchemy.future import select

# Topic regex helpers
_TOPIC_RE = re.compile(r"^autiguard/(?P<device_id>[^/]+)/(?P<event_type>[^/]+)$")


async def _handle_telemetry(device_id: str, payload: dict[str, Any]) -> None:
    """Parse and route a telemetry MQTT message through the ingestion pipeline."""
    try:
        gps_raw = payload.get("gps")
        accel_raw = payload.get("imu") or payload.get("accel")
        gyro_raw = payload.get("imu") or payload.get("gyro")

        packet = TelemetryPacket(
            device_id=device_id,
            timestamp=datetime.fromisoformat(payload["timestamp"])
            if "timestamp" in payload
            else datetime.utcnow(),
            battery_pct=int(payload.get("battery_pct", 100)),
            connection_mode=payload.get("connection_mode", "LTE"),
            gps=GPSReading(
                lat=float(gps_raw["lat"]),
                lng=float(gps_raw["lng"]),
                accuracy_m=float(gps_raw.get("accuracy_m", 0)),
            )
            if gps_raw
            else None,
            heart_rate_bpm=payload.get("heart_rate", {}).get("bpm")
            or payload.get("heart_rate_bpm"),
            hrv_ms=payload.get("heart_rate", {}).get("hrv_ms")
            or payload.get("hrv_ms"),
            accel=AccelReading(
                x=float(accel_raw.get("accel_x", accel_raw.get("x", 0))),
                y=float(accel_raw.get("accel_y", accel_raw.get("y", 0))),
                z=float(accel_raw.get("accel_z", accel_raw.get("z", 1))),
            )
            if accel_raw
            else None,
            gyro=GyroReading(
                x=float(gyro_raw.get("gyro_x", gyro_raw.get("x", 0))),
                y=float(gyro_raw.get("gyro_y", gyro_raw.get("y", 0))),
                z=float(gyro_raw.get("gyro_z", gyro_raw.get("z", 0))),
            )
            if gyro_raw
            else None,
            audio_feature_snippet=payload.get("audio_feature_snippet"),
        )

        async with SessionLocal() as db:
            await IngestionService.process_immediate_ingest(packet, db)
        await IngestionService.queue_telemetry(packet)

    except Exception as exc:
        logger.error(f"MQTT telemetry parse error (device={device_id}): {exc}", exc_info=True)


async def _handle_panic(device_id: str, payload: dict[str, Any]) -> None:
    """Handle high-priority panic button MQTT event — bypasses queue."""
    try:
        async with SessionLocal() as db:
            res = await db.execute(select(Device).where(Device.id == device_id))
            device = res.scalars().first()

            gps = payload.get("gps", {})
            alert = Alert(
                device_id=device_id,
                type="panic",
                severity="critical",
                message="SOS Panic button pressed (MQTT).",
                gps_lat=float(gps.get("lat", 0)) or None,
                gps_lng=float(gps.get("lng", 0)) or None,
                timestamp=datetime.utcnow(),
            )
            db.add(alert)
            await db.commit()
            await manager.broadcast_to_device(device_id, {
                "type": "alert.new",
                "data": {
                    "id": alert.id,
                    "device_id": alert.device_id,
                    "type": alert.type,
                    "severity": alert.severity,
                    "timestamp": alert.timestamp.isoformat(),
                    "message": alert.message,
                    "gps_lat": alert.gps_lat,
                    "gps_lng": alert.gps_lng,
                    "acknowledged": alert.acknowledged,
                },
            })
            if device:
                await NotificationService.dispatch_critical_alert(
                    device_name=device.name,
                    alert_type="panic",
                    details="SOS Panic button pressed via MQTT.",
                )
    except Exception as exc:
        logger.error(f"MQTT panic handler error (device={device_id}): {exc}", exc_info=True)


async def _handle_fall_event(device_id: str, payload: dict[str, Any]) -> None:
    from ai_engine.engine import ai_engine

    impact_g = float(payload.get("impact_g", 0))
    inactivity = int(payload.get("post_fall_inactivity_s", 0))
    result = ai_engine.fall(impact_g=impact_g, inactivity_s=inactivity)

    if result.label in ("confirmed_fall", "possible_fall"):
        try:
            async with SessionLocal() as db:
                res = await db.execute(select(Device).where(Device.id == device_id))
                device = res.scalars().first()
                alert = Alert(
                    device_id=device_id,
                    type="fall",
                    severity="critical",
                    message=f"Fall event via MQTT — {result.label} (conf {result.confidence:.0%})",
                    timestamp=datetime.utcnow(),
                )
                db.add(alert)
                await db.commit()
                await manager.broadcast_to_device(device_id, {
                    "type": "alert.new",
                    "data": {
                        "id": alert.id,
                        "device_id": alert.device_id,
                        "type": alert.type,
                        "severity": alert.severity,
                        "timestamp": alert.timestamp.isoformat(),
                        "message": alert.message,
                        "acknowledged": False,
                    },
                })
                if device:
                    await NotificationService.dispatch_critical_alert(
                        device_name=device.name,
                        alert_type="fall",
                        details=alert.message or "",
                    )
        except Exception as exc:
            logger.error(f"MQTT fall handler error: {exc}", exc_info=True)


async def _handle_audio_event(device_id: str, payload: dict[str, Any]) -> None:
    from ai_engine.engine import ai_engine

    confidence = float(payload.get("confidence", 0))
    snippet = payload.get("audio_clip_url") or "audio_event_mqtt"
    result = ai_engine.distress(snippet=snippet, device_confidence=confidence)

    if result.label == "confirmed_distress":
        try:
            async with SessionLocal() as db:
                res = await db.execute(select(Device).where(Device.id == device_id))
                device = res.scalars().first()
                alert = Alert(
                    device_id=device_id,
                    type="distress",
                    severity="high",
                    message=f"Audio distress event via MQTT (conf {result.confidence:.0%})",
                    timestamp=datetime.utcnow(),
                )
                db.add(alert)
                await db.commit()
                await manager.broadcast_to_device(device_id, {
                    "type": "alert.new",
                    "data": {
                        "id": alert.id,
                        "device_id": alert.device_id,
                        "type": alert.type,
                        "severity": alert.severity,
                        "timestamp": alert.timestamp.isoformat(),
                        "message": alert.message,
                        "acknowledged": False,
                    },
                })
                if device:
                    await NotificationService.dispatch_critical_alert(
                        device_name=device.name,
                        alert_type="distress",
                        details=alert.message or "",
                    )
        except Exception as exc:
            logger.error(f"MQTT audio handler error: {exc}", exc_info=True)


async def _handle_status(device_id: str, payload: dict[str, Any]) -> None:
    """Device heartbeat — update battery / firmware / connection in Postgres."""
    try:
        async with SessionLocal() as db:
            res = await db.execute(select(Device).where(Device.id == device_id))
            device = res.scalars().first()
            if device:
                device.battery_pct = int(payload.get("battery_pct", device.battery_pct))
                device.firmware_version = payload.get("firmware_version", device.firmware_version)
                device.last_seen = datetime.utcnow()
                db.add(device)
                await db.commit()
                await manager.broadcast_to_device(device_id, {
                    "type": "device.status",
                    "data": {
                        "device_id": device.id,
                        "name": device.name,
                        "battery_pct": device.battery_pct,
                        "firmware_version": device.firmware_version,
                        "connection_mode": device.connection_mode,
                        "last_seen": device.last_seen.isoformat(),
                        "is_online": True,
                    },
                })
    except Exception as exc:
        logger.error(f"MQTT status handler error: {exc}", exc_info=True)


_HANDLERS = {
    "telemetry": _handle_telemetry,
    "panic": _handle_panic,
    "fall_event": _handle_fall_event,
    "audio_event": _handle_audio_event,
    "status": _handle_status,
}


async def run_mqtt_bridge() -> None:
    """
    Long-running asyncio task — subscribes to autiguard/+/# and dispatches
    to the correct handler based on the event_type topic segment.

    Exits immediately (without error) if MQTT_BROKER_URL is not configured,
    keeping REST-only development smooth.
    """
    if not settings.MQTT_BROKER_URL:
        logger.info("MQTT_BROKER_URL not set — MQTT bridge disabled (REST-only mode).")
        return

    # aiomqtt is an optional dependency; import here so the app starts even
    # if the package isn't installed and MQTT is disabled.
    try:
        import aiomqtt  # noqa: F401
    except ImportError:
        logger.warning("aiomqtt not installed — MQTT bridge disabled. Run: pip install aiomqtt")
        return

    import aiomqtt

    broker_url: str = settings.MQTT_BROKER_URL
    # Strip scheme prefix so aiomqtt receives a plain hostname
    hostname = broker_url.replace("mqtts://", "").replace("mqtt://", "").rstrip("/")
    use_tls = broker_url.startswith("mqtts://")
    port = int(settings.MQTT_TLS_PORT if use_tls else settings.MQTT_PORT)

    tls_context = None
    if use_tls and settings.MQTT_CA_CERT_PATH:
        import ssl
        tls_context = ssl.create_default_context(cafile=settings.MQTT_CA_CERT_PATH)
        if settings.MQTT_CLIENT_CERT_PATH and settings.MQTT_CLIENT_KEY_PATH:
            tls_context.load_cert_chain(
                certfile=settings.MQTT_CLIENT_CERT_PATH,
                keyfile=settings.MQTT_CLIENT_KEY_PATH,
            )

    logger.info(f"MQTT bridge connecting to {hostname}:{port} (TLS={use_tls})")

    reconnect_delay = 2
    while True:
        try:
            async with aiomqtt.Client(
                hostname=hostname,
                port=port,
                username=settings.MQTT_USERNAME or None,
                password=settings.MQTT_PASSWORD or None,
                tls_context=tls_context,
                identifier="autiguard-backend-bridge",
            ) as client:
                await client.subscribe("autiguard/+/#")
                logger.info("MQTT bridge subscribed to autiguard/+/#")
                reconnect_delay = 2  # reset on successful connect

                async for message in client.messages:
                    topic = str(message.topic)
                    m = _TOPIC_RE.match(topic)
                    if not m:
                        continue

                    device_id = m.group("device_id")
                    event_type = m.group("event_type")
                    handler = _HANDLERS.get(event_type)
                    if not handler:
                        logger.debug(f"MQTT: no handler for topic {topic}")
                        continue

                    try:
                        raw = message.payload
                        payload_str = raw.decode() if isinstance(raw, (bytes, bytearray)) else str(raw)
                        payload = json.loads(payload_str)
                    except Exception as exc:
                        logger.warning(f"MQTT payload parse error on {topic}: {exc}")
                        continue

                    asyncio.create_task(handler(device_id, payload))

        except asyncio.CancelledError:
            logger.info("MQTT bridge task cancelled.")
            return
        except Exception as exc:
            logger.error(f"MQTT bridge connection error: {exc}. Reconnecting in {reconnect_delay}s…")
            await asyncio.sleep(reconnect_delay)
            reconnect_delay = min(reconnect_delay * 2, 60)
