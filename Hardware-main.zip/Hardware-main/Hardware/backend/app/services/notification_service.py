from app.core.config import settings
from app.core.logging import logger

class NotificationService:
    @staticmethod
    async def send_sms(to_phone: str, message: str) -> bool:
        if settings.TWILIO_ACCOUNT_SID and settings.TWILIO_AUTH_TOKEN and settings.TWILIO_PHONE_NUMBER:
            try:
                # We can dynamically import twilio to prevent crashes if the user hasn't run pip install yet
                from twilio.rest import Client
                client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
                client.messages.create(
                    body=message,
                    from_=settings.TWILIO_PHONE_NUMBER,
                    to=to_phone
                )
                logger.info(f"Twilio SMS sent successfully to {to_phone}: '{message}'")
                return True
            except Exception as e:
                logger.error(f"Failed to send Twilio SMS: {e}")
                return False
        else:
            logger.info(f"[SIMULATED SMS] To: {to_phone} | Msg: {message}")
            return True

    @staticmethod
    async def send_email(to_email: str, subject: str, body: str) -> bool:
        # Standard logger for simulated emails
        logger.info(f"[SIMULATED EMAIL] To: {to_email} | Subject: {subject} | Body: {body}")
        return True

    @staticmethod
    async def send_push_notification(user_id: str, title: str, body: str) -> bool:
        logger.info(f"[SIMULATED PUSH] User: {user_id} | Title: {title} | Body: {body}")
        return True

    @classmethod
    async def dispatch_critical_alert(cls, device_name: str, alert_type: str, details: str, contact_phone: str = "+15550199"):
        message = f"🚨 AutiGuard Alert: '{device_name}' triggered a '{alert_type}' safety event. Details: {details}."
        # Dispatch SMS
        await cls.send_sms(contact_phone, message)
        # Dispatch Push
        await cls.send_push_notification("caregiver_id", f"AutiGuard Critical: {alert_type}", message)
