import numpy as np
from datetime import datetime
from typing import Dict, Any, Tuple
from app.core.logging import logger

class MLInferenceClient:
    """
    ML Inference client representing our AI models:
    1. Stress Detection (Random Forest)
    2. Fall Detection (SVM)
    3. Distress Cry Detection (CNN)
    4. Behavioral Trend Analysis (LSTM)
    """

    @staticmethod
    def run_stress_detection(
        hrv_ms: float | None, 
        heart_rate_bpm: int | None,
        accel_x: float | None,
        accel_y: float | None,
        accel_z: float | None
    ) -> Tuple[float, str]:
        """
        Random Forest stress classifier approximation.
        Inputs: HRV, heart rate, and movement intensity.
        Outputs: stress_index (0-100) and risk_level (low, medium, high).
        """
        # Set default values if reading is missing
        hr = heart_rate_bpm if heart_rate_bpm is not None else 72
        hrv = hrv_ms if hrv_ms is not None else 50.0
        
        # Calculate motion intensity (acceleration magnitude deviation)
        x = accel_x if accel_x is not None else 0.0
        y = accel_y if accel_y is not None else 0.0
        z = accel_z if accel_z is not None else 1.0
        motion_val = np.sqrt(x**2 + y**2 + z**2)
        motion_intensity = abs(motion_val - 1.0) # deviation from standard earth gravity (1g)
        
        # Simple Random Forest simulated heuristic logic
        # High heart rate combined with low HRV and high motion increases stress
        stress_score = 30.0
        
        # If heart rate is elevated
        if hr > 90:
            stress_score += (hr - 90) * 1.5
            
        # If HRV is low (stress correlates with low HRV)
        if hrv < 45:
            stress_score += (45 - hrv) * 1.2
            
        # High motion intensity increases score
        if motion_intensity > 0.5:
            stress_score += motion_intensity * 20
            
        # Cap at 100, min 0
        stress_score = max(0.0, min(100.0, stress_score))
        
        if stress_score > 75:
            risk = "high"
        elif stress_score > 45:
            risk = "medium"
        else:
            risk = "low"
            
        logger.info(f"ML Inference (Stress RF): score={stress_score:.1f}, risk={risk}")
        return stress_score, risk

    @staticmethod
    def run_fall_detection(
        accel_x: float | None,
        accel_y: float | None,
        accel_z: float | None
    ) -> Tuple[bool, float]:
        """
        SVM with temporal windowing fall detector approximation.
        Inputs: 3-axis accelerometer vector.
        Outputs: fall_event (bool) and confidence (0.0-1.0).
        """
        if accel_x is None or accel_y is None or accel_z is None:
            return False, 0.0
            
        # Standard acceleration magnitude calculation
        magnitude = np.sqrt(accel_x**2 + accel_y**2 + accel_z**2)
        
        # In a real SVM classifier, we look at windows.
        # Here we check if magnitude crosses a high-G impact threshold (e.g. > 3.0g or < 0.2g freefall)
        if magnitude > 3.2:
            confidence = min(0.95, 0.5 + (magnitude - 3.2) * 0.1)
            logger.warning(f"ML Inference (Fall SVM): Fall detected! Magnitude={magnitude:.2f}g, confidence={confidence:.2f}")
            return True, confidence
            
        return False, 0.0

    @staticmethod
    def run_distress_audio_recognition(audio_feature_snippet: str | None) -> Tuple[bool, float]:
        """
        CNN classifier on pre-processed audio feature vector (Base64 string representing MFCC coefficients).
        Outputs: distress_flag (bool) and confidence (0.0-1.0).
        """
        if not audio_feature_snippet:
            return False, 0.0
            
        # Decode features or check for standard trigger string in simulator
        try:
            # Let's say if the string contains a special token "distress_scream", we mark it
            if "distress_scream" in audio_feature_snippet or "scream" in audio_feature_snippet:
                logger.warning("ML Inference (Audio CNN): Screaming/Distress audio snippet recognized!")
                return True, 0.92
        except Exception as e:
            logger.error(f"Error reading audio snippet: {e}")
            
        return False, 0.0

    @staticmethod
    def run_behavioral_trend_lstm(device_id: str, recent_stress_scores: list) -> Tuple[float, str]:
        """
        LSTM behavioral trend model run less frequently (e.g., rolling window).
        Predicts meltdown escalation risk for the next 2 hours.
        Returns: risk_percentage (0-100) and warning_message.
        """
        if not recent_stress_scores:
            return 10.0, "stable"
            
        # Standard LSTM rolling simulation: check if stress trend is rising
        avg_stress = sum(recent_stress_scores) / len(recent_stress_scores)
        
        # Calculate slope/delta if we have multiple scores
        delta = 0
        if len(recent_stress_scores) > 1:
            delta = recent_stress_scores[-1] - recent_stress_scores[0]
            
        escalation_risk = avg_stress
        if delta > 15:
            # Vitals are rising rapidly
            escalation_risk += delta * 1.5
            
        escalation_risk = max(0.0, min(100.0, escalation_risk))
        
        if escalation_risk > 70:
            trend = "critical_meltdown_risk"
        elif escalation_risk > 40:
            trend = "elevated_anxiety"
        else:
            trend = "stable"
            
        logger.info(f"ML Inference (Trend LSTM): escalation_risk={escalation_risk:.1f}%, status={trend}")
        return escalation_risk, trend
