import math
from app.core.logging import logger

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate the great circle distance between two points 
    on the earth in meters.
    """
    # Earth radius in meters
    R = 6371000.0
    
    phi_1 = math.radians(lat1)
    phi_2 = math.radians(lat2)
    
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)
    
    a = (math.sin(delta_phi / 2.0) ** 2 +
         math.cos(phi_1) * math.cos(phi_2) * (math.sin(delta_lambda / 2.0) ** 2))
         
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
    
    return R * c

class GeofenceEngine:
    @staticmethod
    def is_outside_geofence(gps_lat: float, gps_lng: float, center_lat: float, center_lng: float, radius_meters: float) -> bool:
        """
        Check if the coordinate is outside a circular geofence boundary.
        """
        distance = haversine_distance(gps_lat, gps_lng, center_lat, center_lng)
        logger.info(f"Geofence breach check: distance={distance:.2f}m, radius={radius_meters}m")
        return distance > radius_meters
