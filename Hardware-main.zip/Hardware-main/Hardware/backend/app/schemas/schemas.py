from pydantic import BaseModel, EmailStr, Field
from datetime import datetime
from typing import Literal, Optional, List

# Sub-readings for Telemetry
class GPSReading(BaseModel):
    lat: float = Field(..., ge=-90, le=90)
    lng: float = Field(..., ge=-180, le=180)
    accuracy_m: Optional[float] = Field(None, ge=0)

class AccelReading(BaseModel):
    x: float
    y: float
    z: float

class GyroReading(BaseModel):
    x: float
    y: float
    z: float

# 4.1 Canonical TelemetryPacket Schema
class TelemetryPacket(BaseModel):
    device_id: str
    timestamp: datetime
    battery_pct: int = Field(..., ge=0, le=100)
    gps: Optional[GPSReading] = None
    heart_rate_bpm: Optional[int] = Field(None, ge=0)
    hrv_ms: Optional[float] = Field(None, ge=0)
    accel: Optional[AccelReading] = None
    gyro: Optional[GyroReading] = None
    audio_feature_snippet: Optional[str] = None  # Base64 pre-processed, not raw audio
    connection_mode: Literal["BLE", "WIFI", "LTE"]

    class Config:
        from_attributes = True

# User Schemas
class UserCreate(BaseModel):
    email: EmailStr
    password: str
    name: str
    role: Literal["guardian", "caregiver", "clinician", "emergency_responder", "admin"] = "caregiver"

class UserResponse(BaseModel):
    id: str
    email: EmailStr
    name: str
    role: str
    created_at: datetime

    class Config:
        from_attributes = True

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str

# Geofence Schemas
class GeofenceCreate(BaseModel):
    name: str
    center_lat: float
    center_lng: float
    radius_meters: float

class GeofenceResponse(BaseModel):
    id: str
    device_id: str
    name: str
    center_lat: float
    center_lng: float
    radius_meters: float
    is_active: bool

    class Config:
        from_attributes = True

# Device Schemas
class DeviceRegister(BaseModel):
    serial_number: str
    provisioning_secret: str
    name: str

class DeviceResponse(BaseModel):
    id: str
    serial_number: str
    name: str
    firmware_version: str
    battery_pct: int
    connection_mode: str
    last_seen: datetime

    class Config:
        from_attributes = True

class DeviceConfigResponse(BaseModel):
    device_id: str
    name: str
    geofences: List[GeofenceResponse]

# Alert Schemas
class AlertResponse(BaseModel):
    id: str
    device_id: str
    type: str  # panic, fall, distress, stress, geofence
    severity: str  # critical, high, warning, info
    timestamp: datetime
    message: Optional[str] = None
    gps_lat: Optional[float] = None
    gps_lng: Optional[float] = None
    acknowledged: bool
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class AlertPanicRequest(BaseModel):
    device_id: str
    gps_lat: Optional[float] = None
    gps_lng: Optional[float] = None
    message: Optional[str] = "SOS Panic button pressed!"

# Non-Verbal schemas
class NonVerbalRequest(BaseModel):
    device_id: str
    message: str

class NonVerbalResponse(BaseModel):
    id: str
    device_id: str
    message: str
    timestamp: datetime

    class Config:
        from_attributes = True

# QR Identity Schemas
class QRIdentityResponse(BaseModel):
    device_id: str
    encrypted_payload: str
    rotated_at: datetime

class QRScanRequest(BaseModel):
    encrypted_payload: str
    location_lat: Optional[float] = None
    location_lng: Optional[float] = None

class QRDecodedResponse(BaseModel):
    device_id: str
    wearer_name: str
    role_level: str
    # Fields dynamically filled based on role hierarchy
    emergency_contact: Optional[str] = None
    emergency_phone: Optional[str] = None
    critical_medical_notes: Optional[str] = None
    stress_trend_summary: Optional[str] = None
    full_medical_record: Optional[str] = None
