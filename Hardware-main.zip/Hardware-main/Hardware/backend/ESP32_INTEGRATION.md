# AutiGuard ESP32 Hardware Integration Guide

This document outlines the API specifications and hardware wiring required to connect the ESP32 wearable prototype to the caregiver telemetry backend.

---

## 1. API Endpoint Specifications

The backend server exposes two primary HTTP POST endpoints for the hardware to stream vitals and dispatch distress events.

### Authentication
All requests from the ESP32 must include the following header:
- **Header Key:** `X-AutiGuard-Key`
- **Header Value:** `<shared-secret-key>` (Configured in the backend `.env` file under `AUTIGUARD_API_KEY`)

---

### Endoint A: Telemetry Streaming
Stream vital signs, GPS location, battery levels, and Wi-Fi signal details.

- **Route:** `POST /api/sensor-data`
- **Content-Type:** `application/json`
- **JSON Payload Format:**
```json
{
  "deviceId": "ESP32_AUTIGUARD_01",
  "heartRate": 76,
  "gpsLat": 37.774900,
  "gpsLng": -122.419400,
  "temperature": 36.6,
  "fallDetected": false,
  "batteryLevel": 92,
  "wifiStatus": "excellent"
}
```

#### Parameter Descriptions:
- `deviceId` (string): Unique identifier for the hardware transmitter.
- `heartRate` (number): Heart beats per minute (BPM) read from the PPG sensor.
- `gpsLat` (number): Current latitude coordinates (decimal degrees).
- `gpsLng` (number): Current longitude coordinates (decimal degrees).
- `temperature` (number): Body temperature (°C).
- `fallDetected` (boolean): `true` if the accelerometer registered a high-g impact event.
- `batteryLevel` (number): Remaining battery percentage (0-100).
- `wifiStatus` (string): Wi-Fi strength tag: `"excellent"`, `"good"`, `"fair"`, `"poor"`, or `"none"`.

#### HTTP Response Statuses:
- `200 OK`: Telemetry logged successfully.
- `400 Bad Request`: Missing parameter or invalid payload types.
- `401 Unauthorized`: Missing or incorrect `X-AutiGuard-Key` header.
- `500 Internal Error`: Database connection issue.

---

### Endpoint B: Manual SOS Panic Alert
Dispatches an immediate panic alert bypassing standard telemetry schedules (triggered instantly by button press).

- **Route:** `POST /api/alert`
- **Content-Type:** `application/json`
- **JSON Payload Format:**
```json
{
  "deviceId": "ESP32_AUTIGUARD_01",
  "type": "panic",
  "message": "SOS Emergency: Distress button pressed by the wearer.",
  "gpsLat": 37.774900,
  "gpsLng": -122.419400
}
```

#### Parameter Descriptions:
- `type` (string): Type of alert event (always `"panic"` for distress buttons).
- `message` (string): Optional custom notification text display.

---

## 2. Hardware Wiring Diagram

Connect the sensor modules to your ESP32 board using the following layout:

| Component | Pin Label | ESP32 GPIO Pin | Connection Type |
| :--- | :--- | :--- | :--- |
| **ADXL345 Accelerometer** | VCC | 3.3V | Power |
| | GND | GND | Ground |
| | SDA | GPIO 21 | I2C Data |
| | SCL | GPIO 22 | I2C Clock |
| **L86 / Neo-6M GPS** | VCC | 5.0V or 3.3V | Power |
| | GND | GND | Ground |
| | TX | GPIO 16 (RX2) | UART Serial RX |
| | RX | GPIO 17 (TX2) | UART Serial TX |
| **PPG Vitals Sensor** | VCC | 3.3V | Power |
| | GND | GND | Ground |
| | Signal | GPIO 34 (ADC1_CH6)| Analog Input |
| **Panic Button** | Terminal A | GPIO 12 | Digital Input (Pull-up)|
| | Terminal B | GND | Ground |

---

## 3. Firmware Configuration & Flashing

Follow these steps to flash the firmware to your ESP32:

1. **Install Arduino IDE:** Ensure you have the Arduino IDE installed.
2. **Add ESP32 Board Support:**
   - In Arduino IDE, go to **File > Preferences**.
   - Enter `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json` in the "Additional Boards Manager URLs" field.
   - Go to **Tools > Board > Boards Manager**, search for `esp32`, and install the library.
3. **Install Core Libraries:**
   - Go to **Sketch > Include Library > Manage Libraries...**
   - Search for and install **ArduinoJson** (by Benoit Blanchon).
   - Search for and install **Adafruit Unified Sensor** and **Adafruit ADXL345**.
   - Search for and install **TinyGPS++** (by Mikal Hart).
4. **Open the Sketch:** Open [esp32_autiguard_sketch.ino](file:///c:/Users/gayathree/Documents/Antigravity/backend/esp32_autiguard_sketch/esp32_autiguard_sketch.ino).
5. **Configure Parameters:**
   - Change `ssid` and `password` variables to match your local Wi-Fi router.
   - Replace `YOUR_BACKEND_SERVER_IP` in the API URLs with your local computer's IP address (e.g. `http://192.168.1.45:5000/api/sensor-data`). Do not use `localhost` as the ESP32 is a separate hardware unit.
   - Change the `apiKey` variable to match the secret key in your backend `.env` configuration.
6. **Deploy:** Select your ESP32 board port, compile, and upload! Keep the Serial Monitor open at `115200 baud` to view connection diagnostics and packet logging status.
