import readline from 'readline';
import dotenv from 'dotenv';

dotenv.config();

const API_URL = 'http://localhost:5000';
const DEVICE_ID = 'ESP32_AUTIGUARD_DEMO';
const API_KEY = process.env.AUTIGUARD_API_KEY || 'dev_secret_key_123';

// Base state variables
let heartRate = 72;
let gpsLat = 37.7749;
let gpsLng = -122.4194;
let temperature = 36.6;
let batteryLevel = 98;
let wifiStatus = 'excellent';
let fallDetected = false;

// Safe coordinates tracker
const BASE_LAT = 37.7749;
const BASE_LNG = -122.4194;

readline.emitKeypressEvents(process.stdin);
if (process.stdin.isTTY) {
  process.stdin.setRawMode(true);
}

console.log('========================================================');
console.log('   AutiGuard ESP32 Wearable Telemetry Simulator         ');
console.log('========================================================');
console.log(`Device Identifier: ${DEVICE_ID}`);
console.log(`Target API URL:    ${API_URL}`);
console.log(`Shared API Secret:  ${API_KEY}`);
console.log('--------------------------------------------------------');
console.log('Interactive Controls:');
console.log('  [f] Trigger sudden FALL event');
console.log('  [p] Trigger manual SOS PANIC button press');
console.log('  [o] Teleport wearer OUTSIDE geofence zone');
console.log('  [r] RESET wearer GPS inside safe geofence');
console.log('  [h] Spike HEART RATE (simulates stress/exercise)');
console.log('  [n] NORMALIZE heart rate & vitals');
console.log('  [q] Quit simulator');
console.log('========================================================\n');

// Listen to keyboard keypresses
process.stdin.on('keypress', (str, key) => {
  if (key.ctrl && key.name === 'c' || key.name === 'q') {
    console.log('\nStopping AutiGuard Wearable Simulator...');
    process.exit();
  }

  switch (key.name) {
    case 'f':
      fallDetected = true;
      console.log('\n[EVENT] Simulated Fall Triggered! High-g impact flagged.');
      sendTelemetry(); // Send immediately
      break;
    case 'p':
      console.log('\n[EVENT] Manual Panic SOS Button pressed on wearable!');
      sendPanicAlert();
      break;
    case 'o':
      // Move coordinates away from center (roughly ~350 meters north-east)
      gpsLat = BASE_LAT + 0.0035;
      gpsLng = BASE_LNG + 0.0035;
      console.log('\n[EVENT] Wearer teleported OUTSIDE geofence zone.');
      sendTelemetry();
      break;
    case 'r':
      gpsLat = BASE_LAT;
      gpsLng = BASE_LNG;
      console.log('\n[EVENT] Wearer coordinates reset to center.');
      sendTelemetry();
      break;
    case 'h':
      heartRate = 124;
      console.log('\n[EVENT] Heart Rate spiked to 124 BPM (Stress/Anxiety event).');
      sendTelemetry();
      break;
    case 'n':
      heartRate = 72;
      temperature = 36.6;
      fallDetected = false;
      console.log('\n[EVENT] Vitals stabilized back to optimal baseline.');
      sendTelemetry();
      break;
    default:
      break;
  }
});

// Calculate slight drift movement
const driftLocation = () => {
  // Add small random noise to coordinates
  const driftLat = (Math.random() - 0.5) * 0.0001;
  const driftLng = (Math.random() - 0.5) * 0.0001;
  
  // Drift around current position only if we aren't purposely teleported out
  const distFromBase = Math.abs(gpsLat - BASE_LAT);
  if (distFromBase < 0.002) {
    gpsLat += driftLat;
    gpsLng += driftLng;
  }
};

// Drift vitals
const driftVitals = () => {
  // Drift heart rate slightly (except when spiked)
  if (heartRate < 100) {
    heartRate += Math.floor((Math.random() - 0.5) * 4);
    heartRate = Math.max(60, Math.min(95, heartRate));
  } else {
    // slowly decay spiked heart rate back to normal
    heartRate -= Math.floor(Math.random() * 2);
  }

  // Drift temp
  temperature += (Math.random() - 0.5) * 0.1;
  temperature = Math.max(36.2, Math.min(37.4, temperature));

  // Slow battery decay
  if (Math.random() > 0.8) {
    batteryLevel -= 1;
    if (batteryLevel < 5) batteryLevel = 100; // auto recharge for demo continuity
  }

  // Random wifi state fluctuation
  const signals = ['excellent', 'good', 'fair', 'poor'];
  if (Math.random() > 0.85) {
    wifiStatus = signals[Math.floor(Math.random() * signals.length)];
  }
};

// Send Telemetry packet to backend API
async function sendTelemetry() {
  driftLocation();
  driftVitals();

  const payload = {
    deviceId: DEVICE_ID,
    heartRate,
    gpsLat,
    gpsLng,
    temperature,
    fallDetected,
    batteryLevel,
    wifiStatus
  };

  // Reset fall detected after transmission so it doesn't loop fire
  if (fallDetected) {
    fallDetected = false;
  }

  try {
    const response = await fetch(`${API_URL}/api/sensor-data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-AutiGuard-Key': API_KEY
      },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
      console.log(`[Broadcasting] GPS: ${gpsLat.toFixed(5)}, ${gpsLng.toFixed(5)} | Heart Rate: ${heartRate} BPM | Temp: ${temperature.toFixed(1)}°C | Batt: ${batteryLevel}% | Wifi: ${wifiStatus}`);
    } else {
      const errText = await response.text();
      console.error(`[API Error] Received status ${response.status}:`, errText);
    }
  } catch (err) {
    console.error(`[Network Error] Unable to connect to backend server at ${API_URL}. Check if backend is running. (${err.message})`);
  }
}

// Send Manual Panic Alarm trigger
async function sendPanicAlert() {
  const payload = {
    deviceId: DEVICE_ID,
    type: 'panic',
    message: 'Manual Emergency SOS: Distress button pressed by the wearer.',
    gpsLat,
    gpsLng
  };

  try {
    const response = await fetch(`${API_URL}/api/alert`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-AutiGuard-Key': API_KEY
      },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
      console.log(`[SOS Sent] Manual Panic SOS packet successfully written to server.`);
    } else {
      console.error(`[API Error] SOS transmission failed. Status ${response.status}`);
    }
  } catch (err) {
    console.error(`[Network Error] SOS transmission failed: ${err.message}`);
  }
}

// Stream data continuously
const intervalId = setInterval(sendTelemetry, 5000);
console.log('Telemetry scheduler running: broadcasting packet logs every 5s...');
sendTelemetry(); // trigger initial call
