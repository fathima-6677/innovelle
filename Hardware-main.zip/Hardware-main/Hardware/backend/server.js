import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import admin from 'firebase-admin';
import fs from 'fs';
import path from 'path';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const API_SECRET = process.env.AUTIGUARD_API_KEY || 'dev_secret_key_123';
const SERVICE_ACCOUNT_PATH = process.env.FIREBASE_SERVICE_ACCOUNT_PATH || './service-account.json';

app.use(cors());
app.use(express.json());

// Initialize Firebase Admin
let db;
try {
  if (fs.existsSync(SERVICE_ACCOUNT_PATH)) {
    const serviceAccount = JSON.parse(fs.readFileSync(SERVICE_ACCOUNT_PATH, 'utf8'));
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      databaseURL: process.env.FIREBASE_DATABASE_URL
    });
    console.log('Firebase Admin initialized with service account certificate.');
  } else {
    // Attempt default initialization (using env variables or fallback)
    admin.initializeApp({
      databaseURL: process.env.FIREBASE_DATABASE_URL
    });
    console.log('Firebase Admin initialized using default environment configurations.');
  }
  db = admin.database();
} catch (error) {
  console.error('CRITICAL: Failed to initialize Firebase Admin SDK:', error.message);
  console.log('Backend will run in Mock Mode. Database writes will be output to console instead of Firebase.');
}

// Middleware: API Key verification
const verifyApiKey = (req, res, next) => {
  const clientKey = req.headers['x-autiguard-key'];
  if (!clientKey || clientKey !== API_SECRET) {
    return res.status(401).json({
      error: 'Unauthorized',
      message: 'Access denied. Valid X-AutiGuard-Key header required.'
    });
  }
  next();
};

// Helper: Haversine distance in meters
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371e3; // metres
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c; // in metres
};

// 1. POST /api/sensor-data - Receive telemetry from ESP32
app.post('/api/sensor-data', verifyApiKey, async (req, res) => {
  const {
    deviceId,
    heartRate,
    gpsLat,
    gpsLng,
    temperature,
    fallDetected,
    batteryLevel,
    wifiStatus
  } = req.body;

  // Validation
  if (!deviceId) {
    return res.status(400).json({ error: 'Bad Request', message: 'Missing deviceId parameter.' });
  }
  if (
    typeof heartRate !== 'number' ||
    typeof gpsLat !== 'number' ||
    typeof gpsLng !== 'number' ||
    typeof temperature !== 'number' ||
    typeof batteryLevel !== 'number' ||
    typeof fallDetected !== 'boolean'
  ) {
    return res.status(400).json({
      error: 'Bad Request',
      message: 'Invalid payload types. Vitals metrics must be numbers, fallDetected must be boolean.'
    });
  }

  const timestamp = Date.now();
  const sensorRecord = {
    heartRate,
    gpsLat,
    gpsLng,
    temperature,
    fallDetected,
    batteryLevel,
    timestamp
  };

  console.log(`[Sensor-Data] Device: ${deviceId} | HR: ${heartRate} | Temp: ${temperature}°C | Battery: ${batteryLevel}%`);

  if (!db) {
    // Mock Mode fallback
    return res.status(200).json({
      message: 'Success (Mock Mode - Firebase not connected)',
      record: sensorRecord
    });
  }

  try {
    // A. Write telemetry log
    await db.ref(`sensorData/${deviceId}/${timestamp}`).set(sensorRecord);

    // B. Update current device health record
    await db.ref(`devices/${deviceId}`).update({
      batteryLevel,
      wifiStatus: wifiStatus || 'good',
      lastSeen: timestamp
    });

    // C. Automated Alert Checks
    
    // Check 1: Fall Detected
    if (fallDetected) {
      const alertId = `alert_${timestamp}_fall`;
      await db.ref(`alerts/${deviceId}/${alertId}`).set({
        type: 'fall',
        timestamp,
        location: { lat: gpsLat, lng: gpsLng },
        acknowledged: false,
        message: 'Critical Alert: Accelerometer impact threshold crossed. Fall detected.'
      });
    }

    // Check 2: Low Battery Warning
    if (batteryLevel < 15) {
      const alertId = `alert_${timestamp}_battery`;
      // Check if low battery alert was already fired recently to avoid spamming
      const lastBatteryRef = db.ref(`alerts/${deviceId}`).orderByChild('type').equalTo('lowBattery').limitToLast(1);
      const snapshot = await lastBatteryRef.once('value');
      let shouldFire = true;
      
      if (snapshot.exists()) {
        const lastAlert = Object.values(snapshot.val())[0];
        // Don't fire if alert is less than 30 minutes old
        if (timestamp - lastAlert.timestamp < 30 * 60 * 1000) {
          shouldFire = false;
        }
      }
      
      if (shouldFire) {
        await db.ref(`alerts/${deviceId}/${alertId}`).set({
          type: 'lowBattery',
          timestamp,
          acknowledged: false,
          message: `Warning: Wearable battery cell is critical at ${batteryLevel}%. Please connect charger.`
        });
      }
    }

    // Check 3: Geofence Breach
    const geofenceSnap = await db.ref(`geofences/${deviceId}`).once('value');
    if (geofenceSnap.exists()) {
      const geofence = geofenceSnap.val();
      const dist = calculateDistance(gpsLat, gpsLng, geofence.centerLat, geofence.centerLng);
      
      if (dist > geofence.radiusMeters) {
        // Exited safe zone
        const alertId = `alert_${timestamp}_geofence`;
        
        // Anti-spam query (don't alert again if geofence breach was recorded in the last 5 minutes)
        const lastGeofenceQuery = db.ref(`alerts/${deviceId}`).orderByChild('type').equalTo('geofence').limitToLast(1);
        const geoSnap = await lastGeofenceQuery.once('value');
        let shouldFireGeo = true;
        
        if (geoSnap.exists()) {
          const lastGeoAlert = Object.values(geoSnap.val())[0];
          if (timestamp - lastGeoAlert.timestamp < 5 * 60 * 1000 && !lastGeoAlert.acknowledged) {
            shouldFireGeo = false; // already active alert in dashboard
          }
        }

        if (shouldFireGeo) {
          await db.ref(`alerts/${deviceId}/${alertId}`).set({
            type: 'geofence',
            timestamp,
            location: { lat: gpsLat, lng: gpsLng },
            acknowledged: false,
            message: `Geofence breach detected. Wearer exited safe boundaries for ${geofence.safeZoneName}.`
          });
        }
      }
    }

    return res.status(200).json({ success: true, message: 'Telemetry successfully logged.' });
  } catch (err) {
    console.error('Database write failed:', err);
    return res.status(500).json({ error: 'Internal Server Error', details: err.message });
  }
});

// 2. POST /api/alert - Trigger an alert manually from hardware (e.g. SOS panic press)
app.post('/api/alert', verifyApiKey, async (req, res) => {
  const { deviceId, type, message, gpsLat, gpsLng } = req.body;

  if (!deviceId || !type) {
    return res.status(400).json({ error: 'Bad Request', message: 'Missing deviceId or type parameter.' });
  }

  const timestamp = Date.now();
  const alertId = `alert_${timestamp}_${type}`;
  
  const alertObj = {
    type,
    timestamp,
    acknowledged: false,
    message: message || `SOS trigger alert: ${type}`,
    ...(gpsLat && gpsLng && { location: { lat: gpsLat, lng: gpsLng } })
  };

  console.log(`[Alert-Trigger] Device: ${deviceId} | Type: ${type}`);

  if (!db) {
    return res.status(200).json({ message: 'Success (Mock Mode)', alert: alertObj });
  }

  try {
    await db.ref(`alerts/${deviceId}/${alertId}`).set(alertObj);
    return res.status(200).json({ success: true, alertId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Database write failed', details: err.message });
  }
});

// 3. GET /api/device/:deviceId/status - Fetch device metadata status fallback
app.get('/api/device/:deviceId/status', async (req, res) => {
  const { deviceId } = req.params;

  if (!db) {
    return res.status(200).json({
      deviceId,
      deviceName: 'AutiGuard Wearable (Mock)',
      batteryLevel: 85,
      wifiStatus: 'good',
      lastSeen: Date.now()
    });
  }

  try {
    const snapshot = await db.ref(`devices/${deviceId}`).once('value');
    if (!snapshot.exists()) {
      return res.status(404).json({ error: 'Not Found', message: 'No registered device details found matching ID.' });
    }
    return res.status(200).json(snapshot.val());
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Database read failed', details: err.message });
  }
});

// Start Server
app.listen(PORT, () => {
  console.log(`AutiGuard hardware integration API running on port ${PORT}`);
});
