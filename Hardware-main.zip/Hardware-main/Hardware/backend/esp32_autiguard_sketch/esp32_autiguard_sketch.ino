/*
 * AutiGuard Wearable — ESP32 Firmware v2.0
 * =========================================
 * Targets the FastAPI backend (not the old Node/Firebase server).
 *
 * Transport:
 *   PRIMARY  — MQTT over WiFi / LTE-M  →  autiguard/{device_id}/telemetry
 *   FALLBACK — HTTPS POST               →  /api/v1/telemetry/ingest
 *
 * On-boot the device calls GET /api/v1/devices/{id}/config to pull its
 * UUID and geofence config, then keeps that UUID in all subsequent messages.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * Hardware wiring
 * ─────────────────────────────────────────────────────────────────────────
 *   PPG sensor (heart rate)        GPIO 34  (ADC1 — analog)
 *   ADXL345 accelerometer          I2C  SDA=21 SCL=22
 *   L86 / Neo-6M GPS               UART2  RX=16 TX=17  @ 9600 baud
 *   SOS panic button               GPIO 12  (INPUT_PULLUP — active LOW)
 *   Battery voltage divider        GPIO 35  (ADC1 — 100k+100k divider)
 *
 * ─────────────────────────────────────────────────────────────────────────
 * Arduino library dependencies  (install via Library Manager)
 * ─────────────────────────────────────────────────────────────────────────
 *   ArduinoJson          (Benoit Blanchon)   >= 7.x
 *   Adafruit ADXL345                          >= 1.3
 *   Adafruit Unified Sensor                   >= 1.1
 *   TinyGPS++            (Mikal Hart)         >= 1.0
 *   PubSubClient         (Nick O'Leary)       >= 2.8  ← MQTT client
 *   WiFiClientSecure                          (bundled with ESP32 Arduino core)
 */

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>
#include <TinyGPS++.h>
#include <ArduinoJson.h>
#include <PubSubClient.h>

// ═══════════════════════════════════════════════════════════════════════════
// USER CONFIGURATION — edit these before flashing
// ═══════════════════════════════════════════════════════════════════════════

// WiFi credentials
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// FastAPI backend  (no trailing slash, no /api/v1)
// For LAN testing:  "http://192.168.1.100:8000"
// For production:   "https://api.yourdomain.com"
const char* BACKEND_URL   = "http://192.168.1.100:8000";

// Device provisioning secret — must match DEVICE_PROVISIONING_SECRET in .env
const char* DEVICE_PROV_SECRET = "esp32_factory_secret_2026";

// Serial number burned at factory — becomes the device's stable identity
const char* DEVICE_SERIAL = "ESP32_AUTIGUARD_001";

// MQTT broker — leave blank to run HTTP-only mode
// AWS IoT Core example: "a1b2c3d4e5f6g7-ats.iot.us-east-1.amazonaws.com"
const char* MQTT_BROKER   = "";          // blank = HTTP fallback only
const int   MQTT_PORT     = 1883;        // 8883 for TLS

// ═══════════════════════════════════════════════════════════════════════════
// PIN ASSIGNMENTS
// ═══════════════════════════════════════════════════════════════════════════
#define PANIC_BUTTON_PIN  12   // SOS button — GPIO12, active LOW (INPUT_PULLUP)
#define PPG_SENSOR_PIN    34   // PPG heart-rate — ADC1 (must be ADC1 for WiFi compat)
#define BATTERY_PIN       35   // Voltage divider for battery level — ADC1
#define GPS_RX_PIN        16   // GPS TX  →  ESP32 RX2
#define GPS_TX_PIN        17   // GPS RX  ←  ESP32 TX2

// ═══════════════════════════════════════════════════════════════════════════
// THRESHOLDS
// ═══════════════════════════════════════════════════════════════════════════
#define FALL_G_THRESHOLD     3.5f   // g-force peak considered a fall impact
#define TELEMETRY_INTERVAL   5000   // ms between normal telemetry publishes
#define STATUS_INTERVAL      60000  // ms between device heartbeat messages

// ═══════════════════════════════════════════════════════════════════════════
// GLOBALS
// ═══════════════════════════════════════════════════════════════════════════
Adafruit_ADXL345_Unified accel = Adafruit_ADXL345_Unified(12345);
TinyGPSPlus              gps;
HardwareSerial           gpsSerial(2);

WiFiClient               wifiClient;
PubSubClient             mqttClient(wifiClient);

// Device UUID returned by /devices/register — stored across sessions via NVS
// For simplicity here we use a static char array populated at runtime.
char deviceUuid[64] = "";
bool mqttEnabled    = (MQTT_BROKER[0] != '\0');

unsigned long lastTelemetryMs = 0;
unsigned long lastStatusMs    = 0;

// ═══════════════════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════════════════
void setup() {
    Serial.begin(115200);
    gpsSerial.begin(9600, SERIAL_8N1, GPS_RX_PIN, GPS_TX_PIN);

    pinMode(PANIC_BUTTON_PIN, INPUT_PULLUP);

    // Accelerometer
    if (!accel.begin()) {
        Serial.println("[WARN] ADXL345 not found — fall detection disabled");
    } else {
        accel.setRange(ADXL345_RANGE_16_G);
        Serial.println("[OK] ADXL345 accelerometer initialised (±16 g)");
    }

    // WiFi
    connectWifi();

    // Register device with FastAPI backend and obtain UUID
    registerDevice();

    // MQTT setup (optional)
    if (mqttEnabled) {
        mqttClient.setServer(MQTT_BROKER, MQTT_PORT);
        mqttClient.setKeepAlive(60);
        connectMqtt();
    }

    Serial.println("[OK] AutiGuard firmware v2.0 ready");
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN LOOP
// ═══════════════════════════════════════════════════════════════════════════
void loop() {
    // Feed GPS NMEA parser
    while (gpsSerial.available() > 0) {
        gps.encode(gpsSerial.read());
    }

    // MQTT keepalive
    if (mqttEnabled) {
        if (!mqttClient.connected()) {
            connectMqtt();
        }
        mqttClient.loop();
    }

    // Panic button — debounced active-LOW read
    if (digitalRead(PANIC_BUTTON_PIN) == LOW) {
        delay(50);
        if (digitalRead(PANIC_BUTTON_PIN) == LOW) {
            sendPanicEvent();
            delay(3000);  // hold-off to prevent repeated fires
        }
    }

    // Periodic telemetry
    if (millis() - lastTelemetryMs >= TELEMETRY_INTERVAL) {
        lastTelemetryMs = millis();
        sendTelemetry();
    }

    // Periodic device heartbeat
    if (millis() - lastStatusMs >= STATUS_INTERVAL) {
        lastStatusMs = millis();
        sendDeviceStatus();
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// WiFi
// ═══════════════════════════════════════════════════════════════════════════
void connectWifi() {
    Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    int tries = 0;
    while (WiFi.status() != WL_CONNECTED && tries < 30) {
        delay(500);
        Serial.print(".");
        tries++;
    }
    if (WiFi.status() == WL_CONNECTED) {
        Serial.printf("\n[WiFi] Connected. IP: %s\n", WiFi.localIP().toString().c_str());
    } else {
        Serial.println("\n[WiFi] Connection failed — continuing offline");
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Device registration with FastAPI  →  POST /api/v1/devices/register
// Stores the returned UUID in deviceUuid[]
// ═══════════════════════════════════════════════════════════════════════════
void registerDevice() {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("[Register] WiFi not connected — skipping registration");
        return;
    }

    HTTPClient http;
    String url = String(BACKEND_URL) + "/api/v1/devices/register";
    http.begin(url);
    http.addHeader("Content-Type", "application/json");

    // Build payload
    StaticJsonDocument<256> doc;
    doc["serial_number"]       = DEVICE_SERIAL;
    doc["provisioning_secret"] = DEVICE_PROV_SECRET;
    doc["name"]                = String("AutiGuard Band ") + DEVICE_SERIAL;

    String body;
    serializeJson(doc, body);

    int code = http.POST(body);
    if (code == 200 || code == 201) {
        String resp = http.getString();
        StaticJsonDocument<512> rdoc;
        if (deserializeJson(rdoc, resp) == DeserializationError::Ok) {
            strlcpy(deviceUuid, rdoc["device_id"] | "", sizeof(deviceUuid));
            Serial.printf("[Register] Device UUID: %s\n", deviceUuid);
        }
    } else {
        Serial.printf("[Register] Failed (HTTP %d): %s\n", code, http.getString().c_str());
    }
    http.end();
}

// ═══════════════════════════════════════════════════════════════════════════
// MQTT connection
// ═══════════════════════════════════════════════════════════════════════════
void connectMqtt() {
    if (!mqttEnabled) return;
    int attempts = 0;
    while (!mqttClient.connected() && attempts < 5) {
        Serial.printf("[MQTT] Connecting to %s:%d … ", MQTT_BROKER, MQTT_PORT);
        String clientId = String("autiguard-") + String(deviceUuid).substring(0, 8);
        if (mqttClient.connect(clientId.c_str())) {
            Serial.println("connected");
        } else {
            Serial.printf("failed (state=%d). Retry in 3 s\n", mqttClient.state());
            delay(3000);
            attempts++;
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Build MQTT topic string  →  "autiguard/{uuid}/{event}"
// ═══════════════════════════════════════════════════════════════════════════
String mqttTopic(const char* event) {
    return String("autiguard/") + String(deviceUuid) + "/" + event;
}

// ═══════════════════════════════════════════════════════════════════════════
// Sensor helpers
// ═══════════════════════════════════════════════════════════════════════════
int readHeartRateBpm() {
    // Real implementation: track peak-to-peak interval on PPG signal.
    // This simplified version maps ADC amplitude to a plausible BPM range.
    int raw = analogRead(PPG_SENSOR_PIN);
    int bpm = map(raw, 0, 4095, 58, 102);
    if (bpm < 45 || bpm > 200) bpm = 72;
    return bpm;
}

float readHrvMs() {
    // Stub: real HRV requires R-R interval timing across multiple beats.
    // Returns a plausible resting HRV inversely correlated with BPM.
    int bpm = readHeartRateBpm();
    return constrain(110.0f - bpm + random(-5, 6), 18.0f, 90.0f);
}

int readBatteryPct() {
    // 100k + 100k voltage divider; LiPo max 4.2 V → ADC reads up to 2.1 V
    int raw = analogRead(BATTERY_PIN);
    float voltage = (raw / 4095.0f) * 2.0f * 3.3f;  // 3.3 V reference
    // Map 3.0 V (0%) → 4.2 V (100%)
    int pct = (int)(((voltage - 3.0f) / 1.2f) * 100.0f);
    return constrain(pct, 0, 100);
}

bool checkFall(float& outMagnitude) {
    if (!accel.begin()) { outMagnitude = 0; return false; }
    sensors_event_t event;
    accel.getEvent(&event);
    float x = event.acceleration.x / 9.80665f;
    float y = event.acceleration.y / 9.80665f;
    float z = event.acceleration.z / 9.80665f;
    outMagnitude = sqrt(x * x + y * y + z * z);
    return outMagnitude > FALL_G_THRESHOLD;
}

void fillAccelJson(JsonObject& imu) {
    if (!accel.begin()) return;
    sensors_event_t event;
    accel.getEvent(&event);
    imu["accel_x"] = event.acceleration.x / 9.80665f;
    imu["accel_y"] = event.acceleration.y / 9.80665f;
    imu["accel_z"] = event.acceleration.z / 9.80665f;
    // Gyroscope not on ADXL345; fill zeros (swap with MPU6050 for real gyro)
    imu["gyro_x"] = 0.0;
    imu["gyro_y"] = 0.0;
    imu["gyro_z"] = 0.0;
}

// ═══════════════════════════════════════════════════════════════════════════
// Build the canonical TelemetryPacket JSON (matches FastAPI Pydantic schema)
// ═══════════════════════════════════════════════════════════════════════════
void buildTelemetryJson(String& out) {
    StaticJsonDocument<768> doc;

    doc["device_id"]        = deviceUuid;
    doc["timestamp"]        = ""; // filled by server if blank; real impl: NTP time
    doc["battery_pct"]      = readBatteryPct();
    doc["connection_mode"]  = "WIFI";

    // GPS
    JsonObject gpsObj = doc.createNestedObject("gps");
    if (gps.location.isValid()) {
        gpsObj["lat"]        = gps.location.lat();
        gpsObj["lng"]        = gps.location.lng();
        gpsObj["accuracy_m"] = gps.hdop.isValid() ? gps.hdop.value() * 0.1f : 5.0f;
    } else {
        gpsObj["lat"]        = 37.7799;   // fallback coordinates (update to your location)
        gpsObj["lng"]        = -122.4183;
        gpsObj["accuracy_m"] = 99.0;
    }

    // Heart rate
    doc["heart_rate_bpm"] = readHeartRateBpm();
    doc["hrv_ms"]         = readHrvMs();

    // IMU
    JsonObject imu = doc.createNestedObject("accel");
    sensors_event_t event;
    if (accel.begin()) {
        accel.getEvent(&event);
        imu["x"] = event.acceleration.x / 9.80665f;
        imu["y"] = event.acceleration.y / 9.80665f;
        imu["z"] = event.acceleration.z / 9.80665f;
    } else {
        imu["x"] = 0.02; imu["y"] = 0.01; imu["z"] = 1.00;
    }

    JsonObject gyro = doc.createNestedObject("gyro");
    gyro["x"] = 0.0; gyro["y"] = 0.0; gyro["z"] = 0.0;

    serializeJson(doc, out);
}

// ═══════════════════════════════════════════════════════════════════════════
// Publish telemetry  (MQTT primary, HTTP fallback)
// ═══════════════════════════════════════════════════════════════════════════
void sendTelemetry() {
    if (strlen(deviceUuid) == 0) {
        registerDevice();
        if (strlen(deviceUuid) == 0) return;
    }

    // Opportunistic fall check — if fall detected, also send a fall event
    float magnitude = 0.0f;
    bool  hasFall   = checkFall(magnitude);
    if (hasFall) {
        sendFallEvent(magnitude);
    }

    String payload;
    buildTelemetryJson(payload);

    Serial.printf("[Telemetry] HR=%d BPM | Batt=%d%% | GPS=%s\n",
        readHeartRateBpm(), readBatteryPct(),
        gps.location.isValid() ? "locked" : "no lock");

    if (mqttEnabled && mqttClient.connected()) {
        // PRIMARY: MQTT
        String topic = mqttTopic("telemetry");
        mqttClient.publish(topic.c_str(), payload.c_str(), false);
    } else {
        // FALLBACK: HTTPS REST
        if (WiFi.status() != WL_CONNECTED) return;
        HTTPClient http;
        String url = String(BACKEND_URL) + "/api/v1/telemetry/ingest";
        http.begin(url);
        http.addHeader("Content-Type", "application/json");
        http.addHeader("X-Device-Key", DEVICE_PROV_SECRET);
        int code = http.POST(payload);
        if (code != 200 && code != 202) {
            Serial.printf("[Telemetry] HTTP error %d\n", code);
        }
        http.end();
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Fall event  →  autiguard/{id}/fall_event  OR  POST /events/fall/{id}
// ═══════════════════════════════════════════════════════════════════════════
void sendFallEvent(float impactG) {
    Serial.printf("[ALERT] Fall detected — impact=%.2fg\n", impactG);

    StaticJsonDocument<256> doc;
    doc["device_id"]             = deviceUuid;
    doc["impact_g"]              = impactG;
    doc["post_fall_inactivity_s"] = 4;   // simple stub; real: measure post-impact motion
    String payload;
    serializeJson(doc, payload);

    if (mqttEnabled && mqttClient.connected()) {
        mqttClient.publish(mqttTopic("fall_event").c_str(), payload.c_str(), false);
    } else {
        if (WiFi.status() != WL_CONNECTED) return;
        HTTPClient http;
        String url = String(BACKEND_URL) + "/api/v1/events/fall/" + deviceUuid;
        http.begin(url);
        http.addHeader("Content-Type", "application/json");
        http.addHeader("X-Device-Key", DEVICE_PROV_SECRET);
        http.POST(payload);
        http.end();
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Panic  →  autiguard/{id}/panic  OR  POST /events/panic/{id}
// ═══════════════════════════════════════════════════════════════════════════
void sendPanicEvent() {
    Serial.println("[ALERT] SOS PANIC button pressed!");

    StaticJsonDocument<384> doc;
    doc["device_id"] = deviceUuid;

    JsonObject gpsObj = doc.createNestedObject("gps");
    gpsObj["lat"]        = gps.location.isValid() ? gps.location.lat() : 37.7799;
    gpsObj["lng"]        = gps.location.isValid() ? gps.location.lng() : -122.4183;
    gpsObj["accuracy_m"] = 5.0;

    String payload;
    serializeJson(doc, payload);

    if (mqttEnabled && mqttClient.connected()) {
        // Panic uses QoS 2 (exactly-once) — PubSubClient doesn't expose QoS directly
        // via publish(); use MQTT AT_LEAST_ONCE (QoS 1) as the closest available option.
        mqttClient.publish(mqttTopic("panic").c_str(), payload.c_str(), true);
    } else {
        if (WiFi.status() != WL_CONNECTED) return;
        HTTPClient http;
        String url = String(BACKEND_URL) + "/api/v1/events/panic/" + deviceUuid;
        http.begin(url);
        http.addHeader("Content-Type", "application/json");
        http.addHeader("X-Device-Key", DEVICE_PROV_SECRET);
        http.POST(payload);
        http.end();
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Device heartbeat  →  autiguard/{id}/status  OR  POST /events/status/{id}
// ═══════════════════════════════════════════════════════════════════════════
void sendDeviceStatus() {
    StaticJsonDocument<256> doc;
    doc["device_id"]       = deviceUuid;
    doc["battery_pct"]     = readBatteryPct();
    doc["firmware_version"] = "2.0.0";
    doc["connection_mode"] = mqttEnabled ? "LTE" : "WIFI";

    long rssi = WiFi.RSSI();
    if      (rssi > -50) doc["signal_strength"] = "excellent";
    else if (rssi > -65) doc["signal_strength"] = "good";
    else if (rssi > -75) doc["signal_strength"] = "fair";
    else                 doc["signal_strength"] = "poor";

    String payload;
    serializeJson(doc, payload);

    if (mqttEnabled && mqttClient.connected()) {
        mqttClient.publish(mqttTopic("status").c_str(), payload.c_str(), false);
    } else {
        if (WiFi.status() != WL_CONNECTED) return;
        HTTPClient http;
        String url = String(BACKEND_URL) + "/api/v1/events/status/" + deviceUuid;
        http.begin(url);
        http.addHeader("Content-Type", "application/json");
        http.addHeader("X-Device-Key", DEVICE_PROV_SECRET);
        http.POST(payload);
        http.end();
    }
}
