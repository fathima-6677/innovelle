<div align="center">

# 🛡️ AutiGuard

### AI-Powered Wearable Safety & Emotional Monitoring Platform for Autism Spectrum Disorder

[![Python](https://img.shields.io/badge/Python-3.11+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.139-009688?style=for-the-badge&logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com)
[![React](https://img.shields.io/badge/React-19-61DAFB?style=for-the-badge&logo=react&logoColor=black)](https://react.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-6.0-3178C6?style=for-the-badge&logo=typescript&logoColor=white)](https://typescriptlang.org)
[![ESP32](https://img.shields.io/badge/ESP32-Firmware_v2.0-E7352C?style=for-the-badge&logo=espressif&logoColor=white)](https://espressif.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)](LICENSE)

<br/>

> **1 in 36 children in the US has autism. 91% of autistic individuals cannot independently communicate an emergency.**
>
> AutiGuard gives them a voice — and their caregivers the intelligence to act before a crisis escalates.

<br/>

**[▶ Watch Demo](#demo) · [⚡ Quick Start](#quick-start) · [🔬 AI/ML Layer](#aiml-inference-layer) · [🔌 Hardware](#hardware-integration)**

</div>

---

## 🧠 The Problem We're Solving

Individuals with Autism Spectrum Disorder (ASD) face daily, invisible risks that existing technology fails to address:

| Risk | Scale | Current Gap |
|------|-------|-------------|
| **Meltdown escalation** | Avg. 3–5 episodes/week for severe ASD | No early warning — caregivers react, not prevent |
| **Wandering & elopement** | 49% of children with ASD wander | Geofencing alerts exist, but most require a smartphone |
| **Falls & injury** | 3× higher rate than neurotypical peers | No wearable built for ASD context |
| **Non-verbal emergencies** | 25–30% of ASD individuals are minimally verbal | No system that bridges physiological state + emergency contact |
| **First responder gap** | 71% of officers untrained for ASD interactions | No instant disclosure of diagnosis to responders |

**AutiGuard is the first unified platform that solves all five simultaneously** — combining a purpose-built wearable, a multi-modal AI inference pipeline, and a real-time caregiver dashboard.

---

## ✨ What Makes AutiGuard Different

<table>
<tr>
<td width="50%">

### 🤖 Multi-Model AI Pipeline
Four independent AI models run in real time on every data packet:
- **Random Forest** → physiological stress index (0–100) from HRV + HR + motion
- **SVM** → fall detection using 3-axis accelerometer windowing
- **CNN on MFCC features** → vocal distress / crying / screaming detection  
- **LSTM** → behavioral trend prediction, 30-min meltdown risk forecasting

All models share a common `predict(features) → ModelResult` interface — swap in trained `.pkl` / `.tflite` artefacts without touching a single API line.

</td>
<td width="50%">

### 📡 Dual-Transport Hardware
The ESP32 wearable adapts to connectivity:
- **MQTT over WiFi/LTE-M** — primary, low-power, 5-second telemetry bursts
- **HTTPS REST fallback** — bench testing, poor signal environments
- **On-boot auto-registration** — UUID provisioning with scoped device JWTs
- **SOS panic button** — bypasses all queuing, dispatches in < 1 second

</td>
</tr>
<tr>
<td>

### 🔐 AES-Encrypted QR Emergency ID
A rotating, role-aware QR code embeds the wearer's identity and medical profile, encrypted with Fernet (AES-128-CBC + HMAC). Scanning reveals only what the accessor's role permits:

| Role | Sees |
|------|------|
| Emergency Responder | Name, emergency contact, critical ASD notes |
| Clinician | + HRV stress baseline, medication |
| Guardian | Full medical record |

Rotates every 24 h. Scan events audit-logged.

</td>
<td>

### ⚡ Sub-Second Real-Time Dashboard
The caregiver dashboard maintains a persistent WebSocket per device:
- Live heart rate, HRV, stress index, meltdown risk — update every 5 s
- Alert toasts for fall/panic/geofence/distress — arrive in < 200 ms
- Interactive Leaflet map with animated device marker and geofence overlay
- Non-verbal assist stream — wearer messages surface instantly

</td>
</tr>
</table>

---

## 🏗️ System Architecture

```
╔══════════════════════════════════════════════════════════════════════╗
║  WEARABLE LAYER  (ESP32 + PPG + ADXL345 + GPS + MEMS Mic + LTE-M)   ║
╚═══════════════════════════════╦══════════════════════════════════════╝
                                 │  MQTT (primary) / HTTPS (fallback)
                    ┌────────────▼────────────┐
                    │     INGESTION LAYER      │
                    │  FastAPI + MQTT Bridge   │
                    │  Pydantic v2 validation  │
                    │  Per-device rate limits  │
                    └────┬──────────┬──────────┘
                         │          │
           ┌─────────────▼──┐  ┌────▼──────────────────┐
           │  AI/ML ENGINE  │  │   STORAGE LAYER        │
           │  ─────────────  │  │   ──────────────────   │
           │  Stress RF     │  │   DynamoDB (hot TS)    │
           │  Fall SVM      │  │   PostgreSQL (relational)│
           │  Distress CNN  │  │   SQLite (local dev)   │
           │  Trend LSTM    │  └──────────────┬─────────┘
           └────────┬───────┘                 │
                    │                         │
                    └────────────┬────────────┘
                                 │  WebSocket broadcast
                    ┌────────────▼────────────┐
                    │   DASHBOARD LAYER        │
                    │  React + Vite + TS       │
                    │  Recharts · Leaflet       │
                    │  Tailwind CSS 4          │
                    └─────────────────────────┘
```

---

## 🎯 Core Features

### For Caregivers & Clinicians

| Feature | Description |
|---------|-------------|
| **Live Dashboard** | Real-time HR, HRV, stress index, meltdown risk — all updating live via WebSocket |
| **GPS Tracking** | Animated device marker on dark Leaflet map; geofence breach highlighted instantly |
| **Alert Center** | Filterable log of all events (fall / panic / stress / distress / geofence) with 1-click acknowledge |
| **Geofence Manager** | Click-to-place zone drawing on interactive map; radius slider preview; multi-zone colour coding |
| **QR Emergency ID** | Rotating encrypted QR badge; scan simulator with role inspector for compliance testing |
| **Telemetry History** | 24-hour Recharts area charts (HR / stress / battery) + full audit table with CSV export |
| **Non-Verbal Assist** | Live stream of wearer communication requests from wearable buttons |
| **Hardware Health** | Firmware version, battery, signal, per-sensor operational status |

### For Developers & Judges

| Capability | Implementation |
|-----------|---------------|
| **Zero-infrastructure local dev** | SQLite + JSON DynamoDB mock — runs with zero cloud config |
| **Full hardware simulation** | Python simulator replicates an ESP32 exactly; keyboard-controlled events |
| **Pluggable AI models** | Swap `.pkl` / `.tflite` files in — no API changes needed |
| **Production-ready auth** | PBKDF2 passwords, scoped device JWTs, RBAC role checker |
| **OpenAPI docs** | Full Swagger UI at `/docs`, ReDoc at `/redoc` |
| **HIPAA-aware design** | Data minimisation, audit logs, AES encryption at rest, TTL on raw telemetry |

---

## 🚀 Quick Start

### Prerequisites

| Tool | Minimum Version |
|------|----------------|
| Python | 3.11 |
| Node.js | 18 |
| npm | 9 |

### 1 · Clone & configure

```bash
git clone https://github.com/your-org/autiguard.git
cd autiguard

# Backend
cp backend/.env.example backend/.env

# Frontend  
cp frontend/.env.example frontend/.env
```

> The default `.env` uses SQLite + local DynamoDB mock — **no cloud account required.**

### 2 · Start the backend

```bash
cd backend
python -m venv venv

# Windows
venv\Scripts\activate
# macOS / Linux
source venv/bin/activate

pip install -r requirements.txt

# Listen on 0.0.0.0 so the ESP32 can reach it over LAN
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

You'll see:

```
INFO: AutiGuard backend services initialized
INFO: Relational database tables ready.
INFO: Telemetry processing worker started.
INFO: Application startup complete.
```

### 3 · Start the dashboard

```bash
cd frontend
npm install
npm run dev
```

Dashboard → **http://localhost:5173**  
API docs  → **http://localhost:8000/docs**

### 4 · Register & log in

```bash
curl -X POST http://localhost:8000/api/v1/users/register \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@autiguard.com","password":"Demo1234!","name":"Demo Guardian","role":"guardian"}'
```

Or use the **Register** form in the browser.

---

## 🤖 Demo Without Hardware

The Python simulator fully replicates the ESP32 wearable and drives the entire pipeline — perfect for judging sessions when the physical prototype isn't available.

```bash
# In backend/ with venv active
python scripts/simulate_device.py
```

The simulator auto-registers a device, then streams live telemetry every 5 seconds. Use these keyboard commands to trigger events:

| Key | What it does | What you see in the dashboard |
|-----|-------------|-------------------------------|
| `h` | Spike heart rate to ~130 BPM | Stress Index jumps; possible stress alert |
| `f` | Fall impact (6 g spike) | Critical fall alert appears instantly |
| `p` | SOS panic button press | Red PANIC banner, Twilio SMS dispatched |
| `o` | Teleport GPS outside geofence | Orange GEOFENCE BREACH toast |
| `r` | Reset GPS to safe zone | Breach resolves, marker returns to zone |
| `d` | Trigger vocal distress audio | Audio CNN detects screaming; high alert |
| `n` | Normalize all vitals | All metrics return to baseline |
| `q` | Quit |  |

> **Tip for judges:** Open the dashboard in one window and the simulator in another. Every keystroke produces a visible, sub-second response in the UI.

---

## 🔬 AI/ML Inference Layer

All models live in `backend/ai_engine/` and share a common interface:

```python
result = ai_engine.stress(hr=118, hrv=28, ax=0.4, ay=0.1, az=0.9)
# ModelResult(score=81.3, label='high', confidence=0.81, raw={...})
```

### Model Overview

| Model | Algorithm | Inputs | Output | Trigger |
|-------|-----------|--------|--------|---------|
| **Stress Detection** | Random Forest | HRV, HR, 3-axis accel, hour-of-day | `score` 0–100, risk label | Every telemetry packet |
| **Fall Detection** | SVM + phase rules | 3-axis accel, peak impact g, post-fall inactivity | `confirmed_fall` / `possible_fall` | Fall event + IMU stream |
| **Distress Audio** | CNN on MFCC | Base64 MFCC feature vector, device confidence | `confirmed_distress` / `possible_distress` | Audio event |
| **Behavioral Trend** | LSTM rolling window | Last 50 stress scores per device | `meltdown_risk` 0–100, trend label | Every packet (async) |

### Alert Rule Engine

After each model run, thresholds trigger alerts and WebSocket broadcasts:

```
stress_score > 75 for 2+ consecutive readings  →  "stress" alert (warning)
fall_label == "confirmed_fall"                  →  "fall" alert (critical) + SMS
distress_label == "confirmed_distress"          →  "distress" alert (high)
GPS outside geofence radius                     →  "geofence" alert (critical) + SMS
Panic button pressed                            →  "panic" alert (critical) + SMS bypass queue
```

### Upgrading to Real Trained Models

The interface is designed for drop-in replacement:

```python
# ai_engine/stress_model.py  — swap 3 lines
import joblib
self._clf = joblib.load("ai_engine/artefacts/stress_rf.pkl")
prob = self._clf.predict_proba([feature_vector])[0][1]
```

No changes needed in routes, schemas, or the dashboard.

---

## 🔌 Hardware Integration

### Wiring Diagram

```
ESP32 Dev Module
├── GPIO 34 (ADC1) ──── PPG Heart Rate Sensor (analog)
├── GPIO 21 (SDA)  ──── ADXL345 Accelerometer
├── GPIO 22 (SCL)  ──── ADXL345 Accelerometer
├── GPIO 16 (RX2)  ──── L86 / Neo-6M GPS (TX)
├── GPIO 17 (TX2)  ──── L86 / Neo-6M GPS (RX)
├── GPIO 12        ──── SOS Panic Button → GND (INPUT_PULLUP)
└── GPIO 35 (ADC1) ──── Battery Voltage Divider (100kΩ + 100kΩ)
```

### Flash the Firmware

1. Open `backend/esp32_autiguard_sketch/esp32_autiguard_sketch.ino`
2. Edit the config block (lines 30–50):

```cpp
const char* WIFI_SSID         = "YourWifi";
const char* WIFI_PASSWORD     = "YourPassword";
const char* BACKEND_URL       = "http://192.168.1.XXX:8000";  // your PC's LAN IP
const char* DEVICE_PROV_SECRET = "esp32_factory_secret_2026";
const char* DEVICE_SERIAL     = "ESP32_AUTIGUARD_001";
```

3. Install Arduino libraries: `ArduinoJson` · `Adafruit ADXL345` · `TinyGPS++` · `PubSubClient`
4. Board: **ESP32 Dev Module** · Baud: **115200**
5. Flash → open Serial Monitor → device registers and starts streaming

### Data Flow (Physical Hardware)

```
ESP32 ──(WiFi/LTE-M)──► POST /api/v1/telemetry/ingest
                              │
                    ┌─────────▼──────────┐
                    │  Pydantic validate  │
                    │  DynamoDB write     │
                    │  Geofence check     │
                    └─────────┬──────────┘
                              │ async queue
                    ┌─────────▼──────────┐
                    │  AI Engine         │
                    │  Stress RF         │
                    │  Fall SVM          │
                    │  Distress CNN      │
                    │  Trend LSTM        │
                    └─────────┬──────────┘
                              │ WebSocket broadcast
                    ┌─────────▼──────────┐
                    │  Dashboard updates │
                    │  in < 200 ms       │
                    └────────────────────┘
```

---

## 🗂️ Project Structure

```
autiguard/
├── backend/
│   ├── ai_engine/              ← AI models (pluggable interface)
│   │   ├── base.py             ModelResult + BaseModel
│   │   ├── stress_model.py     Random Forest stress detection
│   │   ├── fall_model.py       SVM fall detection
│   │   ├── distress_model.py   CNN distress audio
│   │   ├── behavioral_model.py LSTM meltdown prediction
│   │   └── engine.py           Unified AIEngine facade
│   ├── app/
│   │   ├── api/v1/             FastAPI route handlers
│   │   ├── core/               Config, security, rate limiter
│   │   ├── db/                 DynamoDB + PostgreSQL clients
│   │   ├── models/             SQLAlchemy ORM
│   │   ├── schemas/            Pydantic v2 schemas
│   │   ├── services/           Ingestion pipeline, MQTT bridge, QR, notifications
│   │   ├── ws/                 WebSocket connection manager
│   │   └── main.py             App entrypoint + lifespan
│   ├── esp32_autiguard_sketch/ ESP32 Arduino firmware v2.0
│   ├── scripts/
│   │   └── simulate_device.py  Interactive hardware simulator
│   ├── requirements.txt
│   └── .env.example
│
└── frontend/
    ├── src/
    │   ├── api/                HTTP client + WebSocket hook
    │   ├── components/         Reusable UI (map, chart, alert banner, tiles)
    │   ├── pages/              8 full dashboard pages
    │   └── types.ts            Shared TypeScript interfaces
    ├── package.json
    └── .env.example
```

---

## 🛡️ Security & Compliance Design

| Concern | Implementation |
|---------|---------------|
| **Device authentication** | Per-device provisioning secret + scoped JWT (`device:telemetry:write`) |
| **Caregiver authentication** | PBKDF2-SHA256 password hashing; 24 h JWT access tokens |
| **QR payload encryption** | Fernet (AES-128-CBC + HMAC-SHA256); 24 h rotation |
| **Role-based access** | 5-tier RBAC: emergency_responder → caregiver → clinician → guardian → admin |
| **Rate limiting** | 120 req/min per IP on ingestion endpoints (slowapi) |
| **Audit trail** | Every QR scan, alert acknowledgment, and geofence edit logged |
| **Data minimisation** | Raw audio clips auto-delete after N days; GDPR/HIPAA-aware model |
| **Transport security** | HTTPS/mqtts in production; TLS-capable ESP32 firmware (WiFiClientSecure) |

---

## 🌐 Production Architecture (AWS)

```
ESP32 ──mqtts──► AWS IoT Core ──► MQTT Bridge (aiomqtt)
                                         │
                               ┌─────────▼──────────┐
                               │  ECS Fargate        │
                               │  FastAPI + ai_engine │
                               └──┬──────────┬───────┘
                                  │          │
                        ┌─────────▼──┐  ┌────▼──────────────┐
                        │ RDS Aurora  │  │ DynamoDB on-demand │
                        │ PostgreSQL  │  │ (telemetry TS)     │
                        └────────────┘  └────────────────────┘
                                                │
                                   ┌────────────▼────────────┐
                                   │ CloudFront + S3 / Amplify│
                                   │ (React SPA)              │
                                   └──────────────────────────┘
```

---

## 📡 API Reference

Full interactive docs: **http://localhost:8000/docs**

### Device-Facing (auth: `X-Device-Key`)

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `POST` | `/api/v1/telemetry/ingest` | Stream telemetry (HR, GPS, IMU) |
| `POST` | `/api/v1/events/fall/{id}` | Report fall event |
| `POST` | `/api/v1/events/audio/{id}` | Report distress audio |
| `POST` | `/api/v1/events/panic/{id}` | SOS panic button |
| `POST` | `/api/v1/events/status/{id}` | Device heartbeat |

### Caregiver-Facing (auth: `Bearer <jwt>`)

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `POST` | `/api/v1/users/register` | Create account |
| `GET` | `/api/v1/dashboard/summary/{id}` | Dashboard snapshot |
| `GET` | `/api/v1/telemetry/history/{id}` | 24 h telemetry log |
| `GET` | `/api/v1/alerts/list/{id}` | Alert history |
| `PATCH` | `/api/v1/alerts/{id}/acknowledge` | Acknowledge alert |
| `POST` | `/api/v1/geofence/` | Create safe zone |
| `GET` | `/api/v1/identity_qr/display/{id}` | Get/rotate QR |
| `POST` | `/api/v1/identity_qr/scan` | Decode QR with RBAC |

### WebSocket

```
ws://host:8000/api/v1/telemetry/ws/v1/devices/{device_id}?token=<jwt>
```

| Event type | Fired when |
|-----------|-----------|
| `telemetry.update` | Every ingested packet (post AI processing) |
| `alert.new` | Fall / panic / stress / distress / geofence |
| `device.status` | Battery or connection mode changes |
| `nonverbal.new` | Wearer sends a communication request |

---

## 🧰 Tech Stack

| Layer | Technology |
|-------|-----------|
| **Firmware** | ESP32 (Arduino C++), ADXL345, PPG, GPS, MQTT |
| **Backend** | Python 3.11, FastAPI, Uvicorn, Pydantic v2, SQLAlchemy 2.0 async |
| **AI/ML** | scikit-learn (RF), custom SVM, CNN-ready interface, LSTM rolling window |
| **Databases** | SQLite (dev), PostgreSQL/Aurora (prod), DynamoDB (telemetry TS) |
| **Messaging** | MQTT (aiomqtt), WebSocket (FastAPI native) |
| **Frontend** | React 19, TypeScript 6, Vite 8, Tailwind CSS 4 |
| **UI Libraries** | Recharts, React-Leaflet, Lucide React |
| **Auth** | PBKDF2-SHA256, JWT (PyJWT), RBAC |
| **Notifications** | Twilio SMS |
| **Deployment** | Docker, AWS ECS/Fargate, RDS, DynamoDB, CloudFront |

---

## 👥 Team Antigravity

Built with ❤️ for the ASD community.

*"We didn't build a monitoring app. We built a safety net."*

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

<div align="center">

**If AutiGuard helps even one family feel safer, we've won.**

⭐ Star this repo if you believe technology should serve those who need it most.

</div>
