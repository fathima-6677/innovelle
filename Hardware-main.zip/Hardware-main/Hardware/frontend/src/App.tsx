import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import DeviceStatus from './pages/DeviceStatus';
import Alerts from './pages/Alerts';
import History from './pages/History';
import QRIdentity from './pages/QRIdentity';
import NonVerbalAssist from './pages/NonVerbalAssist';
import GeofenceManager from './pages/GeofenceManager';
import Settings from './pages/Settings';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />

        <Route element={<Layout />}>
          <Route path="/dashboard"  element={<Dashboard />} />
          <Route path="/device-status" element={<DeviceStatus />} />
          <Route path="/alerts"     element={<Alerts />} />
          <Route path="/history"    element={<History />} />
          <Route path="/geofences"  element={<GeofenceManager />} />
          <Route path="/qr-identity" element={<QRIdentity />} />
          <Route path="/nonverbal"  element={<NonVerbalAssist />} />
          <Route path="/settings"   element={<Settings />} />

          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
