import React from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  MapContainer,
  TileLayer,
  Circle,
  Marker,
  Popup,
  useMapEvents,
  useMap,
} from 'react-leaflet';
import L from 'leaflet';
import { api } from '../api/httpClient';
import type { GeofenceConfig } from '../types';
import {
  Shield,
  Plus,
  Trash2,
  Save,
  MapPin,
  AlertCircle,
  Loader2,
  Info,
} from 'lucide-react';

interface OutletContextType {
  selectedDeviceId: string;
}

// ── Custom pin icon for the draggable center marker ─────────────────────────
const centerIcon = L.divIcon({
  className: '',
  html: `<div style="
    width:22px;height:22px;border-radius:50%;
    background:#4ED9C3;border:3px solid #0f172a;
    box-shadow:0 0 0 3px rgba(78,217,195,0.35);
  "></div>`,
  iconSize: [22, 22],
  iconAnchor: [11, 11],
});

// ── Recenter helper ──────────────────────────────────────────────────────────
const MapRecenter: React.FC<{ center: [number, number] }> = ({ center }) => {
  const map = useMap();
  React.useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
};

// ── Click handler: places new geofence center on map click ──────────────────
interface ClickHandlerProps {
  onMapClick: (lat: number, lng: number) => void;
  enabled: boolean;
}
const ClickHandler: React.FC<ClickHandlerProps> = ({ onMapClick, enabled }) => {
  useMapEvents({
    click(e) {
      if (enabled) onMapClick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
};

// ── Colour palette for multiple zones ───────────────────────────────────────
const ZONE_COLORS = ['#4ED9C3', '#8B5CF6', '#F59E0B', '#3B82F6', '#EF4444', '#10B981'];

// ═══════════════════════════════════════════════════════════════════════════
// Main component
// ═══════════════════════════════════════════════════════════════════════════
export const GeofenceManager: React.FC = () => {
  const { selectedDeviceId } = useOutletContext<OutletContextType>();

  // Existing zones
  const [zones, setZones] = React.useState<GeofenceConfig[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);
  const [statusMsg, setStatusMsg] = React.useState<{ text: string; ok: boolean } | null>(null);

  // New zone being drawn
  const [drawMode, setDrawMode] = React.useState(false);
  const [newName, setNewName] = React.useState('Home Zone');
  const [newLat, setNewLat] = React.useState(37.7799);
  const [newLng, setNewLng] = React.useState(-122.4183);
  const [newRadius, setNewRadius] = React.useState(150);

  // ── Fetch existing geofences ──────────────────────────────────────────────
  const fetchZones = React.useCallback(async () => {
    if (!selectedDeviceId) { setZones([]); setLoading(false); return; }
    setLoading(true);
    try {
      const data: GeofenceConfig[] = await api.get(`/geofence/device/${selectedDeviceId}`);
      setZones(data);
    } catch {
      setZones([]);
    } finally {
      setLoading(false);
    }
  }, [selectedDeviceId]);

  React.useEffect(() => { fetchZones(); }, [fetchZones]);

  // ── Map click handler ─────────────────────────────────────────────────────
  const handleMapClick = (lat: number, lng: number) => {
    setNewLat(parseFloat(lat.toFixed(6)));
    setNewLng(parseFloat(lng.toFixed(6)));
  };

  // ── Save new zone ─────────────────────────────────────────────────────────
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDeviceId) return;
    setSaving(true);
    try {
      await api.post(`/geofence/?device_id=${selectedDeviceId}`, {
        name: newName,
        center_lat: newLat,
        center_lng: newLng,
        radius_meters: newRadius,
      });
      flash('Safe zone saved successfully.', true);
      setDrawMode(false);
      await fetchZones();
    } catch (err: any) {
      flash(err.message || 'Failed to save zone.', false);
    } finally {
      setSaving(false);
    }
  };

  // ── Delete zone ───────────────────────────────────────────────────────────
  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await api.delete(`/geofence/${id}`);
      flash('Zone removed.', true);
      setZones(prev => prev.filter(z => z.id !== id));
    } catch (err: any) {
      flash(err.message || 'Delete failed.', false);
    } finally {
      setDeletingId(null);
    }
  };

  const flash = (text: string, ok: boolean) => {
    setStatusMsg({ text, ok });
    setTimeout(() => setStatusMsg(null), 4500);
  };

  // Map viewport — center on first zone or new center
  const mapCenter: [number, number] = zones.length > 0
    ? [zones[0].center_lat, zones[0].center_lng]
    : [newLat, newLng];

  // ── No device selected ────────────────────────────────────────────────────
  if (!selectedDeviceId) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] border border-dashed border-brand-border rounded-xl p-8 max-w-xl mx-auto">
        <Shield size={40} className="text-gray-500 mb-4 animate-pulse" />
        <h3 className="text-md font-bold text-gray-200">No Device Selected</h3>
        <p className="text-xs text-gray-400 text-center mt-1">
          Select a paired device from the header to manage geofences.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-6xl mx-auto">

      {/* Toast ───────────────────────────────────────────────────────── */}
      {statusMsg && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-lg text-xs font-bold
          shadow-2xl flex items-center gap-2 border animate-pulse ${
          statusMsg.ok
            ? 'bg-brand-accent/10 border-brand-accent/30 text-brand-accent'
            : 'bg-red-500/10 border-red-500/30 text-red-400'
        }`}>
          <AlertCircle size={15} />
          {statusMsg.text}
        </div>
      )}

      {/* Header ──────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-gray-200 flex items-center gap-2">
            <Shield size={16} className="text-brand-accent" />
            Geofence Safe Zones
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            {zones.length} active zone{zones.length !== 1 ? 's' : ''} — breaches trigger instant alerts
          </p>
        </div>
        <button
          onClick={() => setDrawMode(prev => !prev)}
          className={`flex items-center gap-1.5 text-xs font-bold px-4 py-2 rounded-lg border transition-all cursor-pointer ${
            drawMode
              ? 'bg-brand-accent text-brand-bg border-brand-accent'
              : 'bg-brand-bg border-brand-border text-brand-accent hover:border-brand-accent/50'
          }`}
        >
          <Plus size={14} />
          {drawMode ? 'Cancel Drawing' : 'New Zone'}
        </button>
      </div>

      {/* Map + sidebar layout ────────────────────────────────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

        {/* Interactive Leaflet Map ─────────────────────────────────────*/}
        <div className="xl:col-span-2 bg-brand-card border border-brand-border rounded-xl overflow-hidden shadow-lg">

          {drawMode && (
            <div className="flex items-center gap-2 px-4 py-2.5 bg-brand-accent/10 border-b border-brand-accent/20 text-xs text-brand-accent font-bold">
              <Info size={13} />
              Click on the map to place the geofence center, then adjust the radius below.
            </div>
          )}

          <div style={{ height: '440px' }}>
            <MapContainer
              center={mapCenter}
              zoom={15}
              scrollWheelZoom
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
                url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
              />

              {/* Recenter when switching device */}
              <MapRecenter center={mapCenter} />

              {/* Click to place center in draw mode */}
              <ClickHandler onMapClick={handleMapClick} enabled={drawMode} />

              {/* Existing zones */}
              {zones.map((zone, idx) => {
                const color = ZONE_COLORS[idx % ZONE_COLORS.length];
                return (
                  <React.Fragment key={zone.id}>
                    <Circle
                      center={[zone.center_lat, zone.center_lng]}
                      radius={zone.radius_meters}
                      pathOptions={{
                        color,
                        fillColor: color,
                        fillOpacity: 0.10,
                        weight: 2,
                      }}
                    />
                    <Marker
                      position={[zone.center_lat, zone.center_lng]}
                      icon={L.divIcon({
                        className: '',
                        html: `<div style="
                          width:18px;height:18px;border-radius:50%;
                          background:${color};border:2px solid #0f172a;
                          box-shadow:0 0 0 2px ${color}55;
                        "></div>`,
                        iconSize: [18, 18],
                        iconAnchor: [9, 9],
                      })}
                    >
                      <Popup>
                        <div className="text-xs font-sans p-1 text-slate-800">
                          <p className="font-bold">{zone.name}</p>
                          <p className="text-[10px] text-slate-500 mt-0.5">
                            Radius: {zone.radius_meters}m
                          </p>
                        </div>
                      </Popup>
                    </Marker>
                  </React.Fragment>
                );
              })}

              {/* Preview of new zone while drawing */}
              {drawMode && (
                <>
                  <Circle
                    center={[newLat, newLng]}
                    radius={newRadius}
                    pathOptions={{
                      color: '#4ED9C3',
                      fillColor: '#4ED9C3',
                      fillOpacity: 0.12,
                      weight: 2,
                      dashArray: '6 4',
                    }}
                  />
                  <Marker position={[newLat, newLng]} icon={centerIcon}>
                    <Popup>
                      <span className="text-xs font-sans text-slate-700">New zone center</span>
                    </Popup>
                  </Marker>
                </>
              )}
            </MapContainer>
          </div>
        </div>

        {/* Sidebar ─────────────────────────────────────────────────────*/}
        <div className="xl:col-span-1 space-y-4">

          {/* Draw / edit form */}
          {drawMode && (
            <form
              onSubmit={handleSave}
              className="bg-brand-card border border-brand-accent/30 rounded-xl p-5 shadow-lg space-y-4"
            >
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-brand-accent">
                Configure New Zone
              </h4>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                  Zone Name
                </label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  placeholder="e.g. Home Zone"
                  className="w-full bg-brand-bg border border-brand-border rounded-lg px-3 py-2
                    text-xs text-gray-100 placeholder-gray-500 focus:outline-none focus:border-brand-accent"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                    Latitude
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={newLat}
                    onChange={e => setNewLat(Number(e.target.value))}
                    className="w-full bg-brand-bg border border-brand-border rounded-lg px-3 py-2
                      text-xs text-gray-100 font-mono focus:outline-none focus:border-brand-accent"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                    Longitude
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={newLng}
                    onChange={e => setNewLng(Number(e.target.value))}
                    className="w-full bg-brand-bg border border-brand-border rounded-lg px-3 py-2
                      text-xs text-gray-100 font-mono focus:outline-none focus:border-brand-accent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1 flex justify-between">
                  <span>Safe Radius</span>
                  <span className="text-brand-accent font-mono">{newRadius} m</span>
                </label>
                <input
                  type="range"
                  min={30}
                  max={1000}
                  step={10}
                  value={newRadius}
                  onChange={e => setNewRadius(Number(e.target.value))}
                  className="w-full accent-brand-accent cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-gray-500 mt-0.5">
                  <span>30 m</span><span>1000 m</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full bg-brand-accent text-brand-bg hover:bg-brand-accent/90
                  disabled:opacity-50 text-xs font-bold py-2.5 rounded-lg flex items-center
                  justify-center gap-1.5 cursor-pointer transition-colors"
              >
                {saving
                  ? <Loader2 size={14} className="animate-spin" />
                  : <Save size={14} />
                }
                {saving ? 'Saving…' : 'Save Zone'}
              </button>
            </form>
          )}

          {/* Existing zones list */}
          <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-gray-300 mb-3">
              Active Zones ({zones.length})
            </h4>

            {loading ? (
              <div className="flex items-center gap-2 text-xs text-gray-500 py-4 justify-center">
                <Loader2 size={14} className="animate-spin" /> Loading zones…
              </div>
            ) : zones.length === 0 ? (
              <p className="text-xs text-gray-500 italic text-center py-4">
                No safe zones configured yet.<br />
                Click "New Zone" to draw one on the map.
              </p>
            ) : (
              <div className="space-y-2">
                {zones.map((zone, idx) => {
                  const color = ZONE_COLORS[idx % ZONE_COLORS.length];
                  return (
                    <div
                      key={zone.id}
                      className="flex items-center justify-between bg-brand-bg/50
                        border border-brand-border/40 rounded-lg px-3 py-2.5"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {/* Color swatch */}
                        <span
                          className="shrink-0 w-3 h-3 rounded-full border border-brand-border/60"
                          style={{ backgroundColor: color }}
                        />
                        <div className="truncate">
                          <p className="text-xs font-bold text-gray-200 truncate">{zone.name}</p>
                          <p className="text-[10px] font-mono text-gray-500">
                            <MapPin size={9} className="inline mr-0.5" />
                            {zone.center_lat.toFixed(4)}, {zone.center_lng.toFixed(4)}
                            &nbsp;·&nbsp;{zone.radius_meters} m
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDelete(zone.id)}
                        disabled={deletingId === zone.id}
                        className="shrink-0 ml-2 text-red-400 hover:text-red-300
                          disabled:opacity-40 transition-colors cursor-pointer"
                        title="Remove zone"
                      >
                        {deletingId === zone.id
                          ? <Loader2 size={14} className="animate-spin" />
                          : <Trash2 size={14} />
                        }
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Info card */}
          <div className="bg-brand-bg/40 border border-brand-border/30 rounded-xl p-4 text-[11px] text-gray-500 leading-relaxed">
            <p className="font-bold text-gray-400 mb-1">How geofencing works</p>
            Every telemetry packet from the wearable is checked against all active zones using
            the Haversine formula. When the wearer exits a boundary the backend immediately
            generates a <span className="text-brand-accent font-mono">geofence</span> alert,
            broadcasts it over WebSocket to the dashboard, and (if configured) dispatches an
            SMS via Twilio.
          </div>
        </div>
      </div>
    </div>
  );
};

export default GeofenceManager;
