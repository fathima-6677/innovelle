import React from 'react';
import { useOutletContext, useNavigate } from 'react-router-dom';
import { api } from '../api/httpClient';
import { useDeviceWebSocket } from '../api/wsClient';
import { DeviceStatusCard } from '../components/DeviceStatusCard';
import { LiveSensorTile } from '../components/LiveSensorTile';
import { LocationMap } from '../components/LocationMap';
import type { DeviceStatus, SensorReading, GeofenceConfig } from '../types';
import { Heart, Activity, Battery, MapPin, Bell, ShieldAlert, Cpu, CheckCircle, BrainCircuit, ActivitySquare } from 'lucide-react';

interface OutletContextType {
  selectedDeviceId: string;
  alerts: any[];
}

export const Dashboard: React.FC = () => {
  const { selectedDeviceId, alerts } = useOutletContext<OutletContextType>();
  const navigate = useNavigate();
  
  const [device, setDevice] = React.useState<DeviceStatus | null>(null);
  const [latestReading, setLatestReading] = React.useState<SensorReading | null>(null);
  const [geofence, setGeofence] = React.useState<GeofenceConfig | null>(null);
  
  const [loading, setLoading] = React.useState(true);

  // Load summary state on device selection change
  React.useEffect(() => {
    if (!selectedDeviceId) {
      setDevice(null);
      setLatestReading(null);
      setGeofence(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    const fetchDashboardSummary = async () => {
      try {
        const summary = await api.get(`/dashboard/summary/${selectedDeviceId}`);
        setDevice(summary.device);
        setGeofence(summary.geofences.length > 0 ? summary.geofences[0] : null);
        
        if (summary.latest_telemetry) {
          setLatestReading({
            device_id: selectedDeviceId,
            timestamp: summary.latest_telemetry.timestamp,
            battery_pct: summary.latest_telemetry.battery_pct,
            gps: summary.latest_telemetry.gps,
            heart_rate_bpm: summary.latest_telemetry.heart_rate_bpm,
            hrv_ms: summary.latest_telemetry.hrv_ms,
            accel: summary.latest_telemetry.accel,
            gyro: summary.latest_telemetry.gyro,
            stress_index: summary.latest_telemetry.stress_index,
            stress_risk: summary.latest_telemetry.stress_risk,
            behavioral_trend_risk: summary.latest_telemetry.behavioral_trend_risk,
            behavioral_trend_status: summary.latest_telemetry.behavioral_trend_status,
          });
        } else {
          setLatestReading(null);
        }
      } catch (err) {
        console.error("Failed to load dashboard summary payload:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardSummary();
  }, [selectedDeviceId]);

  // Subscribe to real-time telemetry streaming updates via WebSocket
  useDeviceWebSocket(selectedDeviceId ? selectedDeviceId : null, (event) => {
    console.log("WebSocket event in Dashboard page:", event);
    if (event.type === 'telemetry.update') {
      const payload = event.data;
      setLatestReading({
        device_id: payload.device_id,
        timestamp: payload.timestamp,
        battery_pct: payload.battery_pct,
        gps: payload.gps,
        heart_rate_bpm: payload.heart_rate_bpm,
        hrv_ms: payload.hrv_ms,
        accel: payload.accel,
        gyro: payload.gyro,
        stress_index: payload.stress_index,
        stress_risk: payload.stress_risk,
        behavioral_trend_risk: payload.behavioral_trend_risk,
        behavioral_trend_status: payload.behavioral_trend_status,
      });

      // Maintain synced battery and connection mode on status card
      if (device) {
        setDevice(prev => prev ? {
          ...prev,
          battery_pct: payload.battery_pct,
          is_online: true,
          last_seen: payload.timestamp
        } : null);
      }
    } else if (event.type === 'device.status') {
      const payload = event.data;
      setDevice({
        device_id: payload.device_id,
        name: payload.name,
        firmware_version: payload.firmware_version,
        battery_pct: payload.battery_pct,
        connection_mode: payload.connection_mode,
        last_seen: payload.last_seen,
        is_online: payload.is_online
      });
    }
  });

  const activeAlertsCount = React.useMemo(() => {
    return alerts.filter(a => !a.acknowledged).length;
  }, [alerts]);

  const getHrvStatus = (hrv: number) => {
    if (hrv < 35) return { text: 'Low HRV (Stressed)', type: 'warning' as const };
    if (hrv > 75) return { text: 'Excellent HRV', type: 'success' as const };
    return { text: 'Balanced Baseline', type: 'success' as const };
  };

  const getStressStatus = (score: number, risk: string) => {
    if (score > 75 || risk === 'high') return { text: 'Critical Stress Risk', type: 'error' as const };
    if (score > 45 || risk === 'medium') return { text: 'Mild Anxiety', type: 'warning' as const };
    return { text: 'Calm Status', type: 'success' as const };
  };

  const getLSTMStatus = (score: number) => {
    if (score > 70) return { text: 'LSTM: High Meltdown Risk', type: 'error' as const };
    if (score > 40) return { text: 'LSTM: Mild Escalation', type: 'warning' as const };
    return { text: 'LSTM: Emotional Stability', type: 'success' as const };
  };

  if (!selectedDeviceId) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] text-center border-2 border-dashed border-brand-border rounded-2xl p-8 max-w-xl mx-auto">
        <Cpu size={48} className="text-gray-500 mb-4 animate-pulse" />
        <h3 className="text-lg font-bold text-gray-200">No Device Linked</h3>
        <p className="text-sm text-gray-400 mt-2 max-w-md">
          To start monitoring vital safety data, please navigate to the Settings page and pair a wearable device identifier.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Overview Stats Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Device Status Card */}
        <div className="lg:col-span-1">
          <DeviceStatusCard deviceId={selectedDeviceId} device={device} />
        </div>

        {/* Live Vitals (Heart Rate + HRV) */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
          <LiveSensorTile
            title="Heart Rate (PPG)"
            value={latestReading && latestReading.heart_rate_bpm ? latestReading.heart_rate_bpm : '--'}
            unit="BPM"
            icon={<Heart size={22} />}
            trend={latestReading && latestReading.heart_rate_bpm && latestReading.heart_rate_bpm > 90 ? 'up' : 'stable'}
            isPulsingHeart={latestReading && latestReading.heart_rate_bpm ? latestReading.heart_rate_bpm > 0 : false}
            bpm={latestReading && latestReading.heart_rate_bpm ? latestReading.heart_rate_bpm : 72}
            statusText={
              !latestReading ? 'No Connection' :
              latestReading.heart_rate_bpm && latestReading.heart_rate_bpm > 100 ? 'Elevated Vitals' :
              latestReading.heart_rate_bpm && latestReading.heart_rate_bpm < 55 ? 'Bradycardia baseline' :
              'Optimal heart rate'
            }
            statusType={
              !latestReading ? 'neutral' :
              latestReading.heart_rate_bpm && (latestReading.heart_rate_bpm > 100 || latestReading.heart_rate_bpm < 55) ? 'warning' :
              'success'
            }
            description={latestReading ? `Updated ${new Date(latestReading.timestamp).toLocaleTimeString()}` : 'Waiting for telemetry...'}
          />

          <LiveSensorTile
            title="Vitals Variability (HRV)"
            value={latestReading && latestReading.hrv_ms ? latestReading.hrv_ms.toFixed(1) : '--'}
            unit="ms"
            icon={<Activity size={22} />}
            trend={latestReading && latestReading.hrv_ms && latestReading.hrv_ms < 40 ? 'down' : 'stable'}
            statusText={latestReading && latestReading.hrv_ms ? getHrvStatus(latestReading.hrv_ms).text : 'No Connection'}
            statusType={latestReading && latestReading.hrv_ms ? getHrvStatus(latestReading.hrv_ms).type : 'neutral'}
            description={latestReading ? 'AutiGuard HRV baselining' : 'Waiting for telemetry...'}
          />
        </div>
      </div>

      {/* ASD Specific Models (Stress Random Forest + LSTM Trend prediction) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <LiveSensorTile
          title="Physiological Stress (RF)"
          value={latestReading && latestReading.stress_index !== undefined ? latestReading.stress_index.toFixed(1) : '--'}
          unit="%"
          icon={<ActivitySquare size={22} />}
          trend={latestReading && latestReading.stress_risk === 'high' ? 'up' : 'stable'}
          statusText={latestReading && latestReading.stress_index !== undefined ? getStressStatus(latestReading.stress_index, latestReading.stress_risk || '').text : 'Calculating Baseline'}
          statusType={latestReading && latestReading.stress_index !== undefined ? getStressStatus(latestReading.stress_index, latestReading.stress_risk || '').type : 'neutral'}
          description="Fuses HRV, motion intensity, and temporal baselines."
        />

        <LiveSensorTile
          title="Predictive Meltdown Risk (LSTM)"
          value={latestReading && latestReading.behavioral_trend_risk !== undefined ? latestReading.behavioral_trend_risk.toFixed(1) : '--'}
          unit="%"
          icon={<BrainCircuit size={22} />}
          trend={latestReading && latestReading.behavioral_trend_risk && latestReading.behavioral_trend_risk > 50 ? 'up' : 'stable'}
          statusText={latestReading && latestReading.behavioral_trend_risk !== undefined ? getLSTMStatus(latestReading.behavioral_trend_risk).text : 'LSTM Model Inactive'}
          statusType={latestReading && latestReading.behavioral_trend_risk !== undefined ? getLSTMStatus(latestReading.behavioral_trend_risk).type : 'neutral'}
          description="Predictive emotional trajectory within the next 2 hours."
        />
      </div>

      {/* Main Dashboard Body: GPS Map + Auxiliary Vitals Panel */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* GPS Location Map */}
        <div className="xl:col-span-2">
          <LocationMap
            lat={latestReading && latestReading.gps ? latestReading.gps.lat : 0}
            lng={latestReading && latestReading.gps ? latestReading.gps.lng : 0}
            geofence={geofence}
            deviceName={device ? device.name : 'Wearable Device'}
          />
        </div>

        {/* Status Alerts & Auxiliary Health Panel */}
        <div className="xl:col-span-1 space-y-6">
          
          {/* Active Alerts Panel */}
          <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg flex flex-col justify-between h-48">
            <div>
              <h3 className="text-sm font-extrabold uppercase tracking-wider text-gray-400 mb-1 flex items-center justify-between">
                Active Alerts Panel
                <Bell size={16} className={activeAlertsCount > 0 ? 'text-red-400 animate-swing' : 'text-gray-500'} />
              </h3>
              <p className="text-[11px] text-gray-500 mb-3">Unacknowledged emergency events requiring caregiver attention.</p>
              
              <div className="flex items-center gap-3 mt-4">
                <div className={`p-3 rounded-xl border ${
                  activeAlertsCount > 0 
                    ? 'bg-red-500/10 border-red-500/30 text-red-400' 
                    : 'bg-brand-bg border-brand-border/40 text-brand-accent'
                }`}>
                  {activeAlertsCount > 0 ? <ShieldAlert size={24} className="animate-pulse" /> : <CheckCircle size={24} />}
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-100 font-mono">{activeAlertsCount}</p>
                  <p className="text-xs text-gray-400">Critical Unacknowledged Alerts</p>
                </div>
              </div>
            </div>
            
            <button
              onClick={() => navigate('/alerts')}
              className="w-full bg-brand-bg hover:bg-brand-bg/80 border border-brand-border text-xs font-bold py-2 rounded-lg transition-colors cursor-pointer text-center block text-gray-300"
            >
              Access Alarm Logs
            </button>
          </div>

          {/* Quick Hardware Diagnostic Card */}
          <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg flex flex-col justify-between h-[192px]">
            <div>
              <h3 className="text-sm font-extrabold uppercase tracking-wider text-gray-400 mb-1 flex items-center justify-between">
                Wearable Diagnostics
                <Cpu size={16} className="text-gray-500" />
              </h3>
              <p className="text-[11px] text-gray-500 mb-4">Current firmware & connectivity health attributes.</p>

              <div className="space-y-3 text-xs">
                <div className="flex justify-between items-center text-gray-300 py-1.5 border-b border-brand-border/40">
                  <span>Battery Status</span>
                  <span className="font-mono text-brand-accent font-bold">{device ? `${device.battery_pct}%` : '--'}</span>
                </div>
                <div className="flex justify-between items-center text-gray-300 py-1.5 border-b border-brand-border/40">
                  <span>Radio Frequency mode</span>
                  <span className="font-semibold capitalize text-brand-accent">{device ? device.connection_mode : '--'}</span>
                </div>
                <div className="flex justify-between items-center text-gray-300 py-1.5">
                  <span>Last Location Lock</span>
                  <span className="font-semibold text-gray-400 flex items-center gap-1">
                    <MapPin size={12} />
                    {latestReading && latestReading.gps ? `${latestReading.gps.lat.toFixed(4)}, ${latestReading.gps.lng.toFixed(4)}` : '--'}
                  </span>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
export default Dashboard;
