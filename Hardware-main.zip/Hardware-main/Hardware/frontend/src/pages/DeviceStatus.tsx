import React from 'react';
import { useOutletContext } from 'react-router-dom';
import { api } from '../api/httpClient';
import { useDeviceWebSocket } from '../api/wsClient';
import type { DeviceStatus as DeviceStatusType } from '../types';
import { Cpu, Wifi, Battery, Clock, AlertTriangle, ShieldCheck } from 'lucide-react';

interface OutletContextType {
  selectedDeviceId: string;
}

export const DeviceStatus: React.FC = () => {
  const { selectedDeviceId } = useOutletContext<OutletContextType>();
  const [device, setDevice] = React.useState<DeviceStatusType | null>(null);
  const [loading, setLoading] = React.useState(true);

  // Load device status from API
  React.useEffect(() => {
    if (!selectedDeviceId) {
      setDevice(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    const fetchStatus = async () => {
      try {
        const res = await api.get(`/devices/${selectedDeviceId}/status`);
        setDevice(res);
      } catch (err) {
        console.error("Failed to load device status:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchStatus();
  }, [selectedDeviceId]);

  // Subscribe to real-time status notifications
  useDeviceWebSocket(selectedDeviceId ? selectedDeviceId : null, (event) => {
    if (event.type === 'device.status') {
      setDevice(event.data);
    } else if (event.type === 'telemetry.update') {
      const payload = event.data;
      setDevice(prev => prev ? {
        ...prev,
        battery_pct: payload.battery_pct,
        is_online: true,
        last_seen: payload.timestamp
      } : null);
    }
  });

  const getSignalDetails = (mode: string) => {
    switch (mode) {
      case 'WIFI':
        return { label: 'Wi-Fi Network Connected', color: 'text-brand-accent', desc: 'Paired to local router. Low latency, high bandwidth.' };
      case 'LTE':
        return { label: 'LTE-M Cellular Standalone', color: 'text-blue-400', desc: 'Direct cellular transmission. Moderate battery drain, wide area coverage.' };
      case 'BLE':
        return { label: 'BLE Gateway Relayed', color: 'text-brand-accent-purple', desc: 'Bridged through paired smartphone application. Highly power efficient.' };
      default:
        return { label: 'No Connection Link', color: 'text-red-500', desc: 'Wearable is offline. telemetries are cached locally on flash storage.' };
    }
  };

  if (!selectedDeviceId) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] border border-dashed border-brand-border rounded-xl p-8 max-w-xl mx-auto">
        <Cpu size={40} className="text-gray-500 mb-4 animate-pulse" />
        <h3 className="text-md font-bold text-gray-200">No Device Paired</h3>
        <p className="text-xs text-gray-400 text-center mt-1">Please pair a device in Settings to view connection details.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[50vh] text-gray-400 text-xs">
        Loading Diagnostic Telemetry...
      </div>
    );
  }

  if (!device) {
    return (
      <div className="bg-brand-card border border-brand-border rounded-xl p-6 text-center text-xs text-gray-400 max-w-lg mx-auto">
        Device record not found. Confirm device ID is correct.
      </div>
    );
  }

  const signal = getSignalDetails(device.connection_mode);
  const isStale = !device.is_online;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      {/* Overview Header banner */}
      <div className={`p-6 border rounded-xl shadow-lg relative overflow-hidden bg-brand-card ${
        isStale ? 'border-red-500/30' : 'border-brand-border'
      }`}>
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
          <div className="flex gap-4 items-center">
            <div className={`p-3.5 rounded-xl border ${
              isStale ? 'bg-red-500/10 border-red-500/20 text-red-400' : 'bg-brand-accent/10 border-brand-accent/20 text-brand-accent'
            }`}>
              {isStale ? <AlertTriangle size={24} /> : <ShieldCheck size={24} />}
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-100">{device.name}</h3>
              <p className="text-xs text-gray-400 font-mono mt-0.5">ID: {selectedDeviceId}</p>
            </div>
          </div>

          <div className="flex flex-col sm:items-end gap-1">
            <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold self-start sm:self-auto ${
              isStale ? 'bg-red-500/10 text-red-400' : 'bg-brand-accent/10 text-brand-accent'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${isStale ? 'bg-red-400' : 'bg-brand-accent animate-pulse'}`} />
              {isStale ? 'Offline / Inactive' : 'Online / Broadcasting'}
            </span>
            <p className="text-[10px] text-gray-500 mt-1">
              Last report: {new Date(device.last_seen).toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      {/* Grid Specs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* RF Signal Health */}
        <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg flex flex-col justify-between min-h-[160px]">
          <div>
            <div className="flex justify-between items-center mb-3">
              <span className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold">Active Radio Mode</span>
              <Wifi size={18} className={signal.color} />
            </div>
            <p className={`text-md font-bold ${signal.color}`}>{device.connection_mode}</p>
            <p className="text-[10px] text-gray-400 mt-1">{signal.label}</p>
          </div>
          <p className="text-xs text-gray-400 border-t border-brand-border/40 pt-3 mt-3">{signal.desc}</p>
        </div>

        {/* Battery Diagnostic */}
        <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg flex flex-col justify-between min-h-[160px]">
          <div>
            <div className="flex justify-between items-center mb-3">
              <span className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold">Wearable Charge</span>
              <Battery size={18} className={device.battery_pct > 50 ? 'text-brand-accent' : device.battery_pct > 20 ? 'text-yellow-400' : 'text-red-500'} />
            </div>
            <p className="text-xl font-bold text-gray-100 font-mono">{device.battery_pct}%</p>
            <p className="text-[10px] text-gray-400 mt-1">Battery Cell: Lithium Polymer 3.7V</p>
          </div>
          <p className="text-xs text-gray-400 border-t border-brand-border/40 pt-3 mt-3">
            {device.battery_pct <= 15 ? 'Critical: Recharge immediately.' : device.battery_pct <= 30 ? 'Low: Connect charger soon.' : 'Optimal operation range.'}
          </p>
        </div>

        {/* Device Processor Properties */}
        <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg flex flex-col justify-between min-h-[160px]">
          <div>
            <div className="flex justify-between items-center mb-3">
              <span className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold">Processor Specs</span>
              <Cpu size={18} className="text-brand-accent-purple" />
            </div>
            <p className="text-md font-bold text-gray-100">ESP-WROOM-32</p>
            <p className="text-[10px] text-gray-400 mt-1">Firmware version: v{device.firmware_version}</p>
          </div>
          <p className="text-xs text-gray-400 border-t border-brand-border/40 pt-3 mt-3">
            Includes PPG sensor driver, L86 GPS transceiver, MEMS audio snippet encoder, and ADXL345 impact core.
          </p>
        </div>

      </div>

      {/* Diagnostics Logs Table */}
      <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg">
        <h4 className="text-sm font-extrabold uppercase tracking-wider text-gray-300 mb-4">Hardware Component Health</h4>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-brand-border/60 text-gray-400">
                <th className="pb-3 font-semibold">Module</th>
                <th className="pb-3 font-semibold">Type</th>
                <th className="pb-3 font-semibold">Status</th>
                <th className="pb-3 font-semibold">Diagnostics</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-brand-border/30">
              <tr className="text-gray-300">
                <td className="py-3 font-semibold">PPG Optical Pulse Sensor</td>
                <td className="py-3 text-gray-400">Vitals Monitoring</td>
                <td className="py-3">
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-brand-accent/10 text-brand-accent border border-brand-accent/20">Operational</span>
                </td>
                <td className="py-3 text-gray-400">Green LED emitter verified. High SNR.</td>
              </tr>
              <tr className="text-gray-300">
                <td className="py-3 font-semibold">ADXL345 Accelerometer</td>
                <td className="py-3 text-gray-400">Fall Detection</td>
                <td className="py-3">
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-brand-accent/10 text-brand-accent border border-brand-accent/20">Operational</span>
                </td>
                <td className="py-3 text-gray-400">g-Force thresholds active (±16g range).</td>
              </tr>
              <tr className="text-gray-300">
                <td className="py-3 font-semibold">L86 GPS Receiver</td>
                <td className="py-3 text-gray-400">Location Tracking</td>
                <td className="py-3">
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-brand-accent/10 text-brand-accent border border-brand-accent/20">Operational</span>
                </td>
                <td className="py-3 text-gray-400">Satellite lock configured. NMEA streams OK.</td>
              </tr>
              <tr className="text-gray-300">
                <td className="py-3 font-semibold">MEMS Microphone</td>
                <td className="py-3 text-gray-400">Vocal Distress Snippet Encoder</td>
                <td className="py-3">
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-brand-accent/10 text-brand-accent border border-brand-accent/20">Operational</span>
                </td>
                <td className="py-3 text-gray-400">On-device MFCC coefficient pre-filtering online.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
export default DeviceStatus;
