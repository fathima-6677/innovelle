import React from 'react';
import { useOutletContext } from 'react-router-dom';
import { api } from '../api/httpClient';
import type { GeofenceConfig } from '../types';
import { Shield, Plus, Trash2, Save, MapPin, AlertCircle, Phone, Smartphone } from 'lucide-react';

interface OutletContextType {
  selectedDeviceId: string;
  setLinkedDevices: React.Dispatch<React.SetStateAction<any[]>>;
}

export const Settings: React.FC = () => {
  const { selectedDeviceId, setLinkedDevices } = useOutletContext<OutletContextType>();
  const [caregiverName, setCaregiverName] = React.useState('');
  const [deviceIdInput, setDeviceIdInput] = React.useState('');
  const [localDevices, setLocalDevices] = React.useState<any[]>([]);
  
  // Geofence states
  const [geofenceName, setGeofenceName] = React.useState('Home Zone');
  const [centerLat, setCenterLat] = React.useState<number>(37.7599);
  const [centerLng, setCenterLng] = React.useState<number>(-122.4270);
  const [radiusMeters, setRadiusMeters] = React.useState<number>(100);

  // Emergency contact states
  const [contacts, setContacts] = React.useState<Array<{ name: string; relation: string; phone: string }>>([]);
  const [newContactName, setNewContactName] = React.useState('');
  const [newContactRelation, setNewContactRelation] = React.useState('');
  const [newContactPhone, setNewContactPhone] = React.useState('');

  const [loading, setLoading] = React.useState(true);
  const [statusMessage, setStatusMessage] = React.useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Load Caregiver Settings & Geofence
  React.useEffect(() => {
    const initSettings = async () => {
      setLoading(true);
      try {
        // 1. Fetch user profile
        const profile = await api.get('/users/me');
        setCaregiverName(profile.name || '');

        // Load emergency contacts from localStorage
        const savedContacts = localStorage.getItem(`autiguard_contacts_${profile.id}`);
        if (savedContacts) {
          setContacts(JSON.parse(savedContacts));
        }

        // 2. Fetch linked devices
        const devices = await api.get('/devices/list');
        setLocalDevices(devices);
        setLinkedDevices(devices);

        // 3. Fetch geofence config if device selected
        if (selectedDeviceId) {
          try {
            const geofences = await api.get(`/geofence/device/${selectedDeviceId}`);
            if (geofences && geofences.length > 0) {
              const val = geofences[0] as GeofenceConfig;
              setGeofenceName(val.name || 'Safe Zone');
              // Use snake_case fields as returned by the FastAPI backend
              setCenterLat(val.center_lat);
              setCenterLng(val.center_lng);
              setRadiusMeters(val.radius_meters);
            }
          } catch (err) {
            console.error("No geofence found or error:", err);
          }
        }
      } catch (err) {
        console.error("Error loading settings details:", err);
      } finally {
        setLoading(false);
      }
    };

    initSettings();
  }, [selectedDeviceId, setLinkedDevices]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Call update profile endpoint
      const updatedUser = await api.patch(`/users/profile?name=${encodeURIComponent(caregiverName)}`);
      
      // Update contacts locally
      localStorage.setItem(`autiguard_contacts_${updatedUser.id}`, JSON.stringify(contacts));
      
      showStatus('Settings successfully saved.', 'success');
    } catch (err) {
      console.error(err);
      showStatus('Error saving profile settings.', 'error');
    }
  };

  const handlePairDevice = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedId = deviceIdInput.trim();
    if (!trimmedId) return;

    if (localDevices.some(d => d.serial_number === trimmedId || d.id === trimmedId)) {
      showStatus('This device identifier is already paired.', 'error');
      return;
    }

    try {
      // Call device register route
      const regRes = await api.post('/devices/register', {
        serial_number: trimmedId,
        provisioning_secret: "esp32_factory_secret_2026", // Burned in firmware secret
        name: `AutiGuard Band #${trimmedId.slice(-3) || '1'}`
      });

      // Refresh list
      const devices = await api.get('/devices/list');
      setLocalDevices(devices);
      setLinkedDevices(devices);

      setDeviceIdInput('');
      showStatus(`Wearable device paired! Token generated. ID: ${regRes.device_id.slice(0, 8)}...`, 'success');
    } catch (err: any) {
      console.error(err);
      showStatus(err.message || 'Error pairing wearable device.', 'error');
    }
  };

  const handleUnpairDevice = async (idToUnpair: string) => {
    try {
      await api.delete(`/devices/${idToUnpair}`);
      
      // Refresh list
      const devices = await api.get('/devices/list');
      setLocalDevices(devices);
      setLinkedDevices(devices);
      
      showStatus('Wearable device unpaired successfully.', 'success');
    } catch (err) {
      console.error(err);
      showStatus('Error unpairing device.', 'error');
    }
  };

  const handleSaveGeofence = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDeviceId) {
      showStatus('Select a device in the header to configure geofence safe zones.', 'error');
      return;
    }
    try {
      await api.post(`/geofence/?device_id=${selectedDeviceId}`, {
        name: geofenceName,
        center_lat: Number(centerLat),
        center_lng: Number(centerLng),
        radius_meters: Number(radiusMeters)
      });
      showStatus('Geofence boundaries updated.', 'success');
    } catch (err) {
      console.error(err);
      showStatus('Failed to update geofence boundaries.', 'error');
    }
  };

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName.trim() || !newContactPhone.trim()) return;
    setContacts(prev => [...prev, {
      name: newContactName.trim(),
      relation: newContactRelation.trim() || 'Other',
      phone: newContactPhone.trim()
    }]);
    setNewContactName('');
    setNewContactRelation('');
    setNewContactPhone('');
  };

  const handleRemoveContact = (index: number) => {
    setContacts(prev => prev.filter((_, i) => i !== index));
  };

  const showStatus = (text: string, type: 'success' | 'error') => {
    setStatusMessage({ text, type });
    setTimeout(() => setStatusMessage(null), 5000);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[50vh] text-gray-400 text-xs">
        Loading Settings Panel...
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      
      {/* Toast Alert Status */}
      {statusMessage && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-lg text-xs font-bold shadow-2xl flex items-center gap-2 border animate-fade-in ${
          statusMessage.type === 'success' 
            ? 'bg-brand-accent/10 border-brand-accent/30 text-brand-accent' 
            : 'bg-red-500/10 border-red-500/30 text-red-400'
        }`}>
          <AlertCircle size={16} />
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Grid Settings Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Device Pairing Column */}
        <div className="space-y-8">
          
          {/* Pair Device Panel */}
          <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg">
            <h3 className="text-sm font-extrabold uppercase tracking-wider text-gray-300 mb-2 flex items-center gap-2">
              <Shield size={16} className="text-brand-accent" />
              Wearable Pairing Setup
            </h3>
            <p className="text-[11px] text-gray-500 mb-4">Link wearable device serials to authorize telemetry ingestion.</p>
            
            <form onSubmit={handlePairDevice} className="flex gap-2 mb-6">
              <input
                type="text"
                required
                value={deviceIdInput}
                onChange={e => setDeviceIdInput(e.target.value)}
                placeholder="Serial (e.g. ESP32_AUTIGUARD_007)"
                className="flex-1 bg-brand-bg border border-brand-border rounded-lg px-3 py-2 text-xs text-gray-100 placeholder-gray-500 focus:outline-none focus:border-brand-accent font-mono"
              />
              <button
                type="submit"
                className="bg-brand-accent text-brand-bg hover:bg-brand-accent/90 transition-colors text-xs font-bold px-4 py-2 rounded-lg cursor-pointer flex items-center gap-1 shrink-0"
              >
                <Plus size={14} />
                Pair
              </button>
            </form>

            {/* Linked Devices List */}
            <div className="space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block mb-1">Paired Devices ({localDevices.length})</span>
              {localDevices.length === 0 ? (
                <p className="text-[11px] text-gray-500 italic">No paired wearables found.</p>
              ) : (
                localDevices.map(device => (
                  <div key={device.id} className="flex justify-between items-center bg-brand-bg/50 border border-brand-border/40 rounded-lg px-3 py-2 text-xs">
                    <div className="flex flex-col">
                      <span className="font-semibold text-gray-200">{device.name}</span>
                      <span className="font-mono text-[10px] text-gray-500">SN: {device.serial_number}</span>
                    </div>
                    <button
                      onClick={() => handleUnpairDevice(device.id)}
                      className="text-red-400 hover:text-red-300 transition-colors"
                      title="Unpair Device"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Emergency Contacts Panel */}
          <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg">
            <h3 className="text-sm font-extrabold uppercase tracking-wider text-gray-300 mb-2 flex items-center gap-2">
              <Phone size={16} className="text-brand-accent" />
              Distress Contacts
            </h3>
            <p className="text-[11px] text-gray-500 mb-4">Emergency contacts notified immediately when a fall or panic button triggers.</p>

            <form onSubmit={handleAddContact} className="space-y-3 mb-6 bg-brand-bg/40 border border-brand-border/30 p-3 rounded-lg">
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  required
                  placeholder="Full Name"
                  value={newContactName}
                  onChange={e => setNewContactName(e.target.value)}
                  className="bg-brand-bg border border-brand-border rounded-lg px-3 py-2 text-xs text-gray-100 placeholder-gray-500 focus:outline-none focus:border-brand-accent"
                />
                <input
                  type="text"
                  placeholder="Relation (e.g. Mother)"
                  value={newContactRelation}
                  onChange={e => setNewContactRelation(e.target.value)}
                  className="bg-brand-bg border border-brand-border rounded-lg px-3 py-2 text-xs text-gray-100 placeholder-gray-500 focus:outline-none focus:border-brand-accent"
                />
              </div>
              <div className="flex gap-2">
                <input
                  type="tel"
                  required
                  placeholder="Phone Number"
                  value={newContactPhone}
                  onChange={e => setNewContactPhone(e.target.value)}
                  className="flex-1 bg-brand-bg border border-brand-border rounded-lg px-3 py-2 text-xs text-gray-100 placeholder-gray-500 focus:outline-none focus:border-brand-accent"
                />
                <button
                  type="submit"
                  className="bg-brand-bg border border-brand-border hover:border-brand-accent/50 text-brand-accent transition-colors text-xs font-bold px-3 py-2 rounded-lg cursor-pointer"
                >
                  Add Contact
                </button>
              </div>
            </form>

            {/* List */}
            <div className="space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block mb-1">Alert Contact List ({contacts.length})</span>
              {contacts.length === 0 ? (
                <p className="text-[11px] text-gray-500 italic">No contacts added.</p>
              ) : (
                contacts.map((contact, idx) => (
                  <div key={idx} className="flex justify-between items-center bg-brand-bg/50 border border-brand-border/40 rounded-lg px-3 py-2 text-xs">
                    <div>
                      <p className="font-semibold text-gray-200">{contact.name}</p>
                      <p className="text-[10px] text-gray-400">{contact.relation} • {contact.phone}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveContact(idx)}
                      className="text-red-400 hover:text-red-300 transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

        {/* Geofence Configuration Column */}
        <div>
          <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg h-full">
            <h3 className="text-sm font-extrabold uppercase tracking-wider text-gray-300 mb-2 flex items-center gap-2">
              <MapPin size={16} className="text-brand-accent" />
              Safe Zone Geofencing
            </h3>
            <p className="text-[11px] text-gray-500 mb-4">Set boundaries. Exiting the zone triggers an instant Alert Banner warning.</p>

            {!selectedDeviceId ? (
              <div className="bg-brand-bg/30 border border-brand-border/50 rounded-lg p-6 text-center text-xs text-gray-400 italic animate-pulse">
                Select a device in the header dropdown to configure geofence details.
              </div>
            ) : (
              <form onSubmit={handleSaveGeofence} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                    Zone Title
                  </label>
                  <input
                    type="text"
                    required
                    value={geofenceName}
                    onChange={e => setGeofenceName(e.target.value)}
                    className="w-full bg-brand-bg border border-brand-border rounded-lg px-3 py-2 text-xs text-gray-100 focus:outline-none focus:border-brand-accent"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                      Center Latitude
                    </label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={centerLat}
                      onChange={e => setCenterLat(Number(e.target.value))}
                      className="w-full bg-brand-bg border border-brand-border rounded-lg px-3 py-2 text-xs text-gray-100 focus:outline-none focus:border-brand-accent font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                      Center Longitude
                    </label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={centerLng}
                      onChange={e => setCenterLng(Number(e.target.value))}
                      className="w-full bg-brand-bg border border-brand-border rounded-lg px-3 py-2 text-xs text-gray-100 focus:outline-none focus:border-brand-accent font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1 flex justify-between">
                    <span>Safe Radius Boundaries</span>
                    <span className="text-brand-accent font-mono font-bold">{radiusMeters} Meters</span>
                  </label>
                  <input
                    type="range"
                    min="30"
                    max="1000"
                    step="10"
                    value={radiusMeters}
                    onChange={e => setRadiusMeters(Number(e.target.value))}
                    className="w-full h-1.5 bg-brand-bg rounded-lg appearance-none cursor-pointer accent-brand-accent border border-brand-border/40"
                  />
                  <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                    <span>30m (Micro)</span>
                    <span>1000m (Macro)</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-brand-accent text-brand-bg hover:bg-brand-accent/90 transition-all font-bold text-xs py-2.5 rounded-lg flex items-center justify-center gap-1 cursor-pointer mt-4 animate-pulse-subtle"
                >
                  <Save size={14} />
                  Save Geofence Area
                </button>
              </form>
            )}
          </div>
        </div>

      </div>

      {/* Master Caregiver Profile Save Bar */}
      <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-brand-bg border border-brand-border text-gray-400 flex items-center justify-center">
            <Smartphone size={18} />
          </div>
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-0.5">Caregiver Label Name</label>
            <input
              type="text"
              required
              value={caregiverName}
              onChange={e => setCaregiverName(e.target.value)}
              className="bg-brand-bg border border-brand-border rounded-lg px-3 py-1.5 text-xs text-gray-100 focus:outline-none focus:border-brand-accent font-semibold"
            />
          </div>
        </div>
        <button
          onClick={handleUpdateProfile}
          className="bg-brand-accent text-brand-bg hover:bg-brand-accent/90 transition-colors text-xs font-bold px-4 py-2.5 rounded-lg cursor-pointer flex items-center gap-1 shadow-md"
        >
          <Save size={14} />
          Save Settings
        </button>
      </div>

    </div>
  );
};

export default Settings;
