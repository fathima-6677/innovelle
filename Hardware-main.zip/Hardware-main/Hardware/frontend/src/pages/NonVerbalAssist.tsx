import React from 'react';
import { useOutletContext } from 'react-router-dom';
import { api } from '../api/httpClient';
import { useDeviceWebSocket } from '../api/wsClient';
import { Activity, Clock, ShieldAlert, CheckCircle, Hand } from 'lucide-react';

interface OutletContextType {
  selectedDeviceId: string;
}

interface WearerRequest {
  id: string;
  device_id: string;
  message: string;
  timestamp: string;
}

export const NonVerbalAssist: React.FC = () => {
  const { selectedDeviceId } = useOutletContext<OutletContextType>();
  const [requests, setRequests] = React.useState<WearerRequest[]>([]);
  const [loading, setLoading] = React.useState(true);

  // Load history on device selection change
  React.useEffect(() => {
    if (!selectedDeviceId) {
      setRequests([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const fetchRequests = async () => {
      try {
        const list = await api.get(`/nonverbal/device/${selectedDeviceId}`);
        setRequests(list);
      } catch (err) {
        console.error("Failed to load nonverbal requests:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchRequests();
  }, [selectedDeviceId]);

  // Subscribe to real-time nonverbal stream updates
  useDeviceWebSocket(selectedDeviceId ? selectedDeviceId : null, (event) => {
    if (event.type === 'nonverbal.new') {
      const payload = event.data;
      setRequests(prev => [payload, ...prev.filter(r => r.id !== payload.id)]);
    }
  });

  if (!selectedDeviceId) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] border border-dashed border-brand-border rounded-xl p-8 max-w-xl mx-auto">
        <Activity size={40} className="text-gray-500 mb-4 animate-pulse" />
        <h3 className="text-md font-bold text-gray-200">No Paired Device</h3>
        <p className="text-xs text-gray-400 text-center mt-1">Pair a device in Settings to view wearer assist communications.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[50vh] text-gray-400 text-xs">
        Connecting to Wearer Assist channel...
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Intro card */}
      <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg flex gap-4 items-center">
        <div className="p-3 bg-brand-bg rounded-xl border border-brand-border text-brand-accent shadow-inner shrink-0">
          <Hand size={24} />
        </div>
        <div>
          <h3 className="text-sm font-extrabold uppercase tracking-wider text-gray-300">Wearer Assist Panel</h3>
          <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">
            Displays quick, non-verbal need-messages sent by the wearer from their wearable buttons or touch screen interface. Messages stream live without manual refresh.
          </p>
        </div>
      </div>

      {/* Grid of requests */}
      <div className="space-y-4">
        {requests.length === 0 ? (
          <div className="bg-brand-card border border-brand-border rounded-xl p-12 text-center text-xs text-gray-500">
            <CheckCircle size={32} className="mx-auto mb-2 text-brand-accent/40" />
            <p className="font-semibold text-sm">No Communication Requests Received</p>
            <p className="opacity-75 mt-0.5">The wearer hasn't dispatched any assistant signals yet.</p>
          </div>
        ) : (
          requests.map(req => (
            <div
              key={req.id}
              className="bg-brand-card border border-brand-border rounded-xl p-5 shadow flex justify-between items-center"
            >
              <div className="flex gap-4 items-center">
                <div className="w-10 h-10 rounded-lg bg-brand-bg border border-brand-border flex items-center justify-center text-brand-accent font-bold text-sm uppercase">
                  {req.message.slice(0, 2)}
                </div>
                <div>
                  <p className="text-sm font-bold text-gray-100">{req.message}</p>
                  <span className="flex items-center gap-1 mt-1 text-[10px] text-gray-500 font-mono">
                    <Clock size={10} />
                    {new Date(req.timestamp).toLocaleString()}
                  </span>
                </div>
              </div>

              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full border bg-brand-accent/10 border-brand-accent/20 text-brand-accent shadow-inner">
                Received Live
              </span>
            </div>
          ))
        )}
      </div>

    </div>
  );
};
export default NonVerbalAssist;
