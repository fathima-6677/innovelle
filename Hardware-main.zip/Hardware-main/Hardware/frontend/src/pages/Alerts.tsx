import React from 'react';
import { useOutletContext } from 'react-router-dom';
import { api } from '../api/httpClient';
import type { Alert } from '../types';
import { AlertTriangle, CheckCircle, ShieldAlert, MapPin, Check, Filter } from 'lucide-react';

interface OutletContextType {
  selectedDeviceId: string;
  alerts: Alert[];
}

export const Alerts: React.FC = () => {
  const { selectedDeviceId, alerts } = useOutletContext<OutletContextType>();
  const [filterType, setFilterType] = React.useState<string>('all');
  const [filterStatus, setFilterStatus] = React.useState<'all' | 'active' | 'acknowledged'>('all');

  const handleAcknowledge = async (alertId: string) => {
    try {
      await api.patch(`/alerts/${alertId}/acknowledge`);
      // No local state update needed here because Layout.tsx subscribes to the device's WebSocket
      // and updates the global alert state reactively when the server broadcasts alert.acknowledged!
    } catch (error) {
      console.error("Error acknowledging alert via API:", error);
    }
  };

  const filteredAlerts = React.useMemo(() => {
    const sorted = [...alerts].sort((a, b) => b.timestamp - a.timestamp);
    return sorted.filter(alert => {
      const typeMatches = filterType === 'all' || alert.type === filterType;
      const statusMatches =
        filterStatus === 'all' ||
        (filterStatus === 'active' && !alert.acknowledged) ||
        (filterStatus === 'acknowledged' && alert.acknowledged);
      return typeMatches && statusMatches;
    });
  }, [alerts, filterType, filterStatus]);

  const getAlertBadge = (type: string) => {
    switch (type) {
      case 'fall':
        return { label: 'Fall Alert', color: 'bg-red-500/10 text-red-400 border border-red-500/20' };
      case 'panic':
        return { label: 'Panic Button', color: 'bg-violet-500/10 text-violet-400 border border-violet-500/20' };
      case 'geofence':
        return { label: 'Geofence Breach', color: 'bg-orange-500/10 text-orange-400 border border-orange-500/20' };
      case 'stress':
        return { label: 'High Stress (RF)', color: 'bg-amber-500/10 text-amber-400 border border-amber-500/20' };
      case 'distress':
        return { label: 'Audio Distress (CNN)', color: 'bg-red-600/10 text-red-500 border border-red-600/20' };
      default:
        return { label: 'System Notice', color: 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' };
    }
  };

  if (!selectedDeviceId) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] border border-dashed border-brand-border rounded-xl p-8 max-w-xl mx-auto">
        <AlertTriangle size={40} className="text-gray-500 mb-4 animate-pulse" />
        <h3 className="text-md font-bold text-gray-200">No Active Device</h3>
        <p className="text-xs text-gray-400 text-center mt-1">Please pair a device in Settings to view alerts.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Filters Control Bar */}
      <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        <div>
          <h3 className="text-md font-bold text-gray-100 flex items-center gap-2">
            Alarm Dispatch & Log Feed
          </h3>
          <p className="text-xs text-gray-400 mt-0.5">Filter and manage critical notification dispatches.</p>
        </div>

        {/* Filter Selection Panel */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-gray-400 bg-brand-bg px-2.5 py-1.5 rounded-lg border border-brand-border/60">
            <Filter size={12} />
            <span>Filters:</span>
          </div>

          {/* Type Filter */}
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="bg-brand-bg border border-brand-border text-xs rounded-lg px-3 py-1.5 text-gray-200 focus:outline-none focus:border-brand-accent font-semibold"
          >
            <option value="all">All Event Types</option>
            <option value="fall">Falls Only</option>
            <option value="panic">SOS Panic Button</option>
            <option value="geofence">Geofence Breaches</option>
            <option value="stress">High Physiological Stress</option>
            <option value="distress">Vocal Distress Snippets</option>
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value as any)}
            className="bg-brand-bg border border-brand-border text-xs rounded-lg px-3 py-1.5 text-gray-200 focus:outline-none focus:border-brand-accent font-semibold"
          >
            <option value="all">All States</option>
            <option value="active">Active (Unresolved)</option>
            <option value="acknowledged">Acknowledged Logs</option>
          </select>
        </div>
      </div>

      {/* Alert Feed Container */}
      <div className="space-y-4">
        {filteredAlerts.length === 0 ? (
          <div className="bg-brand-card border border-brand-border rounded-xl p-10 text-center text-xs text-gray-500">
            <CheckCircle size={32} className="mx-auto mb-2 text-brand-accent/50" />
            <p className="font-semibold text-sm">No Alert Records Match Filters</p>
            <p className="opacity-75 mt-0.5">Device operation matches expected thresholds.</p>
          </div>
        ) : (
          filteredAlerts.map(alert => {
            const badge = getAlertBadge(alert.type);
            return (
              <div
                key={alert.id}
                className={`bg-brand-card border rounded-xl p-5 shadow transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                  alert.acknowledged
                    ? 'border-brand-border/40 opacity-75'
                    : 'border-red-500/35 shadow-red-950/5'
                }`}
              >
                {/* Event Information */}
                <div className="flex gap-4 items-start">
                  <div className={`p-2.5 rounded-lg border shrink-0 ${
                    alert.acknowledged
                      ? 'bg-brand-bg border-brand-border text-gray-500'
                      : alert.severity === 'critical'
                      ? 'bg-red-500/10 border-red-500/20 text-red-400 animate-pulse'
                      : 'bg-amber-500/10 border-amber-500/20 text-amber-400'
                  }`}>
                    <ShieldAlert size={20} />
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${badge.color}`}>
                        {badge.label}
                      </span>
                      {!alert.acknowledged && (
                        <span className="text-[10px] bg-red-500 text-white font-bold px-1.5 py-0.5 rounded animate-pulse">
                          ACTION REQUIRED
                        </span>
                      )}
                    </div>
                    <p className="text-sm font-semibold text-gray-100 mt-2">{alert.message || 'Sensor trigger warning.'}</p>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs text-gray-400 font-mono">
                      <span>Time: {new Date(alert.timestamp).toLocaleString()}</span>
                      {alert.location && (
                        <span className="flex items-center gap-1">
                          <MapPin size={12} />
                          {alert.location.lat.toFixed(6)}, {alert.location.lng.toFixed(6)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Event Actions */}
                <div className="shrink-0 flex items-center md:justify-end">
                  {alert.acknowledged ? (
                    <div className="flex items-center gap-1.5 text-xs text-brand-accent bg-brand-accent/5 border border-brand-accent/15 px-3.5 py-1.5 rounded-lg font-bold">
                      <Check size={14} />
                      <span>Acknowledged</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleAcknowledge(alert.id)}
                      className="bg-brand-accent text-brand-bg hover:bg-brand-accent/90 transition-colors text-xs font-bold px-4 py-2 rounded-lg shadow-md cursor-pointer flex items-center gap-1.5"
                    >
                      <CheckCircle size={14} />
                      Mark Acknowledged
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
export default Alerts;
