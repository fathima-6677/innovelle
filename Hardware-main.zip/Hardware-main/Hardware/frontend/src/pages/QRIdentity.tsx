import React from 'react';
import { useOutletContext } from 'react-router-dom';
import { api } from '../api/httpClient';
import { Shield, Clock, MapPin, Eye, EyeOff, Loader2, AlertCircle } from 'lucide-react';

interface OutletContextType {
  selectedDeviceId: string;
}

export const QRIdentity: React.FC = () => {
  const { selectedDeviceId } = useOutletContext<OutletContextType>();
  const [encryptedPayload, setEncryptedPayload] = React.useState<string>('');
  const [rotatedAt, setRotatedAt] = React.useState<string>('');
  const [loading, setLoading] = React.useState(true);
  
  // Simulator states
  const [simRole, setSimRole] = React.useState<'emergency_responder' | 'clinician' | 'guardian'>('emergency_responder');
  const [scanResult, setScanResult] = React.useState<any>(null);
  const [scanning, setScanning] = React.useState(false);
  const [simError, setSimError] = React.useState<string | null>(null);

  const fetchQRData = React.useCallback(async () => {
    if (!selectedDeviceId) return;
    try {
      const res = await api.get(`/identity_qr/display/${selectedDeviceId}`);
      setEncryptedPayload(res.encrypted_payload);
      setRotatedAt(res.rotated_at);
      setScanResult(null);
    } catch (err) {
      console.error("Failed to load dynamic QR payload:", err);
    } finally {
      setLoading(false);
    }
  }, [selectedDeviceId]);

  React.useEffect(() => {
    fetchQRData();
  }, [fetchQRData]);

  // Simulate scanning the QR code with selected role
  const handleSimulateScan = async () => {
    if (!encryptedPayload) return;
    setScanning(true);
    setSimError(null);
    setScanResult(null);
    try {
      // Simulate scan with location
      const res = await api.post('/identity_qr/scan', {
        encrypted_payload: encryptedPayload,
        location_lat: 37.7599 + (Math.random() - 0.5) * 0.01,
        location_lng: -122.4270 + (Math.random() - 0.5) * 0.01
      });
      setScanResult(res);
    } catch (err: any) {
      console.error("Scan simulation failed:", err);
      setSimError(err.message || "Failed to decode scanned QR code.");
    } finally {
      setScanning(false);
    }
  };

  if (!selectedDeviceId) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] border border-dashed border-brand-border rounded-xl p-8 max-w-xl mx-auto">
        <Shield size={40} className="text-gray-500 mb-4 animate-pulse" />
        <h3 className="text-md font-bold text-gray-200">No Device Paired</h3>
        <p className="text-xs text-gray-400 text-center mt-1">Pair a device in Settings to view the QR Emergency ID.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[50vh] text-gray-400 text-xs">
        Generating dynamic encrypted QR identity...
      </div>
    );
  }

  // Generate Google Chart/QRServer URL for real scannable QR Code
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(encryptedPayload)}`;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      
      {/* Introduction Card */}
      <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg">
        <h3 className="text-sm font-extrabold uppercase tracking-wider text-gray-300 mb-1 flex items-center gap-2">
          <Shield size={16} className="text-brand-accent" />
          Dynamic Encrypted QR Identity
        </h3>
        <p className="text-xs text-gray-500 leading-relaxed">
          Provides emergency medical details for individuals with ASD. The payload is encrypted using AES/Fernet and rotates automatically every 24 hours. Data exposure is strictly hierarchical based on the accessor's RBAC role.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* QR Display Panel */}
        <div className="bg-brand-card border border-brand-border rounded-xl p-6 shadow-lg flex flex-col items-center justify-center text-center">
          <span className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-4">Live Wearer Badge Screen</span>
          
          <div className="bg-white p-4 rounded-xl border-4 border-brand-accent/30 shadow-inner">
            <img src={qrCodeUrl} alt="Wearer Encrypted QR" className="w-56 h-56" />
          </div>

          <div className="mt-4 space-y-1 text-xs text-gray-400">
            <p className="flex items-center justify-center gap-1">
              <Clock size={12} className="text-brand-accent" />
              Rotated: {new Date(rotatedAt).toLocaleString()}
            </p>
            <p className="text-[10px] text-gray-500 font-mono">Payload: {encryptedPayload.slice(0, 32)}...</p>
          </div>

          <button
            onClick={fetchQRData}
            className="mt-6 bg-brand-bg hover:bg-brand-bg/80 border border-brand-border text-xs font-bold px-4 py-2 rounded-lg text-brand-accent cursor-pointer transition-colors"
          >
            Force Rotate Key
          </button>
        </div>

        {/* Scan Log and Role Inspector */}
        <div className="bg-brand-card border border-brand-border rounded-xl p-6 shadow-lg space-y-4">
          <div>
            <h4 className="text-sm font-extrabold uppercase tracking-wider text-gray-300">Scan Simulator & Inspector</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">Test scanning as different roles to verify hierarchical data disclosure.</p>
          </div>

          <div className="space-y-3">
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400">Accessor Scan Role Profile</label>
            <div className="grid grid-cols-3 gap-2">
              {(['emergency_responder', 'clinician', 'guardian'] as const).map(role => (
                <button
                  key={role}
                  onClick={() => setSimRole(role)}
                  className={`py-2 text-[10px] font-bold uppercase tracking-wider rounded-lg border text-center transition-all ${
                    simRole === role 
                      ? 'bg-brand-bg border-brand-accent text-brand-accent shadow-inner' 
                      : 'bg-brand-bg/50 border-brand-border text-gray-400 hover:text-gray-300'
                  }`}
                >
                  {role.replace('_', ' ')}
                </button>
              ))}
            </div>

            <button
              onClick={handleSimulateScan}
              disabled={scanning}
              className="w-full bg-brand-accent text-brand-bg hover:bg-brand-accent/90 disabled:opacity-50 text-xs font-bold py-2.5 rounded-lg flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
            >
              {scanning ? <Loader2 size={14} className="animate-spin" /> : <Eye size={14} />}
              Simulate Code Scan
            </button>
          </div>

          {/* Decryption inspector response */}
          <div className="bg-brand-bg border border-brand-border/60 rounded-xl p-4 min-h-[180px] flex flex-col justify-center">
            {simError && (
              <div className="flex gap-2 text-xs text-red-400 p-2 border border-red-500/20 bg-red-950/20 rounded-lg">
                <AlertCircle size={16} className="shrink-0" />
                <span>{simError}</span>
              </div>
            )}
            
            {!scanResult && !simError && (
              <p className="text-xs text-gray-500 text-center italic">
                Press "Simulate Code Scan" to preview hierarchical records revealed to the {simRole.replace('_', ' ')}.
              </p>
            )}

            {scanResult && (
              <div className="space-y-3 text-xs">
                <div className="flex justify-between border-b border-brand-border/30 pb-1.5">
                  <span className="text-gray-400">Scanned Wearer:</span>
                  <span className="font-bold text-gray-200">{scanResult.wearer_name}</span>
                </div>
                <div className="flex justify-between border-b border-brand-border/30 pb-1.5">
                  <span className="text-gray-400">Authorized Role:</span>
                  <span className="font-mono text-brand-accent uppercase font-bold">{scanResult.role_level}</span>
                </div>

                <div className="space-y-2 pt-1.5">
                  {scanResult.emergency_contact && (
                    <div>
                      <span className="text-[10px] uppercase text-gray-500 font-bold block">Emergency Contact</span>
                      <p className="text-gray-300 font-semibold">{scanResult.emergency_contact} • {scanResult.emergency_phone}</p>
                    </div>
                  )}
                  {scanResult.critical_medical_notes && (
                    <div>
                      <span className="text-[10px] uppercase text-gray-500 font-bold block">Critical Safety Details</span>
                      <p className="text-red-400/90 leading-relaxed font-semibold bg-red-950/10 border border-red-950/30 p-2 rounded-lg mt-0.5">{scanResult.critical_medical_notes}</p>
                    </div>
                  )}
                  {scanResult.stress_trend_summary && (
                    <div>
                      <span className="text-[10px] uppercase text-gray-500 font-bold block">Physiological Stress Baseline</span>
                      <p className="text-gray-300 font-mono">{scanResult.stress_trend_summary}</p>
                    </div>
                  )}
                  {scanResult.full_medical_record && (
                    <div>
                      <span className="text-[10px] uppercase text-gray-500 font-bold block">Clinical Medical File</span>
                      <p className="text-gray-300 leading-relaxed">{scanResult.full_medical_record}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
export default QRIdentity;
