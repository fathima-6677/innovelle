import React from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api/httpClient';
import { Shield, AlertCircle, Eye, EyeOff, Loader2 } from 'lucide-react';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const [isRegistering, setIsRegistering] = React.useState(false);
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [fullName, setFullName] = React.useState('');
  const [role, setRole] = React.useState<'guardian' | 'caregiver' | 'clinician' | 'emergency_responder' | 'admin'>('caregiver');
  const [showPassword, setShowPassword] = React.useState(false);
  
  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    // Redirect if already logged in
    const token = localStorage.getItem("autiguard_token");
    if (token) {
      navigate('/dashboard');
    }
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (isRegistering) {
        // Register Caregiver/Guardian Account via FastAPI REST
        await api.post('/users/register', {
          email,
          password,
          name: fullName,
          role
        });
        
        // Log in immediately after registration
        const loginRes = await api.post('/users/login', {
          email,
          password
        });
        
        localStorage.setItem("autiguard_token", loginRes.access_token);
        localStorage.setItem("autiguard_role", loginRes.role);
        navigate('/dashboard');
      } else {
        // Sign In via FastAPI REST
        const loginRes = await api.post('/users/login', {
          email,
          password
        });
        
        localStorage.setItem("autiguard_token", loginRes.access_token);
        localStorage.setItem("autiguard_role", loginRes.role);
        navigate('/dashboard');
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An error occurred during authentication.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-bg px-4 relative">
      {/* Abstract calming background blobs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-brand-accent/5 blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-brand-accent-purple/5 blur-3xl" />

      <div className="max-w-md w-full bg-brand-card border border-brand-border rounded-2xl p-8 shadow-2xl relative z-10">
        
        {/* Branding header */}
        <div className="text-center mb-8">
          <div className="inline-flex p-3 bg-brand-bg rounded-2xl border border-brand-border text-brand-accent mb-3 shadow-inner">
            <Shield size={36} />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-100">
            AutiGuard Control Layer
          </h1>
          <p className="text-sm text-gray-400 mt-1.5">
            Wearable telemetry dashboard for safety monitoring
          </p>
        </div>

        {error && (
          <div className="mb-5 bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-3 rounded-lg text-sm flex gap-2 items-start">
            <AlertCircle className="shrink-0 mt-0.5" size={16} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegistering && (
            <>
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  placeholder="Caregiver Name"
                  className="w-full bg-brand-bg border border-brand-border rounded-lg px-4 py-2.5 text-sm text-gray-100 placeholder-gray-500 focus:outline-none focus:border-brand-accent transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1">
                  RBAC Role Profile
                </label>
                <select
                  value={role}
                  onChange={e => setRole(e.target.value as any)}
                  className="w-full bg-brand-bg border border-brand-border rounded-lg px-4 py-2.5 text-sm text-gray-100 focus:outline-none focus:border-brand-accent transition-colors"
                >
                  <option value="caregiver">Caregiver</option>
                  <option value="guardian">Guardian / Parent</option>
                  <option value="clinician">Clinician / Doctor</option>
                  <option value="emergency_responder">First Responder / EMS</option>
                </select>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1">
              Email Address
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="caregiver@autiguard.com"
              className="w-full bg-brand-bg border border-brand-border rounded-lg px-4 py-2.5 text-sm text-gray-100 placeholder-gray-500 focus:outline-none focus:border-brand-accent transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-brand-bg border border-brand-border rounded-lg pl-4 pr-10 py-2.5 text-sm text-gray-100 placeholder-gray-500 focus:outline-none focus:border-brand-accent transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-gray-500 hover:text-gray-300"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-brand-accent text-brand-bg hover:bg-brand-accent/90 disabled:opacity-50 py-3 rounded-lg text-sm font-bold shadow-lg transition-all flex items-center justify-center gap-2 mt-6 cursor-pointer"
          >
            {loading ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <span>{isRegistering ? 'Create Account' : 'Authenticate Credentials'}</span>
            )}
          </button>
        </form>

        <div className="mt-6 text-center text-xs pt-4 border-t border-brand-border/40">
          <button
            type="button"
            onClick={() => {
              setIsRegistering(!isRegistering);
              setError(null);
            }}
            className="text-brand-accent hover:underline font-semibold"
          >
            {isRegistering
              ? 'Already registered? Access your account'
              : 'New user? Register account profile'}
          </button>
        </div>

      </div>
    </div>
  );
};
export default Login;
