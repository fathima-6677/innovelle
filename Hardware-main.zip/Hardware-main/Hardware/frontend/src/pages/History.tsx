import React from 'react';
import { useOutletContext } from 'react-router-dom';
import { api } from '../api/httpClient';
import type { SensorReading } from '../types';
import { HistoryChart } from '../components/HistoryChart';
import { Clock, Battery, Heart, ShieldAlert, Activity, BrainCircuit, RefreshCw } from 'lucide-react';

interface OutletContextType {
  selectedDeviceId: string;
}

export const History: React.FC = () => {
  const { selectedDeviceId } = useOutletContext<OutletContextType>();
  const [telemetryLogs, setTelemetryLogs] = React.useState<SensorReading[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);

  const fetchHistory = React.useCallback(async (showSpinner = false) => {
    if (!selectedDeviceId) {
      setTelemetryLogs([]);
      setLoading(false);
      return;
    }
    if (showSpinner) setRefreshing(true);
    else setLoading(true);

    try {
      // Fetch last 24 hours (86400 seconds)
      const response = await api.get(`/telemetry/history/${selectedDeviceId}?seconds=86400`);
      const rawData: any[] = response.data ?? [];

      const mapped: SensorReading[] = rawData.map((item) => ({
        device_id: item.device_id,
        timestamp: item.timestamp,
        battery_pct: item.battery_pct ?? 0,
        gps: item.gps ?? undefined,
        heart_rate_bpm: item.heart_rate_bpm ?? undefined,
        hrv_ms: item.hrv_ms ?? undefined,
        accel: item.accel ?? undefined,
        gyro: item.gyro ?? undefined,
        stress_index: item.stress_index ?? undefined,
        stress_risk: item.stress_risk ?? undefined,
        behavioral_trend_risk: item.behavioral_trend_risk ?? undefined,
        behavioral_trend_status: item.behavioral_trend_status ?? undefined,
      }));

      // Most recent first for the table; chart handles its own sort
      setTelemetryLogs(
        mapped.sort(
          (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        )
      );
    } catch (err) {
      console.error('Error fetching history logs:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [selectedDeviceId]);

  React.useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  if (!selectedDeviceId) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] border border-dashed border-brand-border rounded-xl p-8 max-w-xl mx-auto">
        <ShieldAlert size={40} className="text-gray-500 mb-4 animate-pulse" />
        <h3 className="text-md font-bold text-gray-200">No Device Paired</h3>
        <p className="text-xs text-gray-400 text-center mt-1">
          Pair a device in Settings to view historical trends.
        </p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[50vh] text-gray-400 text-xs">
        Compiling Historical Telemetry Logs...
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-6xl mx-auto">

      {/* Recharts area chart — heart rate / stress / battery over time */}
      <HistoryChart data={telemetryLogs} />

      {/* Raw audit table */}
      <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h4 className="text-sm font-extrabold uppercase tracking-wider text-gray-300">
              Telemetry Audit Logs
            </h4>
            <p className="text-xs text-gray-500 mt-0.5">
              {telemetryLogs.length} packets in the last 24 hours
            </p>
          </div>
          <button
            onClick={() => fetchHistory(true)}
            disabled={refreshing}
            className="flex items-center gap-1.5 text-xs font-bold text-brand-accent bg-brand-bg border border-brand-border px-3 py-1.5 rounded-lg hover:border-brand-accent/40 transition-colors disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} />
            Refresh
          </button>
        </div>

        {telemetryLogs.length === 0 ? (
          <div className="text-center py-6 text-xs text-gray-500">
            No diagnostic packets recorded yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-brand-border/60 text-gray-400">
                  <th className="pb-3 pr-4 font-semibold">
                    <span className="flex items-center gap-1"><Clock size={12} /> Timestamp</span>
                  </th>
                  <th className="pb-3 pr-4 font-semibold">
                    <span className="flex items-center gap-1"><Heart size={12} /> Vitals</span>
                  </th>
                  <th className="pb-3 pr-4 font-semibold">
                    <span className="flex items-center gap-1"><Activity size={12} /> Stress Index</span>
                  </th>
                  <th className="pb-3 pr-4 font-semibold">
                    <span className="flex items-center gap-1"><BrainCircuit size={12} /> Meltdown Risk</span>
                  </th>
                  <th className="pb-3 pr-4 font-semibold">
                    <span className="flex items-center gap-1"><Battery size={12} /> Battery</span>
                  </th>
                  <th className="pb-3 font-semibold">GPS Coordinates</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-border/30 text-gray-300">
                {telemetryLogs.map((log, i) => (
                  <tr key={i} className="hover:bg-brand-bg/25 transition-colors">
                    <td className="py-2.5 pr-4 font-mono text-[10px] text-gray-400 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="py-2.5 pr-4 font-mono whitespace-nowrap">
                      <span className="font-bold text-brand-accent">
                        {log.heart_rate_bpm ?? '--'} BPM
                      </span>
                      <span className="text-gray-500 mx-1.5">|</span>
                      <span className="text-gray-300">
                        {log.hrv_ms != null ? `${log.hrv_ms.toFixed(1)} ms` : '--'} HRV
                      </span>
                    </td>
                    <td className="py-2.5 pr-4 font-mono whitespace-nowrap">
                      {log.stress_index != null ? (
                        <span
                          className={`font-bold ${
                            log.stress_risk === 'high'
                              ? 'text-red-400'
                              : log.stress_risk === 'medium'
                              ? 'text-yellow-400'
                              : 'text-brand-accent'
                          }`}
                        >
                          {log.stress_index.toFixed(1)}%{' '}
                          <span className="text-gray-500">({log.stress_risk})</span>
                        </span>
                      ) : (
                        <span className="text-gray-500">--</span>
                      )}
                    </td>
                    <td className="py-2.5 pr-4 font-mono whitespace-nowrap">
                      {log.behavioral_trend_risk != null ? (
                        <span
                          className={`font-bold ${
                            log.behavioral_trend_risk > 70
                              ? 'text-red-400'
                              : log.behavioral_trend_risk > 40
                              ? 'text-yellow-400'
                              : 'text-brand-accent'
                          }`}
                        >
                          {log.behavioral_trend_risk.toFixed(1)}%{' '}
                          <span className="text-gray-500">({log.behavioral_trend_status})</span>
                        </span>
                      ) : (
                        <span className="text-gray-500">--</span>
                      )}
                    </td>
                    <td className="py-2.5 pr-4 font-mono text-gray-300 whitespace-nowrap">
                      {log.battery_pct}%
                    </td>
                    <td className="py-2.5 font-mono text-gray-400 whitespace-nowrap">
                      {log.gps
                        ? `${log.gps.lat.toFixed(5)}, ${log.gps.lng.toFixed(5)}`
                        : 'No GPS Lock'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
export default History;
