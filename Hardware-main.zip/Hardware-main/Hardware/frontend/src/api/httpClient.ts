// Base HTTP Client for REST endpoints
const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1";

interface RequestOptions extends RequestInit {
    body_json?: any;
}

export async function request(endpoint: string, options: RequestOptions = {}) {
    const token = localStorage.getItem("autiguard_token");
    const headers = new Headers(options.headers || {});

    if (token) {
        headers.set("Authorization", `Bearer ${token}`);
    }

    if (options.body_json) {
        headers.set("Content-Type", "application/json");
        options.body = JSON.stringify(options.body_json);
    }

    options.headers = headers;

    const response = await fetch(`${API_URL}${endpoint}`, options);

    if (response.status === 401) {
        // Token has expired or is invalid, redirect to login
        localStorage.removeItem("autiguard_token");
        localStorage.removeItem("autiguard_user");
        if (!window.location.pathname.includes("/login")) {
            window.location.href = "/login";
        }
    }

    if (!response.ok) {
        const errorText = await response.text();
        let errorMsg = "API request failed";
        try {
            const parsed = JSON.parse(errorText);
            errorMsg = parsed.detail || errorMsg;
        } catch {
            errorMsg = errorText || errorMsg;
        }
        throw new Error(errorMsg);
    }

    if (response.status === 204) {
        return null;
    }

    return response.json();
}

export const api = {
    get: (endpoint: string) => request(endpoint, { method: "GET" }),
    post: (endpoint: string, body: any) => request(endpoint, { method: "POST", body_json: body }),
    put: (endpoint: string, body: any) => request(endpoint, { method: "PUT", body_json: body }),
    patch: (endpoint: string, body?: any) => request(endpoint, { method: "PATCH", body_json: body }),
    delete: (endpoint: string) => request(endpoint, { method: "DELETE" }),
};
