import { useEffect, useRef, useState } from 'react';

const WS_URL =
  import.meta.env.VITE_WS_URL ||
  'ws://localhost:8000/api/v1/telemetry/ws/v1/devices';

/**
 * useDeviceWebSocket
 * ------------------
 * Opens a single authenticated WebSocket connection to the backend device room
 * and calls `onEvent` with every incoming JSON message.
 *
 * The `onEvent` callback is stored in a ref so it always reflects the latest
 * version without triggering a reconnect — this avoids the stale-closure bug
 * that would occur if onEvent were included in the useEffect dependency array.
 *
 * Reconnects with exponential backoff (1 s → 30 s cap) on drop.
 */
export function useDeviceWebSocket(
  deviceId: string | null,
  onEvent: (event: any) => void
): boolean {
  const [connected, setConnected] = useState(false);

  // Stable ref for the callback — always points to the latest version
  const onEventRef = useRef(onEvent);
  useEffect(() => {
    onEventRef.current = onEvent;
  });

  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const backoffRef = useRef(1000);

  useEffect(() => {
    if (!deviceId) {
      setConnected(false);
      return;
    }

    let cancelled = false;

    const connect = () => {
      if (cancelled) return;

      const token = localStorage.getItem('autiguard_token');
      if (!token) {
        console.warn('[WS] Aborting connect — no auth token in localStorage.');
        return;
      }

      // Close any stale socket before opening a new one
      if (socketRef.current) {
        socketRef.current.onclose = null;
        socketRef.current.close();
        socketRef.current = null;
      }

      const url = `${WS_URL}/${deviceId}?token=${encodeURIComponent(token)}`;
      console.log(`[WS] Connecting: ${url}`);

      const ws = new WebSocket(url);
      socketRef.current = ws;

      ws.onopen = () => {
        if (cancelled) { ws.close(); return; }
        console.log(`[WS] Connected to device channel: ${deviceId}`);
        setConnected(true);
        backoffRef.current = 1000; // reset on success
      };

      ws.onmessage = (msgEvent) => {
        try {
          const data = JSON.parse(msgEvent.data);
          onEventRef.current(data); // always uses latest callback — no stale closure
        } catch (err) {
          console.error('[WS] Failed to parse message:', err);
        }
      };

      ws.onclose = (closeEvent) => {
        if (cancelled) return;
        console.log(
          `[WS] Closed for ${deviceId} (code ${closeEvent.code}). ` +
          `Reconnecting in ${backoffRef.current}ms…`
        );
        setConnected(false);
        const delay = backoffRef.current;
        backoffRef.current = Math.min(delay * 2, 30_000);
        reconnectTimerRef.current = setTimeout(connect, delay);
      };

      ws.onerror = (err) => {
        // onclose fires immediately after onerror; reconnect logic lives there
        console.error('[WS] Error:', err);
      };
    };

    connect();

    return () => {
      cancelled = true;
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      if (socketRef.current) {
        socketRef.current.onclose = null; // prevent reconnect on intentional close
        socketRef.current.close();
        socketRef.current = null;
      }
      setConnected(false);
    };
  }, [deviceId]); // only reconnect when the device changes, not on callback changes

  return connected;
}
