export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'guardian' | 'caregiver' | 'clinician' | 'emergency_responder' | 'admin';
}

export interface DeviceStatus {
  device_id: string;
  name: string;
  firmware_version: string;
  battery_pct: number;
  connection_mode: 'BLE' | 'WIFI' | 'LTE';
  last_seen: string;
  is_online: boolean;
}

export interface SensorReading {
  device_id: string;
  timestamp: string;
  battery_pct: number;
  gps?: {
    lat: number;
    lng: number;
    accuracy_m: number;
  };
  heart_rate_bpm?: number;
  hrv_ms?: number;
  accel?: {
    x: number;
    y: number;
    z: number;
  };
  gyro?: {
    x: number;
    y: number;
    z: number;
  };
  stress_index?: number;
  stress_risk?: 'low' | 'medium' | 'high';
  behavioral_trend_risk?: number;
  behavioral_trend_status?: string;
}

export interface Alert {
  id: string;
  deviceId: string;
  type: 'panic' | 'fall' | 'distress' | 'stress' | 'geofence' | 'lowBattery';
  severity: 'critical' | 'high' | 'warning' | 'info';
  timestamp: number;
  location?: {
    lat: number;
    lng: number;
  };
  acknowledged: boolean;
  acknowledged_by?: string;
  acknowledged_at?: string;
  message?: string;
}

export interface GeofenceConfig {
  id: string;
  device_id: string;
  name: string;
  // snake_case matches the FastAPI backend response exactly
  center_lat: number;
  center_lng: number;
  radius_meters: number;
  is_active: boolean;
}
