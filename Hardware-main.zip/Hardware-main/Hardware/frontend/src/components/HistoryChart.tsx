import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Activity, BrainCircuit, Battery, Calendar } from 'lucide-react';
import type { SensorReading } from '../types';

interface HistoryChartProps {
  data: SensorReading[];
}

type MetricKey = 'heart_rate_bpm' | 'stress_index' | 'battery_pct';

export const HistoryChart: React.FC<HistoryChartProps> = ({ data }) => {
  const [selectedMetric, setSelectedMetric] = React.useState<MetricKey>('heart_rate_bpm');
  const [timeRange, setTimeRange] = React.useState<'1h' | '24h'>('1h');

  const chartData = React.useMemo(() => {
    const sorted = [...data].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    const cutoff =
      timeRange === '1h'
        ? Date.now() - 60 * 60 * 1000
        : Date.now() - 24 * 60 * 60 * 1000;

    return sorted
      .filter((item) => new Date(item.timestamp).getTime() >= cutoff)
      .map((item) => ({
        formattedTime: new Date(item.timestamp).toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
        heart_rate_bpm: item.heart_rate_bpm ?? null,
        stress_index: item.stress_index ?? null,
        battery_pct: item.battery_pct ?? null,
      }));
  }, [data, timeRange]);

  const metricConfig: Record<
    MetricKey,
    { label: string; unit: string; color: string; icon: React.ReactNode; domain: [number, number] }
  > = {
    heart_rate_bpm: {
      label: 'Heart Rate',
      unit: ' BPM',
      color: '#4ED9C3',
      icon: <Activity size={16} />,
      domain: [40, 160],
    },
    stress_index: {
      label: 'Stress Index',
      unit: '%',
      color: '#F59E0B',
      icon: <BrainCircuit size={16} />,
      domain: [0, 100],
    },
    battery_pct: {
      label: 'Battery Level',
      unit: '%',
      color: '#3B82F6',
      icon: <Battery size={16} />,
      domain: [0, 100],
    },
  };

  const current = metricConfig[selectedMetric];

  return (
    <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg flex flex-col min-h-[380px]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 mb-5">
        <div>
          <h3 className="text-sm font-extrabold uppercase tracking-wider text-gray-300">
            Sensor Telemetry Trends
          </h3>
          <p className="text-xs text-gray-500 mt-0.5">
            {chartData.length} data points in view
          </p>
        </div>

        <div className="flex items-center gap-2 bg-brand-bg/85 p-1 rounded-lg border border-brand-border/40 self-start sm:self-auto">
          {(['1h', '24h'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setTimeRange(r)}
              className={`px-3 py-1 rounded text-xs font-semibold transition-all ${
                timeRange === r
                  ? 'bg-brand-card text-brand-accent shadow'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              {r === '1h' ? 'Last Hour' : '24 Hours'}
            </button>
          ))}
        </div>
      </div>

      {/* Metric tabs */}
      <div className="grid grid-cols-3 gap-2 mb-5">
        {(Object.keys(metricConfig) as MetricKey[]).map((key) => {
          const cfg = metricConfig[key];
          const isActive = selectedMetric === key;
          return (
            <button
              key={key}
              onClick={() => setSelectedMetric(key)}
              className={`flex items-center justify-center gap-2 py-2.5 px-2 rounded-lg border text-xs font-bold transition-all ${
                isActive
                  ? 'bg-brand-bg border-brand-accent/50 text-brand-accent shadow-inner'
                  : 'bg-brand-bg/40 border-brand-border/30 text-gray-400 hover:text-gray-200 hover:bg-brand-bg/60'
              }`}
            >
              {cfg.icon}
              <span className="hidden sm:inline">{cfg.label}</span>
            </button>
          );
        })}
      </div>

      {/* Chart */}
      <div className="flex-1 min-h-[220px] w-full">
        {chartData.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500 border border-dashed border-brand-border/50 rounded-lg p-8">
            <Calendar size={32} className="mb-2 text-gray-600" />
            <p className="font-semibold text-sm">No Telemetry Data</p>
            <p className="text-[11px] opacity-85 text-center mt-0.5">
              Logs will appear here once the wearable starts transmitting.
            </p>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorMetric" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={current.color} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={current.color} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1C2541" opacity={0.5} />
              <XAxis
                dataKey="formattedTime"
                stroke="#6B7280"
                fontSize={10}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="#6B7280"
                fontSize={10}
                tickLine={false}
                axisLine={false}
                domain={current.domain}
                unit={current.unit}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1C2541',
                  borderColor: '#2E3A59',
                  borderRadius: '0.5rem',
                  color: '#F3F4F6',
                  fontSize: '11px',
                }}
                labelClassName="font-semibold text-gray-300"
              />
              <Area
                type="monotone"
                dataKey={selectedMetric}
                stroke={current.color}
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorMetric)"
                name={current.label}
                connectNulls
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};
export default HistoryChart;
