import React from 'react';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

interface LiveSensorTileProps {
  title: string;
  value: string | number;
  unit: string;
  icon: React.ReactNode;
  trend?: 'up' | 'down' | 'stable';
  statusText?: string;
  statusType?: 'success' | 'warning' | 'error' | 'neutral';
  isPulsingHeart?: boolean;
  bpm?: number;
  description?: string;
}

export const LiveSensorTile: React.FC<LiveSensorTileProps> = ({
  title,
  value,
  unit,
  icon,
  trend = 'stable',
  statusText,
  statusType = 'neutral',
  isPulsingHeart = false,
  bpm = 72,
  description
}) => {
  // Calculate pulse speed in seconds per beat based on BPM
  const pulseDuration = React.useMemo(() => {
    if (bpm <= 0) return '0s';
    return `${60 / bpm}s`;
  }, [bpm]);

  const getStatusClasses = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-brand-accent/10 text-brand-accent border border-brand-accent/20';
      case 'warning':
        return 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20';
      case 'error':
        return 'bg-red-500/10 text-red-400 border border-red-500/20';
      default:
        return 'bg-gray-500/10 text-gray-400 border border-gray-500/20';
    }
  };

  const renderTrendIcon = () => {
    switch (trend) {
      case 'up':
        return <ArrowUpRight className="text-brand-accent" size={16} />;
      case 'down':
        return <ArrowDownRight className="text-brand-accent-purple" size={16} />;
      default:
        return <Minus className="text-gray-500" size={16} />;
    }
  };

  return (
    <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg relative overflow-hidden transition-all duration-300 hover:border-brand-accent/30 group">
      {/* Background Hover Highlight */}
      <div className="absolute inset-0 bg-gradient-to-r from-brand-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
      
      {/* Top Section */}
      <div className="flex justify-between items-center mb-3">
        <span className="text-xs uppercase tracking-wider font-semibold text-gray-400">
          {title}
        </span>
        <div className="flex items-center gap-1.5 bg-brand-bg/80 px-2 py-0.5 rounded border border-brand-border/40 text-xs text-gray-300">
          {renderTrendIcon()}
          <span className="font-medium text-[11px] capitalize">{trend}</span>
        </div>
      </div>

      {/* Main Metric Content */}
      <div className="flex items-end justify-between">
        <div className="flex items-baseline">
          <span className="text-3xl font-bold tracking-tight text-gray-100 font-mono">
            {value}
          </span>
          <span className="text-sm font-medium text-gray-400 ml-1">
            {unit}
          </span>
        </div>

        {/* Pulsing Visual Effect for Heart Rate */}
        <div 
          className="p-3 bg-brand-bg rounded-lg border border-brand-border/50 text-brand-accent"
          style={isPulsingHeart && bpm > 0 ? {
            animation: `heart-pulse ${pulseDuration} infinite ease-in-out`
          } : undefined}
        >
          {icon}
        </div>
      </div>

      {/* Status Footer */}
      {statusText && (
        <div className="mt-4 flex items-center justify-between gap-2 pt-3 border-t border-brand-border/30">
          <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full ${getStatusClasses(statusType)}`}>
            {statusText}
          </span>
          {description && (
            <span className="text-xs text-gray-400 truncate max-w-[60%]">
              {description}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
