import React from 'react';
import { Battery, Wifi, Activity, Clock, ShieldAlert, Cpu } from 'lucide-react';
import type { DeviceStatus } from '../types';

interface DeviceStatusCardProps {
  deviceId: string;
  device: DeviceStatus | null;
}

export const DeviceStatusCard: React.FC<DeviceStatusCardProps> = ({ deviceId, device }) => {
  // Determine if data is stale (not online)
  const isStale = React.useMemo(() => {
    if (!device) return true;
    return !device.is_online;
  }, [device]);

  const getConnectionColor = (mode: string) => {
    switch (mode) {
      case 'WIFI':
        return 'text-brand-accent';
      case 'BLE':
        return 'text-brand-accent-purple';
      case 'LTE':
        return 'text-blue-400';
      default:
        return 'text-red-500';
    }
  };

  const getBatteryColor = (level: number) => {
    if (level > 50) return 'text-brand-accent';
    if (level > 20) return 'text-yellow-400';
    return 'text-red-500';
  };

  const formatLastSeen = (isoString: string) => {
    if (!isoString) return 'Never';
    const timestamp = new Date(isoString).getTime();
    if (isNaN(timestamp)) return 'Never';
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 60) return 'Just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return new Date(timestamp).toLocaleDateString();
  };

  if (!device) {
    return (
      <div className="bg-brand-card border border-brand-border rounded-xl p-6 shadow-lg flex flex-col justify-between h-[192px] animate-pulse">
        <div className="space-y-3">
          <div className="h-5 w-2/3 bg-brand-border rounded"></div>
          <div className="h-4 w-1/2 bg-brand-border rounded"></div>
        </div>
        <div className="h-8 w-full bg-brand-border rounded"></div>
      </div>
    );
  }

  return (
    <div className={`bg-brand-card border rounded-xl p-6 shadow-lg relative overflow-hidden transition-all duration-300 ${
      isStale ? 'border-red-500/50 shadow-red-950/20' : 'border-brand-border'
    }`}>
      {/* Background status pulse indicator */}
      <div className={`absolute top-0 right-0 w-32 h-32 -mr-16 -mt-16 rounded-full blur-3xl opacity-10 ${
        isStale ? 'bg-red-500' : 'bg-brand-accent'
      }`} />

      {/* Header */}
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-100 flex items-center gap-2">
            {device.name}
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-brand-border text-gray-400">
              {deviceId.slice(0, 8)}...
            </span>
          </h3>
          <div className="flex items-center gap-2 text-xs text-gray-400 mt-1">
            <Cpu size={12} />
            <span>Firmware: v{device.firmware_version}</span>
          </div>
        </div>

        {/* Live / Offline Status Tag */}
        <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${
          isStale 
            ? 'bg-red-500/10 text-red-400 border border-red-500/20' 
            : 'bg-brand-accent/10 text-brand-accent border border-brand-accent/20'
        }`}>
          <span className={`w-2 h-2 rounded-full ${
            isStale ? 'bg-red-400' : 'bg-brand-accent animate-pulse'
          }`} />
          {isStale ? 'Offline' : 'Live / Connected'}
        </span>
      </div>

      {/* Warning Alert if Stale */}
      {isStale && (
        <div className="mb-4 flex items-start gap-2 bg-red-950/30 border border-red-500/30 rounded-lg p-3 text-xs text-red-400">
          <ShieldAlert className="shrink-0 mt-0.5" size={16} />
          <div>
            <p className="font-semibold">Device Connection Stale</p>
            <p className="opacity-90">No sensor data has been received for over 15 seconds. Check wearable power or cell signal.</p>
          </div>
        </div>
      )}

      {/* Core Metrics */}
      <div className="grid grid-cols-2 gap-4 mt-2">
        <div className="flex items-center gap-3 bg-brand-bg/50 border border-brand-border/30 rounded-lg p-3">
          <div className={`p-2 rounded-md bg-brand-bg ${getBatteryColor(device.battery_pct)}`}>
            <Battery size={20} />
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold">Battery</p>
            <p className="text-sm font-bold text-gray-100">{device.battery_pct}%</p>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-brand-bg/50 border border-brand-border/30 rounded-lg p-3">
          <div className={`p-2 rounded-md bg-brand-bg ${getConnectionColor(device.connection_mode)}`}>
            <Wifi size={20} />
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold">Radio Mode</p>
            <p className="text-sm font-bold text-gray-100 capitalize">{device.connection_mode}</p>
          </div>
        </div>
      </div>

      {/* Footer / Last Seen */}
      <div className="mt-4 flex items-center justify-between text-xs text-gray-400 pt-3 border-t border-brand-border/40">
        <div className="flex items-center gap-1.5">
          <Clock size={12} />
          <span>Last Sync: {formatLastSeen(device.last_seen)}</span>
        </div>
        <div className="flex items-center gap-1">
          <Activity size={12} className={isStale ? 'text-gray-600' : 'text-brand-accent'} />
          <span className="text-[10px] font-mono tracking-wider uppercase">Vitals Stream Active</span>
        </div>
      </div>
    </div>
  );
};
export default DeviceStatusCard;
