import React from 'react';
import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { api } from '../api/httpClient';
import { useDeviceWebSocket } from '../api/wsClient';
import {
  LayoutDashboard,
  Cpu,
  Bell,
  LineChart,
  Settings,
  LogOut,
  Shield,
  ChevronDown,
  Loader2,
  AlertCircle,
  QrCode,
  Activity,
  MapPin,
} from 'lucide-react';
import { AlertBanner } from './AlertBanner';
import type { Alert } from '../types';

export const Layout: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [loading, setLoading] = React.useState(true);
  const [user, setUser] = React.useState<any>(null);
  const [linkedDevices, setLinkedDevices] = React.useState<any[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = React.useState<string>('');
  const [alerts, setAlerts] = React.useState<Alert[]>([]);
  const [showDeviceDropdown, setShowDeviceDropdown] = React.useState(false);

  // Fetch current user and list of devices on load
  React.useEffect(() => {
    const initLayout = async () => {
      try {
        const token = localStorage.getItem("autiguard_token");
        if (!token) {
          navigate('/login');
          return;
        }

        // 1. Get user profile
        const profile = await api.get('/users/me');
        setUser(profile);
        localStorage.setItem("autiguard_user", JSON.stringify(profile));

        // 2. Get device list
        const devices = await api.get('/devices/list');
        setLinkedDevices(devices);
        if (devices.length > 0) {
          setSelectedDeviceId(devices[0].id);
        }
      } catch (err) {
        console.error("Layout initialization failed:", err);
        localStorage.removeItem("autiguard_token");
        navigate('/login');
      } finally {
        setLoading(false);
      }
    };

    initLayout();
  }, [navigate]);

  // Fetch alerts list when selected device changes
  React.useEffect(() => {
    if (!selectedDeviceId) {
      setAlerts([]);
      return;
    }

    const fetchAlerts = async () => {
      try {
        const alertList = await api.get(`/alerts/list/${selectedDeviceId}`);
        setAlerts(alertList);
      } catch (err) {
        console.error("Failed to fetch alerts list:", err);
      }
    };

    fetchAlerts();
  }, [selectedDeviceId]);

  // Subscribe to device WebSocket stream for real-time alerts and state syncs
  useDeviceWebSocket(selectedDeviceId ? selectedDeviceId : null, (event) => {
    console.log("WebSocket event received in Layout:", event);
    if (event.type === 'alert.new') {
      const newAlert: Alert = {
        id: event.data.id,
        deviceId: event.data.device_id,
        type: event.data.type,
        timestamp: new Date(event.data.timestamp).getTime(),
        acknowledged: event.data.acknowledged,
        message: event.data.message,
        location: event.data.gps_lat ? { lat: event.data.gps_lat, lng: event.data.gps_lng } : undefined
      };
      
      // Add new alert to list
      setAlerts(prev => [newAlert, ...prev.filter(a => a.id !== newAlert.id)]);
    } else if (event.type === 'alert.acknowledged') {
      // Mark alert as acknowledged in state
      setAlerts(prev => prev.map(a => 
        a.id === event.data.id ? { ...a, acknowledged: true } : a
      ));
    }
  });

  // REST API acknowledgment dispatcher
  const handleAcknowledgeAlert = async (alertId: string) => {
    try {
      await api.patch(`/alerts/${alertId}/acknowledge`);
      // Update local state
      setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, acknowledged: true } : a));
    } catch (error) {
      console.error('Error acknowledging alert via REST API:', error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("autiguard_token");
    localStorage.removeItem("autiguard_user");
    navigate('/login');
  };

  const menuItems = [
    { name: 'Dashboard',       path: '/dashboard',     icon: <LayoutDashboard size={18} /> },
    { name: 'Hardware Health', path: '/device-status', icon: <Cpu size={18} /> },
    { name: 'Alert Logs',      path: '/alerts',        icon: <Bell size={18} /> },
    { name: 'Telemetry History', path: '/history',     icon: <LineChart size={18} /> },
    { name: 'Safe Zones',      path: '/geofences',     icon: <MapPin size={18} /> },
    { name: 'QR Emergency ID', path: '/qr-identity',  icon: <QrCode size={18} /> },
    { name: 'Non-Verbal Assist', path: '/nonverbal',   icon: <Activity size={18} /> },
    { name: 'Settings',        path: '/settings',      icon: <Settings size={18} /> },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-brand-bg flex flex-col items-center justify-center text-gray-400">
        <Loader2 className="animate-spin text-brand-accent mb-4" size={40} />
        <p className="text-sm font-semibold tracking-wide uppercase">Initializing AutiGuard Panel...</p>
      </div>
    );
  }

  if (!user) return null;

  const activeDeviceObj = linkedDevices.find(d => d.id === selectedDeviceId);

  return (
    <div className="min-h-screen bg-brand-bg flex flex-col md:flex-row text-gray-200">
      
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-brand-card border-b md:border-b-0 md:border-r border-brand-border flex flex-col shrink-0">
        {/* Sidebar Header / Logo */}
        <div className="p-6 border-b border-brand-border/60 flex items-center gap-3">
          <div className="p-2 bg-brand-bg rounded-lg border border-brand-border text-brand-accent shadow-inner">
            <Shield size={20} />
          </div>
          <div>
            <span className="font-bold text-sm text-gray-100 tracking-wide uppercase block">AutiGuard</span>
            <span className="text-[10px] text-gray-400 font-medium">Caregiver Portal v1.0</span>
          </div>
        </div>

        {/* Sidebar Navigation Links */}
        <nav className="flex-1 p-4 space-y-1">
          {menuItems.map(item => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-lg text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-brand-bg border border-brand-accent/20 text-brand-accent shadow-inner'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-brand-bg/50 border border-transparent'
                }`
              }
            >
              {item.icon}
              <span>{item.name}</span>
            </NavLink>
          ))}
        </nav>

        {/* Sidebar User Footer */}
        <div className="p-4 border-t border-brand-border/60 bg-brand-bg/30">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-full bg-brand-border flex items-center justify-center text-brand-accent text-xs font-bold border border-brand-border uppercase">
              {user.name.slice(0, 2)}
            </div>
            <div className="truncate flex-1">
              <p className="text-xs font-bold text-gray-200 truncate">{user.name}</p>
              <p className="text-[10px] text-gray-400 truncate capitalize">{user.role}</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 bg-brand-bg border border-brand-border hover:bg-red-500/10 hover:border-red-500/30 hover:text-red-400 transition-colors duration-200 text-[11px] font-bold py-2 rounded-lg cursor-pointer"
          >
            <LogOut size={12} />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Panel Area */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Top Header */}
        <header className="h-16 border-b border-brand-border bg-brand-card/50 backdrop-blur px-6 flex items-center justify-between z-20">
          
          {/* Active Route Title */}
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-gray-300">
            {menuItems.find(item => item.path === location.pathname)?.name || 'Portal'}
          </h2>

          {/* Device Switcher */}
          <div className="relative">
            {linkedDevices.length > 0 ? (
              <div>
                <button
                  onClick={() => setShowDeviceDropdown(!showDeviceDropdown)}
                  className="flex items-center gap-2 bg-brand-bg border border-brand-border px-3.5 py-1.5 rounded-lg text-xs font-bold hover:border-brand-accent/50 transition-colors"
                >
                  <span className="text-[10px] uppercase text-gray-400 mr-1 font-semibold">Active Device:</span>
                  <span className="text-brand-accent text-[11px] font-mono">{activeDeviceObj ? activeDeviceObj.name : 'Select...'}</span>
                  <ChevronDown size={14} className="text-gray-400" />
                </button>

                {showDeviceDropdown && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setShowDeviceDropdown(false)} />
                    <div className="absolute right-0 mt-2 w-56 bg-brand-card border border-brand-border rounded-lg shadow-xl py-1 z-20">
                      {linkedDevices.map(device => (
                        <button
                          key={device.id}
                          onClick={() => {
                            setSelectedDeviceId(device.id);
                            setShowDeviceDropdown(false);
                          }}
                          className={`w-full text-left px-4 py-2 text-xs font-mono transition-colors ${
                            selectedDeviceId === device.id
                              ? 'bg-brand-bg text-brand-accent font-bold'
                              : 'text-gray-300 hover:bg-brand-bg/50 hover:text-white'
                          }`}
                        >
                          {device.name}
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-xs text-yellow-400 bg-yellow-500/10 border border-yellow-500/20 px-3 py-1.5 rounded-lg">
                <AlertCircle size={14} />
                <span>Pair a device in Settings</span>
              </div>
            )}
          </div>
        </header>

        {/* Content Outlet */}
        <main className="flex-1 p-6 overflow-y-auto">
          <Outlet context={{ selectedDeviceId, alerts, setLinkedDevices }} />
        </main>
      </div>

      {/* Global Realtime Alert Banner */}
      <AlertBanner alerts={alerts} onAcknowledge={handleAcknowledgeAlert} />
    </div>
  );
};
export default Layout;
