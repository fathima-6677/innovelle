import React from 'react';
import { AlertCircle, CheckCircle, MapPin, ShieldAlert, X } from 'lucide-react';
import type { Alert } from '../types';

interface AlertBannerProps {
  alerts: Alert[];
  onAcknowledge: (alertId: string) => Promise<void>;
}

export const AlertBanner: React.FC<AlertBannerProps> = ({ alerts, onAcknowledge }) => {
  const activeAlerts = React.useMemo(() => {
    return alerts.filter(a => !a.acknowledged);
  }, [alerts]);

  const [dismissedAlerts, setDismissedAlerts] = React.useState<string[]>([]);

  const visibleAlerts = React.useMemo(() => {
    return activeAlerts.filter(a => !dismissedAlerts.includes(a.id));
  }, [activeAlerts, dismissedAlerts]);

  const handleDismiss = (id: string) => {
    setDismissedAlerts(prev => [...prev, id]);
  };

  const getAlertConfig = (type: string) => {
    switch (type) {
      case 'fall':
        return {
          title: 'FALL DETECTED',
          bg: 'bg-red-950/90 border-red-500 text-red-100',
          icon: <ShieldAlert className="text-red-400 animate-bounce" size={24} />,
          desc: 'The onboard accelerometer has detected a high-g impact event.'
        };
      case 'panic':
        return {
          title: 'PANIC BUTTON PRESS',
          bg: 'bg-violet-950/90 border-violet-500 text-violet-100',
          icon: <AlertCircle className="text-violet-400 animate-pulse" size={24} />,
          desc: 'The wearer has manually activated the panic SOS button.'
        };
      case 'geofence':
        return {
          title: 'GEOFENCE BREACH',
          bg: 'bg-orange-950/90 border-orange-500 text-orange-100',
          icon: <MapPin className="text-orange-400 animate-pulse" size={24} />,
          desc: 'The wearer has exited the configured safe zone coordinates.'
        };
      default:
        return {
          title: 'LOW BATTERY ALERT',
          bg: 'bg-yellow-950/90 border-yellow-500 text-yellow-100',
          icon: <AlertCircle className="text-yellow-400" size={24} />,
          desc: 'The wearable battery charge is below 15%.'
        };
    }
  };

  if (visibleAlerts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-md w-full px-4 md:px-0">
      {visibleAlerts.map(alert => {
        const config = getAlertConfig(alert.type);
        return (
          <div
            key={alert.id}
            className={`border-2 rounded-xl p-4 shadow-2xl backdrop-blur-md flex flex-col gap-3 transition-all duration-300 animate-slide-in ${config.bg}`}
          >
            {/* Upper row: icon and title */}
            <div className="flex justify-between items-start">
              <div className="flex gap-3 items-center">
                {config.icon}
                <div>
                  <h4 className="font-extrabold tracking-wide text-sm">
                    {config.title}
                  </h4>
                  <p className="text-[11px] opacity-75 font-mono">
                    {new Date(alert.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </div>
              <button
                onClick={() => handleDismiss(alert.id)}
                className="text-gray-400 hover:text-white p-1 rounded-md transition-colors"
                title="Dismiss from view (does not acknowledge)"
              >
                <X size={16} />
              </button>
            </div>

            {/* Description */}
            <p className="text-xs opacity-90 leading-relaxed">
              {alert.message || config.desc}
            </p>

            {/* Location coordinates if available */}
            {alert.location && (
              <div className="bg-black/30 rounded p-2 text-[10px] font-mono flex items-center gap-1.5 border border-white/5">
                <MapPin size={12} className="text-gray-400" />
                <span>Lat: {alert.location.lat.toFixed(6)}, Lng: {alert.location.lng.toFixed(6)}</span>
              </div>
            )}

            {/* Action Row */}
            <div className="flex justify-end gap-2 pt-1">
              <button
                onClick={() => onAcknowledge(alert.id)}
                className="flex items-center gap-1 bg-white text-brand-bg hover:bg-brand-accent hover:text-brand-bg transition-colors duration-200 text-xs font-bold px-3 py-1.5 rounded-lg shadow-md"
              >
                <CheckCircle size={14} />
                Acknowledge Alert
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};
