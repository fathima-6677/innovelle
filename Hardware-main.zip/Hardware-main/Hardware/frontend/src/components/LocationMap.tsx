import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import type { GeofenceConfig } from '../types';
import { Shield, ShieldAlert, Navigation } from 'lucide-react';

interface LocationMapProps {
  lat: number;
  lng: number;
  geofence: GeofenceConfig | null;
  deviceName: string;
}

// Recenter map when coordinates change
const MapRecenter: React.FC<{ center: [number, number] }> = ({ center }) => {
  const map = useMap();
  React.useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
};

export const LocationMap: React.FC<LocationMapProps> = ({ lat, lng, geofence, deviceName }) => {
  const position: [number, number] = [lat || 37.7749, lng || -122.4194];

  // Haversine breach check using snake_case fields from backend
  const isOutsideGeofence = React.useMemo(() => {
    if (!geofence || !lat || !lng) return false;

    const R = 6371e3;
    const φ1 = (lat * Math.PI) / 180;
    const φ2 = (geofence.center_lat * Math.PI) / 180;
    const Δφ = ((geofence.center_lat - lat) * Math.PI) / 180;
    const Δλ = ((geofence.center_lng - lng) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c > geofence.radius_meters;
  }, [lat, lng, geofence]);

  const activeIcon = React.useMemo(() => {
    return L.divIcon({
      className: 'custom-leaflet-icon',
      html: `
        <div class="relative flex items-center justify-center w-8 h-8">
          <span class="absolute inline-flex h-full w-full rounded-full ${
            isOutsideGeofence ? 'bg-red-400' : 'bg-brand-accent'
          } opacity-40 animate-ping"></span>
          <span class="relative inline-flex rounded-full h-4.5 w-4.5 ${
            isOutsideGeofence ? 'bg-red-500' : 'bg-brand-accent'
          } border-2 border-slate-900 shadow-md"></span>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });
  }, [isOutsideGeofence]);

  return (
    <div className="bg-brand-card border border-brand-border rounded-xl p-5 shadow-lg flex flex-col h-full min-h-[400px]">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-md font-semibold text-gray-100 flex items-center gap-2">
            Live GPS Tracking
          </h3>
          <p className="text-xs text-gray-400">
            Coordinates: {lat.toFixed(6)}, {lng.toFixed(6)}
          </p>
        </div>

        {/* Geofence status badge */}
        {geofence ? (
          <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
            isOutsideGeofence
              ? 'bg-red-500/10 text-red-400 border border-red-500/20'
              : 'bg-brand-accent/10 text-brand-accent border border-brand-accent/20'
          }`}>
            {isOutsideGeofence ? (
              <>
                <ShieldAlert size={14} />
                <span>Zone Breach: {geofence.name}</span>
              </>
            ) : (
              <>
                <Shield size={14} />
                <span>Inside {geofence.name}</span>
              </>
            )}
          </div>
        ) : (
          <span className="text-xs text-gray-400 bg-brand-bg px-2.5 py-1 rounded border border-brand-border/40">
            Geofence Unconfigured
          </span>
        )}
      </div>

      {/* Map */}
      <div className="flex-1 w-full h-[300px] min-h-[300px] rounded-lg overflow-hidden relative">
        <MapContainer center={position} zoom={16} scrollWheelZoom={true} style={{ height: '100%', width: '100%' }}>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          />

          <MapRecenter center={position} />

          <Marker position={position} icon={activeIcon}>
            <Popup className="custom-popup">
              <div className="text-xs text-slate-900 font-sans p-1">
                <p className="font-bold text-slate-800">{deviceName}</p>
                <p className="text-[10px] text-slate-500 mt-0.5">PPG Heart Rate: Tracked Live</p>
              </div>
            </Popup>
          </Marker>

          {/* Geofence overlay using snake_case props */}
          {geofence && (
            <Circle
              center={[geofence.center_lat, geofence.center_lng]}
              radius={geofence.radius_meters}
              pathOptions={{
                color: isOutsideGeofence ? '#EF4444' : '#4ED9C3',
                fillColor: isOutsideGeofence ? '#EF4444' : '#4ED9C3',
                fillOpacity: 0.08,
                weight: 1.5,
                dashArray: isOutsideGeofence ? '5, 5' : undefined,
              }}
            />
          )}
        </MapContainer>
      </div>

      <div className="flex items-center gap-2 mt-4 text-xs text-gray-400 bg-brand-bg/50 border border-brand-border/30 p-2.5 rounded-lg">
        <Navigation size={14} className="text-brand-accent animate-pulse" />
        <span>Telemetry streams every 5 seconds. GPS accuracy subject to hardware lock quality.</span>
      </div>
    </div>
  );
};
export default LocationMap;
