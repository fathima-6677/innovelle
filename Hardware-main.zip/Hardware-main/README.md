# Hardware
AutiGuard is a smart wearable safety system for children with autism. It uses an ESP32, GPS, sensors, and Firebase to monitor location and detect emergencies in real time. Caregivers receive instant alerts through a web dashboard, enabling quick response and improving safety, communication, and peace of mind.
